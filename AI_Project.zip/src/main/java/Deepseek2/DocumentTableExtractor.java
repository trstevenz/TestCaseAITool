package Deepseek2;

import org.apache.poi.xwpf.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

public class DocumentTableExtractor {
    public static List<String> extractTablesList(File file) {
        List<String> tableHtmlList = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(file);
             XWPFDocument document = new XWPFDocument(fis)) {

            for (XWPFTable table : document.getTables()) {
                StringBuilder tableHtml = new StringBuilder("<html><body>");
                tableHtml.append("<table border='1' cellspacing='0' cellpadding='5' style='border-collapse: collapse;'>");

                for (XWPFTableRow row : table.getRows()) {
                    tableHtml.append("<tr>");
                    for (XWPFTableCell cell : row.getTableCells()) {
                        tableHtml.append("<td>").append(cell.getText().replace("\n", "<br>")).append("</td>");
                    }
                    tableHtml.append("</tr>");
                }
                tableHtml.append("</table></body></html>");

                tableHtmlList.add(tableHtml.toString());
            }

        } catch (Exception e) {
            tableHtmlList.add("<html><body><h3>Error extracting tables: " + e.getMessage() + "</h3></body></html>");
        }

        return tableHtmlList;
    }
}
