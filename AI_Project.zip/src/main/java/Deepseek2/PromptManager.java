package Deepseek2;

public class PromptManager {

    public static String generatePrompt(String tableContent, int testCaseCount) {
        return "Generate exactly " + testCaseCount + " test cases in this TAB-SEPARATED format:\n\n" +
               String.join("\t", TestCaseManager.COLUMN_HEADERS) + "\n\n" +
               "TABLE CONTENT:\n" + tableContent + "\n\n" +
               "### INSTRUCTIONS ###\n" +
               "1. Ensure the Testcase ID follows a continuous sequence: TC001, TC002, ..., TC" + String.format("%03d", testCaseCount) + ".\n" +
               "2. The Testcase Name should follow this format: 'TC001_{name}', 'TC002_{name}', etc. (without duplicate prefixes).\n" +
               "3. Do not repeat headers in the response.\n" +
               "4. Maintain proper test case descriptions, expected results, and steps.\n" +
               "5. Ensure all " + testCaseCount + " test cases are present. Do not skip any numbers.\n" +
               "6. Testcase Description should start with 'Verify whether'.\n" +
               "7. Actual Result should be the same as Testcase Description but without 'Verify whether'.\n" +
               "8. Expected Result should be the same as Actual Result but using the word 'should'.\n" +
               "9. Always maintain ascending sequence order for test cases based on Requirement Number.\n" +
               "10. If continuing, DO NOT provide extra explanations or greetings—just continue from the last test case number in the same format.\n\n" +
               "**IMPORTANT:**\n" +
               "- Format output as a clean, tab-separated text block with no extra text.\n" +
               "- If you receive a continuation command, start directly with the next test case ID without reintroducing any headers.";
    }

    public static String generateContinuationPrompt(int remainingCount, int lastTestCaseID) {
        return "CONTINUE: Generate exactly " + remainingCount + " more test cases, starting from TC" +
               String.format("%03d", lastTestCaseID + 1) + ".\n\n" +
               "**IMPORTANT:**\n" +
               "- If continuing, DO NOT provide extra explanations or greetings—just continue from the last test case number in the same format."+
               "- Maintain the same tab-separated format.\n" +
               "- DO NOT repeat headers, explanations, or greetings.\n" +
               "- Continue the numbering sequence correctly.\n" +
               "- Keep test case descriptions, actual results, and expected results consistent.";
    }
}
