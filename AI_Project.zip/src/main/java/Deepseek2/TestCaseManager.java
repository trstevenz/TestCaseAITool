package Deepseek2;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class TestCaseManager {
    public static final String[] COLUMN_HEADERS = {
        "Testcase ID", "Testcase Name", "Requirement no", "Testcase Description",
        "Test Data", "Steps No", "Detailed Steps", "Expected Result",
        "Actual Result", "Status", "Comments"
    };

    public static List<List<String>> generateTestCases(String tableContent, int testCaseCount, String apiKey) throws IOException {
        List<List<String>> allTestCases = new ArrayList<>();
        int remainingTestCases = testCaseCount;
        int lastTestCaseID = 0;

        while (remainingTestCases > 0) {
            String prompt = (lastTestCaseID == 0)
                ? PromptManager.generatePrompt(tableContent, remainingTestCases)
                : PromptManager.generateContinuationPrompt(remainingTestCases, lastTestCaseID);

            String response = getAIResponse(prompt, apiKey);
            List<List<String>> newTestCases = processResponse(response);

            if (newTestCases.isEmpty()) {
                throw new IOException("API returned no new test cases. Possible content limit issue.");
            }

            allTestCases.addAll(newTestCases);
            remainingTestCases -= newTestCases.size();

            // Update the last TestCase ID for seamless continuation
            lastTestCaseID = extractTestCaseNumber(newTestCases.get(newTestCases.size() - 1).get(0));
        }

        return ensureContinuousTestCases(allTestCases, testCaseCount);
    }

    private static String getAIResponse(String prompt, String apiKey) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + apiKey)
            .openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        JSONObject request = new JSONObject()
            .put("contents", new JSONArray()
                .put(new JSONObject()
                    .put("parts", new JSONArray()
                        .put(new JSONObject().put("text", prompt))
                    )
                )
            );

        try (OutputStream os = conn.getOutputStream()) {
            os.write(request.toString().getBytes(StandardCharsets.UTF_8));
        }

        if (conn.getResponseCode() != 200) {
            throw new IOException("API Error: " + conn.getResponseMessage());
        }

        StringBuilder response = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line);
            }
        }
        return response.toString();
    }

    private static List<List<String>> processResponse(String response) {
        List<List<String>> testCaseList = new ArrayList<>();
        try {
            JSONObject json = new JSONObject(response);
            String content = json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text");

            String[] lines = content.split("\n");
            
            for (String line : lines) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith(COLUMN_HEADERS[0])) continue;

                String[] values = line.split("\t", -1);
                List<String> row = new ArrayList<>(Arrays.asList(values));

                testCaseList.add(row);
            }
            return testCaseList;
        } catch (Exception e) {
            throw new RuntimeException("Failed to process response: " + e.getMessage());
        }
    }

    private static List<List<String>> ensureContinuousTestCases(List<List<String>> testCases, int testCaseCount) {
        List<List<String>> finalTestCases = new ArrayList<>();
        for (int i = 1; i <= testCaseCount; i++) {
            String expectedID = String.format("TC%03d", i);
            boolean found = false;
            for (List<String> testCase : testCases) {
                if (testCase.get(0).equals(expectedID)) {
                    finalTestCases.add(testCase);
                    found = true;
                    break;
                }
            }
            if (!found) {
                List<String> placeholderRow = new ArrayList<>(Collections.nCopies(COLUMN_HEADERS.length, ""));
                placeholderRow.set(0, expectedID);
                placeholderRow.set(1, expectedID + "_GeneratedLater");
                finalTestCases.add(placeholderRow);
            }
        }
        return finalTestCases;
    }

    private static int extractTestCaseNumber(String testCaseID) {
        try {
            return Integer.parseInt(testCaseID.replaceAll("[^0-9]", ""));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public static void exportToExcel(List<List<String>> testCases, String filePath) throws IOException {
        if (testCases.isEmpty()) {
            throw new IOException("No test cases to write to Excel.");
        }

        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Test Cases");
            CellStyle headerStyle = ExcelStyleManager.createHeaderStyle(workbook);
            CellStyle wrapStyle = ExcelStyleManager.createWrapTextStyle(workbook);

            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < COLUMN_HEADERS.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(COLUMN_HEADERS[i]);
                cell.setCellStyle(headerStyle);
            }

            for (int i = 0; i < testCases.size(); i++) {
                Row row = sheet.createRow(i + 1);
                List<String> testCase = testCases.get(i);
                for (int j = 0; j < COLUMN_HEADERS.length; j++) {
                    Cell cell = row.createCell(j, CellType.STRING);
                    cell.setCellValue(j < testCase.size() ? testCase.get(j) : "");
                    cell.setCellStyle(wrapStyle);
                }
            }

            for (int i = 0; i < COLUMN_HEADERS.length; i++) {
                sheet.autoSizeColumn(i);
            }

            try (FileOutputStream fos = new FileOutputStream(filePath)) {
                workbook.write(fos);
            }
        }
    }
}
