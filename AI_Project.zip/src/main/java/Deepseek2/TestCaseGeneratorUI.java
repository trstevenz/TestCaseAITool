package Deepseek2;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import com.formdev.flatlaf.FlatIntelliJLaf;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import Deepseek2.TestCaseManager;


public class TestCaseGeneratorUI extends JFrame {
    private JButton uploadBtn, generateBtn, downloadBtn;
    private JEditorPane documentPane;
    private JTextArea logArea;
    private JComboBox<String> tableDropdown;
    private JTextField testcaseCountField;
    private String apiKey = "AIzaSyB2RpjaWNVh4vl5xd9PrnPHfcLvgQBtC8s";  // Replace with your API key
    private List<String> extractedTables = new ArrayList<>();
    private List<List<String>> testCases = new ArrayList<>();

    public TestCaseGeneratorUI() {
        initializeUI();
    }

    private void initializeUI() {
        try {
            UIManager.setLookAndFeel(new FlatIntelliJLaf());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        setTitle("AI Test Case Generator");
        setSize(1280, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));

        uploadBtn = createStyledButton("Upload Document", new Color(63, 81, 181));
        uploadBtn.addActionListener(this::handleUpload);
        topPanel.add(uploadBtn);

        tableDropdown = new JComboBox<>();
        tableDropdown.setEnabled(false);
        topPanel.add(tableDropdown);

        testcaseCountField = new JTextField(5);
        testcaseCountField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        testcaseCountField.setToolTipText("Enter number of test cases");
        topPanel.add(new JLabel("Test Cases:"));
        topPanel.add(testcaseCountField);

        documentPane = new JEditorPane();
        documentPane.setContentType("text/html");
        documentPane.setEditable(false);
        JScrollPane documentScroll = new JScrollPane(documentPane);
        documentScroll.setBorder(BorderFactory.createTitledBorder("Extracted Table Content"));

        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(BorderFactory.createTitledBorder("Processing Log"));

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        generateBtn = createStyledButton("Generate Test Cases", new Color(40, 167, 226));
        downloadBtn = createStyledButton("Download Excel", new Color(76, 175, 80));
        generateBtn.addActionListener(this::handleGeneration);
        downloadBtn.addActionListener(this::handleDownload);
        generateBtn.setEnabled(false);
        downloadBtn.setEnabled(false);
        controlPanel.add(generateBtn);
        controlPanel.add(downloadBtn);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, documentScroll, logScroll);
        splitPane.setResizeWeight(0.7);

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(splitPane, BorderLayout.CENTER);
        mainPanel.add(controlPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        return btn;
    }

    private void handleUpload(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Word Documents", "docx"));

        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            try {
                extractedTables = DocumentTableExtractor.extractTablesList(file);

                tableDropdown.removeAllItems();
                if (extractedTables.isEmpty()) {
                    tableDropdown.addItem("No Tables Found");
                    documentPane.setText("<html><body><h3>No tables found in the document.</h3></body></html>");
                    generateBtn.setEnabled(false);
                } else {
                    for (int i = 0; i < extractedTables.size(); i++) {
                        tableDropdown.addItem("Table " + (i + 1));
                    }
                    tableDropdown.setEnabled(true);
                    tableDropdown.addActionListener(e1 -> updateDisplayedTable());
                    documentPane.setText(extractedTables.get(0));
                    generateBtn.setEnabled(true);
                }

                logArea.append("Document uploaded successfully: " + file.getName() + "\n");
                downloadBtn.setEnabled(false);
            } catch (Exception ex) {
                showError("Upload Error", "Failed to read document: " + ex.getMessage());
            }
        }
    }

    private void updateDisplayedTable() {
        int selectedIndex = tableDropdown.getSelectedIndex();
        if (selectedIndex >= 0 && selectedIndex < extractedTables.size()) {
            documentPane.setText(extractedTables.get(selectedIndex));
        }
    }

    private void handleGeneration(ActionEvent e) {
        int selectedIndex = tableDropdown.getSelectedIndex();
        if (selectedIndex < 0 || extractedTables.isEmpty()) {
            showError("Selection Error", "Please upload a document and select a table.");
            return;
        }

        String selectedTableContent = extractedTables.get(selectedIndex);
        int testCaseCount;

        try {
            testCaseCount = Integer.parseInt(testcaseCountField.getText().trim());
            if (testCaseCount <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            showError("Input Error", "Please enter a valid number of test cases.");
            return;
        }

        logArea.append("\n=== Generating Test Cases for " + (selectedIndex + 1) + " ===\n");

        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    testCases = TestCaseManager.generateTestCases(selectedTableContent, testCaseCount, apiKey);
                    logArea.append("Successfully generated " + testCases.size() + " test cases\n");
                    downloadBtn.setEnabled(true);
                } catch (Exception ex) {
                    logArea.append("Generation failed: " + ex.getMessage() + "\n");
                }
                return null;
            }
        }.execute();
    }

    private void handleDownload(ActionEvent e) {
        if (testCases.isEmpty()) {
            showError("Download Error", "No test cases available. Please generate test cases first.");
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Test Cases");
        fileChooser.setSelectedFile(new File("TestCases.xlsx"));
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Excel Files", "xlsx"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            if (!fileToSave.getAbsolutePath().endsWith(".xlsx")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".xlsx");
            }

            try {
                TestCaseManager.exportToExcel(testCases, fileToSave.getAbsolutePath());
                JOptionPane.showMessageDialog(this, "Test cases saved to: " + fileToSave.getAbsolutePath(), "Download Complete", JOptionPane.INFORMATION_MESSAGE);
                logArea.append("Test cases saved: " + fileToSave.getAbsolutePath() + "\n");
            } catch (Exception ex) {
                showError("Download Error", "Failed to save file: " + ex.getMessage());
            }
        }
    }

    private void showError(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
        logArea.append("ERROR: " + message + "\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TestCaseGeneratorUI().setVisible(true));
    }
}
