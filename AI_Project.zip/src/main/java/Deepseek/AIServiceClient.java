package Deepseek;

import org.json.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AIServiceClient {
    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
    private static final String API_KEY = "AIzaSyCAXgHQCRX75CWTXyVpuCiSqlhGo2cfloI";

    public String getAIResponse(String prompt) throws IOException {
        HttpURLConnection conn = createConnection();
        sendRequest(conn, prompt);
        return handleResponse(conn);
    }

    private HttpURLConnection createConnection() throws IOException {
        URL url = new URL(API_URL + "?key=" + API_KEY);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        return conn;
    }

    private void sendRequest(HttpURLConnection conn, String prompt) throws IOException {
        try (OutputStream os = conn.getOutputStream()) {
            os.write(buildRequestBody(prompt).toString().getBytes(StandardCharsets.UTF_8));
        }
    }

    private JSONObject buildRequestBody(String prompt) {
        return new JSONObject()
            .put("contents", new JSONArray()
                .put(new JSONObject()
                    .put("parts", new JSONArray()
                        .put(new JSONObject().put("text", prompt))
                    )
                )
            );
    }

    private String handleResponse(HttpURLConnection conn) throws IOException {
        if (conn.getResponseCode() != 200) {
            throw new IOException("API Error: " + conn.getResponseMessage());
        }
        
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream()))) {
            return br.lines().collect(java.util.stream.Collectors.joining());
        }
    }
}