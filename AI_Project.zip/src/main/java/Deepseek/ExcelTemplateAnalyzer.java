package Deepseek;


import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExcelTemplateAnalyzer {
    public static class ColumnProfile {
        public final String header;
        public String dataType;
        public String formatPattern;
        public final List<String> examples = new ArrayList<>();
        public CellStyle style;

        public ColumnProfile(String header) {
            this.header = header;
        }
    }

    private final List<ColumnProfile> columnProfiles = new ArrayList<>();
    private final List<String> headers = new ArrayList<>();

    public void analyzeTemplate(File file) throws IOException {
        try (Workbook wb = WorkbookFactory.create(file)) {
            Sheet sheet = wb.getSheetAt(0);
            headers.clear();
            columnProfiles.clear();
            analyzeHeaders(sheet.getRow(0));
            analyzeColumns(sheet);
        }
    }

    private void analyzeHeaders(Row headerRow) {
        for (Cell cell : headerRow) {
            headers.add(cell.getStringCellValue());
        }
    }

    private void analyzeColumns(Sheet sheet) {
        for (int col = 0; col < headers.size(); col++) {
            ColumnProfile profile = new ColumnProfile(headers.get(col));
            analyzeColumn(sheet, col, profile);
            columnProfiles.add(profile);
        }
    }

    private void analyzeColumn(Sheet sheet, int colIndex, ColumnProfile profile) {
        profile.style = sheet.getRow(0).getCell(colIndex).getCellStyle();
        
        for (int row = 1; row <= Math.min(5, sheet.getLastRowNum()); row++) {
            Cell cell = sheet.getRow(row).getCell(colIndex);
            if (cell != null) {
                analyzeCellContent(cell, profile);
                if (profile.examples.size() < 3) {
                    profile.examples.add(cell.toString());
                }
            }
        }
    }

    private void analyzeCellContent(Cell cell, ColumnProfile profile) {
        DataFormatter formatter = new DataFormatter();
        String value = formatter.formatCellValue(cell);

        switch (cell.getCellType()) {
            case STRING:
                analyzeStringPattern(value, profile);
                break;
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    profile.dataType = "Date";
                    profile.formatPattern = cell.getCellStyle().getDataFormatString();
                } else {
                    profile.dataType = "Number";
                    profile.formatPattern = cell.getCellStyle().getDataFormatString();
                }
                break;
            case BOOLEAN:
                profile.dataType = "Boolean";
                break;
            default:
                profile.dataType = "Text";
        }
    }

    private void analyzeStringPattern(String value, ColumnProfile profile) {
        if (value.matches("^[\\w-]+(\\.[\\w-]+)*@([\\w-]+\\.)+[a-zA-Z]{2,7}$")) {
            profile.dataType = "Email";
        } else if (value.matches("^[A-Z]{3}-\\d{3}$")) {
            profile.dataType = "ID";
            profile.formatPattern = "XXX-000";
        } else if (value.matches("^\\d{3}-\\d{2}-\\d{4}$")) {
            profile.dataType = "SSN";
            profile.formatPattern = "###-##-####");
        } else {
            profile.dataType = "Text";
        }
    }

    public List<ColumnProfile> getColumnProfiles() {
        return columnProfiles;
    }

    public List<String> getHeaders() {
        return headers;
    }
}