package Deepseek;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.util.List;

public class MainFrame extends JFrame {
    private JButton uploadBtn, generateBtn, downloadBtn;
    private JTextArea logArea;
    private JTextField promptField;
    private File selectedFile;
    
    private final ExcelTemplateAnalyzer templateAnalyzer;
    private final AIServiceClient aiServiceClient;
    private final ExcelReportGenerator reportGenerator;

    public MainFrame() {
        templateAnalyzer = new ExcelTemplateAnalyzer();
        aiServiceClient = new AIServiceClient();
        reportGenerator = new ExcelReportGenerator();
        initializeUI();
    }

    private void initializeUI() {
        try {
            UIManager.setLookAndFeel("com.formdev.flatlaf.FlatLightLaf");
        } catch (Exception e) {
            logError("UI Error: " + e.getMessage());
        }

        setTitle("AI Excel Generator");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(Color.WHITE);

        // Header
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setBackground(Color.WHITE);
        JLabel title = new JLabel("AI-Powered Test Case Generator");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(new Color(63, 81, 181));
        headerPanel.add(title);

        // File upload section
        JPanel uploadPanel = createSectionPanel("Step 1: Upload Template");
        uploadBtn = createActionButton("Upload Excel File", new Color(40, 167, 226));
        uploadBtn.addActionListener(this::handleUpload);
        uploadPanel.add(uploadBtn);

        // Prompt section
        JPanel promptPanel = createSectionPanel("Step 2: Enter Scenario");
        promptField = new JTextField();
        promptField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        promptField.setBorder(createInputBorder());
        promptPanel.add(promptField);

        // Control buttons
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        controlPanel.setBackground(Color.WHITE);
        generateBtn = createActionButton("Generate Test Cases", new Color(63, 81, 181));
        downloadBtn = createActionButton("Download Results", new Color(76, 175, 80));
        generateBtn.addActionListener(this::handleGeneration);
        downloadBtn.addActionListener(this::handleDownload);
        downloadBtn.setEnabled(false);
        controlPanel.add(generateBtn);
        controlPanel.add(downloadBtn);

        // Log area
        logArea = new JTextArea();
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(BorderFactory.createTitledBorder("Activity Log"));

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(uploadPanel, BorderLayout.WEST);
        mainPanel.add(promptPanel, BorderLayout.CENTER);
        mainPanel.add(controlPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.NORTH);
        add(logScroll, BorderLayout.CENTER);
    }

    private CompoundBorder createInputBorder() {
        return BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        );
    }

    private JPanel createSectionPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(title),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        panel.setBackground(Color.WHITE);
        return panel;
    }

    private JButton createActionButton(String text, Color bg) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                Color color = getModel().isPressed() ? bg.darker() : 
                    getModel().isRollover() ? bg.brighter() : bg;
                
                g2.setColor(color);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(Color.WHITE);
                FontMetrics fm = g2.getFontMetrics();
                Rectangle bounds = fm.getStringBounds(getText(), g2).getBounds();
                g2.drawString(getText(), 
                    (getWidth() - bounds.width) / 2, 
                    (getHeight() - bounds.height) / 2 + fm.getAscent());
                g2.dispose();
            }
        };
        
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setPreferredSize(new Dimension(180, 40));
        return btn;
    }

    private void handleUpload(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
            "Excel Files", "xlsx", "xls"));
        
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            selectedFile = fc.getSelectedFile();
            try {
                templateAnalyzer.analyzeTemplate(selectedFile);
                logArea.append("✓ Template analyzed: " + selectedFile.getName() + "\n");
                generateBtn.setEnabled(true);
            } catch (Exception ex) {
                showError("Upload Error", ex.getMessage());
            }
        }
    }

    private void handleGeneration(ActionEvent e) {
        if (!validateInputs()) return;

        new SwingWorker<Void, String>() {
            @Override
            protected Void doInBackground() {
                try {
                    publish("\n=== Starting Generation Process ===");
                    String prompt = buildGenerationPrompt();
                    publish("Sending request to Gemini API...");
                    String apiResponse = aiServiceClient.getAIResponse(prompt);
                    publish("Processing API response...");
                    reportGenerator.generateReport(apiResponse, templateAnalyzer.getColumnProfiles());
                    publish("✓ Generation completed successfully!");
                    SwingUtilities.invokeLater(() -> downloadBtn.setEnabled(true));
                } catch (Exception ex) {
                    publish("Error: " + ex.getMessage());
                }
                return null;
            }

            @Override
            protected void process(List<String> chunks) {
                for (String message : chunks) {
                    logArea.append(message + "\n");
                }
            }
        }.execute();
    }

    private void handleDownload(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("Generated_Test_Cases.xlsx"));
        
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                reportGenerator.saveWorkbook(fc.getSelectedFile());
                showMessage("Success", "File saved successfully!");
                logArea.append("Output saved to: " + fc.getSelectedFile().getAbsolutePath() + "\n");
            } catch (Exception ex) {
                showError("Save Error", ex.getMessage());
            }
        }
    }

    private boolean validateInputs() {
        if (selectedFile == null) {
            showError("Input Error", "Please upload an Excel template first!");
            return false;
        }
        if (promptField.getText().trim().isEmpty()) {
            showError("Input Error", "Please enter test scenario description!");
            return false;
        }
        return true;
    }

    private String buildGenerationPrompt() {
        StringBuilder prompt = new StringBuilder();
        List<String> headers = templateAnalyzer.getHeaders();
        List<ExcelTemplateAnalyzer.ColumnProfile> profiles = templateAnalyzer.getColumnProfiles();
        
        prompt.append("Generate test cases in EXACTLY this format:\n\n");
        prompt.append(String.join("\t", headers)).append("\n");
        
        for (int i = 0; i < Math.min(3, profiles.get(0).examples.size()); i++) {
            List<String> exampleRow = new ArrayList<>();
            for (ExcelTemplateAnalyzer.ColumnProfile cp : profiles) {
                exampleRow.add(cp.examples.size() > i ? cp.examples.get(i) : "");
            }
            prompt.append(String.join("\t", exampleRow)).append("\n");
        }
        
        prompt.append("\nRequirements:\n");
        prompt.append("- Generate 10-15 test cases\n");
        prompt.append("- Maintain column order: ").append(String.join(" > ", headers)).append("\n");
        prompt.append("- Data types and formats:\n");
        for (ExcelTemplateAnalyzer.ColumnProfile cp : profiles) {
            prompt.append("  - ").append(cp.header).append(": ").append(cp.dataType);
            if (cp.formatPattern != null) prompt.append(" (").append(cp.formatPattern).append(")");
            prompt.append("\n");
        }
        prompt.append("- Scenario: ").append(promptField.getText()).append("\n");
        prompt.append("\nRespond ONLY with tab-separated values, NO headers, NO explanations!");

        return prompt.toString();
    }

    private void showError(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
    }

    private void showMessage(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    private void logError(String message) {
        System.err.println(message);
        logArea.append("ERROR: " + message + "\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}