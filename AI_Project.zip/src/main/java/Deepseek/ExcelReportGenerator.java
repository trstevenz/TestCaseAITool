package Deepseek;

package ChatGPT;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

public class ExcelReportGenerator {
    private Workbook workbook;

    public void generateReport(String aiResponse, List<ExcelTemplateAnalyzer.ColumnProfile> columnProfiles) 
        throws JSONException {
        String content = parseAIResponse(aiResponse);
        createWorkbook(content, columnProfiles);
    }

    private String parseAIResponse(String response) throws JSONException {
        JSONObject json = new JSONObject(response);
        return json.getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text");
    }

    private void createWorkbook(String content, List<ExcelTemplateAnalyzer.ColumnProfile> columnProfiles) {
        workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Test Cases");
        createHeaders(sheet, columnProfiles);
        processContent(content, sheet, columnProfiles);
        autoSizeColumns(sheet, columnProfiles.size());
    }

    private void createHeaders(Sheet sheet, List<ExcelTemplateAnalyzer.ColumnProfile> columnProfiles) {
        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < columnProfiles.size(); i++) {
            ExcelTemplateAnalyzer.ColumnProfile cp = columnProfiles.get(i);
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cp.header);
            
            CellStyle style = workbook.createCellStyle();
            Font font = workbook.createFont();
            font.setBold(true);
            style.setFont(font);
            style.cloneStyleFrom(cp.style);
            cell.setCellStyle(style);
        }
    }}

    private void processContent(String content, Sheet sheet, List<ExcelTemplateAnalyzer.ColumnProfile> columnProfiles) {
        int rowNum = 1;
        for (String line : content.split("\n")) {
            line = line.trim();
            if (line.isEmpty()) continue;

            String[] values = line.split("\t");
            if (values.length != columnProfiles.size()) continue;

            Row row =
