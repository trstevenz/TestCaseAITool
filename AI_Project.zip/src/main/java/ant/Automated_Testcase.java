package ant;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
 
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
 
public class Automated_Testcase extends Application {
 
    private File selectedFile;
    private Label responseLabel;
 
    @Override
    public void start(Stage primaryStage) {
        // UI Elements
        Label titleLabel = new Label("Upload Excel & Generate Test Cases");
        Button uploadButton = new Button("Upload Excel File");
        TextField promptField = new TextField();
        promptField.setPromptText("Enter test case prompt");
        Button generateButton = new Button("Generate Response");
        responseLabel = new Label("Response: Waiting...");
 
        // File Chooser
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel Files", "*.xlsx"));
 
        // Upload File Action
        uploadButton.setOnAction(e -> {
            selectedFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedFile != null) {
                responseLabel.setText("File uploaded: " + selectedFile.getName());
            } else {
                responseLabel.setText("No file selected.");
            }
        });
 
        // Generate Response Action
        generateButton.setOnAction(e -> {
            if (selectedFile != null && !promptField.getText().isEmpty()) {
                try {
                    String excelData = readExcel(selectedFile);
                    String aiResponse = callGeminiAI(promptField.getText(), excelData);
                    createExcel(aiResponse);
                    responseLabel.setText("Response generated & saved!");
                } catch (Exception ex) {
                    responseLabel.setText("Error: " + ex.getMessage());
                }
            } else {
                responseLabel.setText("Upload file and enter a prompt!");
            }
        });
 
        // Layout Setup
        VBox root = new VBox(10, titleLabel, uploadButton, promptField, generateButton, responseLabel);
        root.setStyle("-fx-padding: 20; -fx-alignment: center;");
 
        // Scene Setup
        Scene scene = new Scene(root, 400, 300);
        primaryStage.setTitle("AI Test Case Generator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
 
    // Method to Read Excel File
    private String readExcel(File file) throws IOException {
        StringBuilder excelContent = new StringBuilder();
        FileInputStream fis = new FileInputStream(file);
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheetAt(0); // Read first sheet
 
        for (Row row : sheet) {
            for (org.apache.poi.ss.usermodel.Cell cell : row) { // ✅ FIX: Use full POI Cell path
                excelContent.append(cell.toString()).append("\t");
            }
            excelContent.append("\n");
        }
 
        workbook.close();
        return excelContent.toString();
    }
 
    // Method to Call Gemini Flash API (Dummy Placeholder)
    private String callGeminiAI(String prompt, String excelData) {
        // TODO: Integrate Gemini Flash API
        return "AI-generated test case based on prompt: " + prompt;
    }
 
    // Method to Create Excel File
    private void createExcel(String aiResponse) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Generated Test Cases");
 
        Row row = sheet.createRow(0);
        org.apache.poi.ss.usermodel.Cell cell = row.createCell(0); // ✅ FIX: Use full POI Cell path
        cell.setCellValue(aiResponse);
 
        FileOutputStream fos = new FileOutputStream("Generated_Test_Cases.xlsx");
        workbook.write(fos);
        fos.close();
        workbook.close();
    }
 
    public static void main(String[] args) {
        launch(args);
    }
}
