package ChatGPT;

import com.formdev.flatlaf.FlatIntelliJLaf;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class TestCaseGenerator extends JFrame {
    private JButton uploadBtn, generateBtn, downloadBtn;
    private JTextArea documentArea, logArea;
    private String apiKey = "AIzaSyB2RpjaWNVh4vl5xd9PrnPHfcLvgQBtC8s";
    private String documentText;
    private List<List<String>> testCases = new ArrayList<>();
    private final String[] COLUMN_HEADERS = {
        "Testcase ID", "Testcase Name", "Requirement no", "Testcase Description",
        "Test Data", "Steps No", "Detailed Steps", "Expected Result",
        "Actual Result", "Status", "Comments"
    };

    public TestCaseGenerator() {
        initializeUI();
    }

    private void initializeUI() {
        try {
            UIManager.setLookAndFeel(new FlatIntelliJLaf());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        setTitle("AI Test Case Generator");
        setSize(1280, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main container
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        // Upload panel
        JPanel uploadPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        uploadBtn = createStyledButton("Upload Document", new Color(63, 81, 181));
        uploadBtn.addActionListener(this::handleUpload);
        uploadPanel.add(uploadBtn);

        // Document area
        documentArea = new JTextArea();
        documentArea.setEditable(false);
        documentArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JScrollPane documentScroll = new JScrollPane(documentArea);
        documentScroll.setBorder(BorderFactory.createTitledBorder("Document Content"));

        // Log area
        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(BorderFactory.createTitledBorder("Processing Log"));

        // Control panel
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        generateBtn = createStyledButton("Generate Test Cases", new Color(40, 167, 226));
        downloadBtn = createStyledButton("Download Excel", new Color(76, 175, 80));
        generateBtn.addActionListener(this::handleGeneration);
        downloadBtn.addActionListener(this::handleDownload);
        downloadBtn.setEnabled(false);
        controlPanel.add(generateBtn);
        controlPanel.add(downloadBtn);

        // Split pane for document and logs
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, documentScroll, logScroll);
        splitPane.setResizeWeight(0.6);

        mainPanel.add(uploadPanel, BorderLayout.NORTH);
        mainPanel.add(splitPane, BorderLayout.CENTER);
        mainPanel.add(controlPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        return btn;
    }

    private void handleUpload(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
            "Word Documents", "docx", "doc"));

        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            try (XWPFDocument doc = new XWPFDocument(new FileInputStream(file))) {
                XWPFWordExtractor extractor = new XWPFWordExtractor(doc);
                documentText = extractor.getText();
                documentArea.setText(documentText);
                logArea.append("Document uploaded successfully: " + file.getName() + "\n");
                downloadBtn.setEnabled(false);
            } catch (Exception ex) {
                showError("Upload Error", "Failed to read document: " + ex.getMessage());
            }
        }
    }

    private void handleGeneration(ActionEvent e) {
        if (documentText == null || documentText.isEmpty()) {
            showError("Input Error", "Please upload a document first!");
            return;
        }

        testCases.clear();
        downloadBtn.setEnabled(false);
        logArea.append("\n=== Starting Generation Process ===\n");

        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    String prompt = buildPrompt();
                    logArea.append("Sending request to Gemini API...\n");
                    String response = getAIResponse(prompt);
                    processResponse(response);
                    logArea.append("Successfully generated " + testCases.size() + " test cases\n");
                    downloadBtn.setEnabled(true);
                } catch (Exception ex) {
                    logArea.append("Generation failed: " + ex.getMessage() + "\n");
                }
                return null;
            }
        }.execute();
    }

    private String buildPrompt() {
        return "Generate test cases in EXACTLY this TAB-SEPARATED format:\n\n" +
               String.join("\t", COLUMN_HEADERS) + "\n\n" +
               "STRUCTURE RULES:\n" +
               "1. One row per test case\n" + 
               "2. Combine multiple steps in 'Steps No' and 'Detailed Steps' columns using:\n" +
               "   Format: '1. [Step 1]; 2. [Step 2]'\n" +
               "3. Keep all related verification steps in single row\n" +
               "4. For Expected Result, list outcomes matching each step\n\n" +
               "DOCUMENT CONTENT:\n" + documentText + "\n\n" +
               "RESPONSE REQUIREMENTS:\n" +
               "- Generate 15-20 test cases\n" +
               "- Maintain column order\n" +
               "- Use exactly " + COLUMN_HEADERS.length + " columns\n" +
               "- NO markdown, ONLY tab-separated values";
    }

    private String getAIResponse(String prompt) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + apiKey)
            .openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        JSONObject request = new JSONObject()
            .put("contents", new JSONArray()
                .put(new JSONObject()
                    .put("parts", new JSONArray()
                        .put(new JSONObject().put("text", prompt))
                    )
                )
            );

        try (OutputStream os = conn.getOutputStream()) {
            os.write(request.toString().getBytes(StandardCharsets.UTF_8));
        }

        if (conn.getResponseCode() != 200) {
            throw new IOException("API Error: " + conn.getResponseMessage());
        }

        StringBuilder response = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
            new InputStreamReader(conn.getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line);
            }
        }
        return response.toString();
    }

    private void processResponse(String response) {
        try {
            JSONObject json = new JSONObject(response);
            String content = json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text");

            logArea.append("Processing API response...\n");
            int validRows = 0;
            
            for (String line : content.split("\n")) {
                line = line.trim()
                          .replaceAll("^\"|\"$", "")
                          .replaceAll("\\d+\\.\\s*", "") // Remove step numbers
                          .replaceAll(";\\s*", "\t");     // Convert step separators to tabs

                if (line.isEmpty()) continue;

                String[] values = line.split("\t", -1);
                if (values.length != COLUMN_HEADERS.length) {
                    logArea.append("Skipped invalid row: " + line + "\n");
                    continue;
                }

                List<String> row = new ArrayList<>();
                for (String value : values) {
                    row.add(value.trim().replaceAll("\\s+", "")); // Normalize whitespace
                }
                testCases.add(row);
                validRows++;
            }
            
            logArea.append("Processed " + validRows + " valid test cases\n");
        } catch (Exception e) {
            throw new RuntimeException("Failed to process response: " + e.getMessage());
        }
    }

    private void handleDownload(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Save Test Cases");
        fc.setSelectedFile(new File("TestCases.xlsx"));

        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            try (XSSFWorkbook workbook = new XSSFWorkbook()) {
                Sheet sheet = workbook.createSheet("Test Cases");
                
                // Create styles
                CellStyle headerStyle = createHeaderStyle(workbook);
                CellStyle wrapStyle = workbook.createCellStyle();
                wrapStyle.setWrapText(true);

                // Create header row
                Row headerRow = sheet.createRow(0);
                for (int i = 0; i < COLUMN_HEADERS.length; i++) {
                    Cell cell = headerRow.createCell(i);
                    cell.setCellValue(COLUMN_HEADERS[i]);
                    cell.setCellStyle(headerStyle);
                }

                // Create data rows with proper formatting
                for (int i = 0; i < testCases.size(); i++) {
                    Row row = sheet.createRow(i + 1);
                    List<String> testCase = testCases.get(i);
                    
                    for (int j = 0; j < testCase.size(); j++) {
                        Cell cell = row.createCell(j);
                        String value = testCase.get(j);
                        
                        // Special formatting for steps columns
                        if (j == 5 || j == 6) { // Steps No and Detailed Steps
                            value = value.replace("; ", "\n")
                                         .replace(". ", ".\n");
                        }
                        
                        cell.setCellValue(value);
                        cell.setCellStyle(wrapStyle);
                    }
                }

                // Auto-size columns with minimum width
                for (int i = 0; i < COLUMN_HEADERS.length; i++) {
                    sheet.autoSizeColumn(i);
                    int currentWidth = sheet.getColumnWidth(i);
                    sheet.setColumnWidth(i, Math.max(currentWidth, 4000));
                }

                // Save file
                try (FileOutputStream fos = new FileOutputStream(file)) {
                    workbook.write(fos);
                    logArea.append("Excel file saved: " + file.getAbsolutePath() + "\n");
                    JOptionPane.showMessageDialog(this,
                        "File saved successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Exception ex) {
                showError("Save Error", "Failed to save Excel file: " + ex.getMessage());
            }
        }
    }
    private CellStyle createHeaderStyle(XSSFWorkbook workbook) {
		// TODO Auto-generated method stub
		return null;
	}

	private void showError(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
        logArea.append("ERROR: " + message + "\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TestCaseGenerator().setVisible(true));
    }
}