package ChatGPT;

public class Config {
    // ✅ Store your API key here
    public static final String GEMINI_API_KEY = "AIzaSyB2RpjaWNVh4vl5xd9PrnPHfcLvgQBtC8s";  // Replace with your API key
}
