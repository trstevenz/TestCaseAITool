package ChatGPT;

import com.formdev.flatlaf.FlatLightLaf;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.*;
import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class AIExcelGenerator extends JFrame {
    private JButton uploadBtn, generateBtn, downloadBtn;
    private JTextArea logArea;
    private JTextField promptField;
    private File selectedFile;
    private Workbook templateWorkbook;
    private Workbook generatedWorkbook;
    private List<ColumnProfile> columnProfiles = new ArrayList<>();
    private List<String> headers = new ArrayList<>();

    // Configuration
    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
    private static final String API_KEY = "AIzaSyCAXgHQCRX75CWTXyVpuCiSqlhGo2cfloI";
    private static final Color PRIMARY_COLOR = new Color(63, 81, 181);
    private static final Color SECONDARY_COLOR = new Color(40, 167, 226);

    class ColumnProfile {
        String header;
        String dataType;
        String formatPattern;
        List<String> examples = new ArrayList<>();
        CellStyle style;

        public ColumnProfile(String header) {
            this.header = header;
        }
    }

    public AIExcelGenerator() {
        if (!checkAPIConnection()) {
            showError("API Connection Error", "Unable to connect to the API. Please check your API key and URL.");
            System.exit(1);
        }
        initializeUI();
    }

    private void initializeUI() {
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception e) {
            logError("UI Error: " + e.getMessage());
        }

        setTitle("AI Excel Generator");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main container
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(Color.WHITE);

        // Header
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setBackground(Color.WHITE);
        JLabel title = new JLabel("AI-Powered Test Case Generator");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(PRIMARY_COLOR);
        headerPanel.add(title);

        // File upload section
        JPanel uploadPanel = createSectionPanel("Step 1: Upload Template");
        uploadBtn = createActionButton("Upload Excel File", SECONDARY_COLOR);
        uploadBtn.addActionListener(this::handleUpload);
        uploadPanel.add(uploadBtn);

        // Prompt section
        JPanel promptPanel = createSectionPanel("Step 2: Enter Scenario");
        promptField = new JTextField();
        promptField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        promptField.setBorder(createInputBorder());
        promptPanel.add(promptField);

        // Control buttons
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        controlPanel.setBackground(Color.WHITE);
        generateBtn = createActionButton("Generate Test Cases", PRIMARY_COLOR);
        downloadBtn = createActionButton("Download Results", new Color(76, 175, 80));
        generateBtn.addActionListener(this::handleGeneration);
        downloadBtn.addActionListener(this::handleDownload);
        downloadBtn.setEnabled(false);
        controlPanel.add(generateBtn);
        controlPanel.add(downloadBtn);

        // Log area
        logArea = new JTextArea();
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(BorderFactory.createTitledBorder("Activity Log"));

        // Layout assembly
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(uploadPanel, BorderLayout.WEST);
        mainPanel.add(promptPanel, BorderLayout.CENTER);
        mainPanel.add(controlPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.NORTH);
        add(logScroll, BorderLayout.CENTER);
    }

    private CompoundBorder createInputBorder() {
        return BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        );
    }

    private JPanel createSectionPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(title),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        panel.setBackground(Color.WHITE);
        return panel;
    }

    private JButton createActionButton(String text, Color bg) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                Color color = getModel().isPressed() ? bg.darker() : 
                    getModel().isRollover() ? bg.brighter() : bg;
                
                g2.setColor(color);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(Color.WHITE);
                FontMetrics fm = g2.getFontMetrics();
                Rectangle bounds = fm.getStringBounds(getText(), g2).getBounds();
                g2.drawString(getText(), 
                    (getWidth() - bounds.width) / 2, 
                    (getHeight() - bounds.height) / 2 + fm.getAscent());
                g2.dispose();
            }
        };
        
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setPreferredSize(new Dimension(180, 40));
        return btn;
    }

    private void handleUpload(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
            "Excel Files", "xlsx", "xls"));
        
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            selectedFile = fc.getSelectedFile();
            try (Workbook wb = WorkbookFactory.create(selectedFile)) {
                templateWorkbook = wb;
                analyzeTemplate(wb.getSheetAt(0));
                logArea.append("✓ Template analyzed: " + selectedFile.getName() + "\n");
                generateBtn.setEnabled(true);
            } catch (Exception ex) {
                showError("Upload Error", ex.getMessage());
            }
        }
    }

    private void analyzeTemplate(Sheet sheet) {
        columnProfiles.clear();
        headers.clear();
        Row headerRow = sheet.getRow(0);
        
        for (Cell cell : headerRow) {
            ColumnProfile cp = new ColumnProfile(cell.getStringCellValue());
            cp.style = cell.getCellStyle();
            headers.add(cp.header);
            analyzeColumn(sheet, cell.getColumnIndex(), cp);
            columnProfiles.add(cp);
        }
    }

    private void analyzeColumn(Sheet sheet, int colIndex, ColumnProfile cp) {
        for (int row = 1; row <= Math.min(5, sheet.getLastRowNum()); row++) {
            Cell cell = sheet.getRow(row).getCell(colIndex);
            if (cell != null) {
                analyzeCellContent(cell, cp);
                if (cp.examples.size() < 3) {
                    cp.examples.add(cell.toString());
                }
            }
        }
        logArea.append(String.format("Column '%s': %s (%s)\n", 
            cp.header, cp.dataType, cp.formatPattern));
    }

    private void analyzeCellContent(Cell cell, ColumnProfile cp) {
        DataFormatter formatter = new DataFormatter();
        String cellValue = formatter.formatCellValue(cell);

        switch (cell.getCellType()) {
            case STRING:
                analyzeStringPattern(cellValue, cp);
                break;
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    cp.dataType = "Date";
                    cp.formatPattern = cell.getCellStyle().getDataFormatString();
                } else {
                    cp.dataType = "Number";
                    cp.formatPattern = cell.getCellStyle().getDataFormatString();
                }
                break;
            case BOOLEAN:
                cp.dataType = "Boolean";
                break;
            default:
                cp.dataType = "Text";
        }
    }

    private void analyzeStringPattern(String value, ColumnProfile cp) {
        if (value.matches("^[\\w-]+(\\.[\\w-]+)*@([\\w-]+\\.)+[a-zA-Z]{2,7}$")) {
            cp.dataType = "Email";
        } else if (value.matches("^[A-Z]{3}-\\d{3}$")) {
            cp.dataType = "ID";
            cp.formatPattern = "XXX-000";
        } else if (value.matches("^\\d{3}-\\d{2}-\\d{4}$")) {
            cp.dataType = "SSN";
            cp.formatPattern = "###-##-####";
        } else {
            cp.dataType = "Text";
        }
    }

    private void handleGeneration(ActionEvent e) {
        if (!validateInputs()) return;

        new SwingWorker<Void, String>() {
            @Override
            protected Void doInBackground() {
                try {
                    publish("\n=== Starting Generation Process ===");
                    String prompt = buildGenerationPrompt();
                    publish("Sending request to Gemini API...");
                    String apiResponse = getAIResponse(prompt);
                    publish("Processing API response...");
                    generatedWorkbook = processAIResponse(apiResponse);
                    publish("✓ Generation completed successfully!");
                    SwingUtilities.invokeLater(() -> downloadBtn.setEnabled(true));
                } catch (Exception ex) {
                    publish("Error: " + ex.getMessage());
                }
                return null;
            }

            @Override
            protected void process(java.util.List<String> chunks) {
                for (String message : chunks) {
                    logArea.append(message + "\n");
                }
            }
        }.execute();
    }

    private boolean validateInputs() {
        if (templateWorkbook == null) {
            showError("Input Error", "Please upload an Excel template first!");
            return false;
        }
        if (promptField.getText().trim().isEmpty()) {
            showError("Input Error", "Please enter test scenario description!");
            return false;
        }
        return true;
    }

    private String buildGenerationPrompt() {
        StringBuilder prompt = new StringBuilder();
        prompt.append("Generate test cases in EXACTLY this format:\n\n");
        
        // Header row
        prompt.append(String.join("\t", headers)).append("\n");
        
        // Example data
        for (int i = 0; i < Math.min(3, columnProfiles.get(0).examples.size()); i++) {
            List<String> exampleRow = new ArrayList<>();
            for (ColumnProfile cp : columnProfiles) {
                exampleRow.add(cp.examples.size() > i ? cp.examples.get(i) : "");
            }
            prompt.append(String.join("\t", exampleRow)).append("\n");
        }
        
        prompt.append("\nRequirements:\n");
        prompt.append("- Generate 10-15 test cases\n");
        prompt.append("- Maintain column order: ").append(String.join(" > ", headers)).append("\n");
        prompt.append("- Data types and formats:\n");
        for (ColumnProfile cp : columnProfiles) {
            prompt.append("  - ").append(cp.header).append(": ").append(cp.dataType);
            if (cp.formatPattern != null) prompt.append(" (").append(cp.formatPattern).append(")");
            prompt.append("\n");
        }
        prompt.append("- Scenario: ").append(promptField.getText()).append("\n");
        prompt.append("\nRespond ONLY with tab-separated values, NO headers, NO explanations!");

        return prompt.toString();
    }

    private String getAIResponse(String prompt) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(API_URL + "?key=" + API_KEY).openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        JSONObject request = new JSONObject()
            .put("contents", new JSONArray()
                .put(new JSONObject()
                    .put("parts", new JSONArray()
                        .put(new JSONObject().put("text", prompt))
                    )
                )
            );

        try (OutputStream os = conn.getOutputStream()) {
            os.write(request.toString().getBytes(StandardCharsets.UTF_8));
        }

        if (conn.getResponseCode() != 200) {
            throw new IOException("API Error: " + conn.getResponseMessage());
        }

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream()))) {
            return br.lines().collect(java.util.stream.Collectors.joining());
        }
    }

    private Workbook processAIResponse(String response) throws JSONException {
        JSONObject json = new JSONObject(response);
        JSONArray candidates = json.getJSONArray("candidates");
        
        if (candidates.isEmpty()) {
            throw new JSONException("Empty response from AI");
        }

        String content = candidates.getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text");

        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet("Test Cases");

        // Create headers
        createStyledHeaders(sheet, wb);

        // Process data rows with improved parsing
        int rowNum = 1;
        boolean dataStarted = false;
        
        for (String line : content.split("\\r?\\n")) {
            line = line.trim().replaceAll("^\"|\"$", ""); // Remove surrounding quotes
            if (line.isEmpty()) continue;

            String[] values = line.split("\t");
            
            // Validate column count
            if (values.length != columnProfiles.size()) {
                if (!dataStarted) continue; // Skip header-like lines
                logArea.append("Skipping invalid row (columns: " + values.length + "): " + line + "\n");
                continue;
            }
            
            dataStarted = true; // Start processing after finding first valid row
            
            Row row = sheet.createRow(rowNum++);
            for (int i = 0; i < values.length; i++) {
                ColumnProfile cp = columnProfiles.get(i);
                Cell cell = row.createCell(i);
                String cleanedValue = values[i].trim().replaceAll("^\"|\"$", "");
                applyCellFormat(cell, cp, cleanedValue, wb);
            }
        }

        // Auto-size columns for better visibility
        for (int i = 0; i < columnProfiles.size(); i++) {
            sheet.autoSizeColumn(i);
        }

        return wb;
    }

    private void createStyledHeaders(Sheet sheet, Workbook wb) {
        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < columnProfiles.size(); i++) {
            ColumnProfile cp = columnProfiles.get(i);
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(cp.header);
            cell.setCellStyle(cloneStyle(cp.style, wb));
        }
    }

    private CellStyle cloneStyle(CellStyle source, Workbook target) {
        CellStyle style = target.createCellStyle();
        style.cloneStyleFrom(source);
        return style;
    }

    private void applyCellFormat(Cell cell, ColumnProfile cp, String value, Workbook wb) {
        try {
            switch (cp.dataType) {
                case "Number":
                    if (!value.isEmpty()) {
                        cell.setCellValue(Double.parseDouble(value));
                    }
                    break;
                case "Date":
                    if (!value.isEmpty()) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat(cp.formatPattern);
                        cell.setCellValue(dateFormat.parse(value));
                        CellStyle dateStyle = wb.createCellStyle();
                        dateStyle.cloneStyleFrom(cp.style);
                        dateStyle.setDataFormat(
                            wb.createDataFormat().getFormat(cp.formatPattern)
                        );
                        cell.setCellStyle(dateStyle);
                    }
                    break;
                case "Boolean":
                    cell.setCellValue(value.equalsIgnoreCase("true"));
                    break;
                default:
                    cell.setCellValue(value);
            }
        } catch (Exception e) {
            cell.setCellValue(value);
            logArea.append("Format warning for " + cp.header + ": " + value + " (" + e.getMessage() + ")\n");
        }
        
        // Apply base style if not already set
        if (cell.getCellStyle() == null) {
            cell.setCellStyle(cloneStyle(cp.style, wb));
        }
    }

    private void handleDownload(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("Generated_Test_Cases.xlsx"));
        
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try (FileOutputStream fos = new FileOutputStream(fc.getSelectedFile())) {
                generatedWorkbook.write(fos);
                showMessage("Success", "File saved successfully!");
                logArea.append("Output saved to: " + fc.getSelectedFile().getAbsolutePath() + "\n");
            } catch (IOException ex) {
                showError("Save Error", ex.getMessage());
            }
        }
    }

    private void showError(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
    }

    private void showMessage(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    private void logError(String message) {
        System.err.println(message);
        logArea.append("ERROR: " + message + "\n");
    }

    private boolean checkAPIConnection() {
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(API_URL + "?key=" + API_KEY).openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            JSONObject request = new JSONObject()
                .put("contents", new JSONArray()
                    .put(new JSONObject()
                        .put("parts", new JSONArray()
                            .put(new JSONObject().put("text", "Explain how AI works"))
                        )
                    )
                );

            try (OutputStream os = conn.getOutputStream()) {
                os.write(request.toString().getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = conn.getResponseCode();
            return (responseCode == 200);
        } catch (Exception e) {
            logError("API Connection Error: " + e.getMessage());
            return false;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AIExcelGenerator().setVisible(true));
    }
}