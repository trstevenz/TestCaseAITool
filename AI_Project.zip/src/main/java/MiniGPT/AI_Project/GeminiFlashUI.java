package MiniGPT.AI_Project;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import javax.swing.text.html.HTMLEditorKit;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class GeminiFlashUI extends JFrame {
    APIKey key = new APIKey();
    private JEditorPane chatArea;
    private JTextArea promptArea;
    private JButton generateButton;
    private JButton newChatButton;
    private List<String> conversationHistory = new ArrayList<>();
    private JButton chooseFileButton;
    private JButton summarizeButton;
    private File selectedFile;

    public GeminiFlashUI() {
        setTitle("Gemini Flash Chat");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        // Color Palette
        Color backgroundColor = new Color(245, 245, 245);
        Color panelColor = new Color(255, 255, 255);
        Color buttonColor = new Color(0, 123, 255);
        Color textColor = new Color(33, 37, 41);

        // Background
        getContentPane().setBackground(backgroundColor);

        // Chat Area (Use JEditorPane for HTML)
        chatArea = new JEditorPane();
        chatArea.setEditable(false);
        chatArea.setContentType("text/html");
        chatArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        chatArea.setBackground(panelColor);

        HTMLEditorKit editorKit = new HTMLEditorKit();
        chatArea.setEditorKit(editorKit);

        chatArea.setText("<html><body style='font-family: Monospaced; background-color: " + toHexString(panelColor) + "; color: " + toHexString(textColor) + "'>");

        JScrollPane chatScrollPane = new JScrollPane(chatArea);
        chatScrollPane.setBorder(BorderFactory.createTitledBorder("Chat"));
        add(chatScrollPane, BorderLayout.CENTER);

        // Prompt Area (Increased Height)
        promptArea = new JTextArea();
        promptArea.setBackground(panelColor);
        promptArea.setForeground(textColor);
        JScrollPane promptScrollPane = new JScrollPane(promptArea);
        promptScrollPane.setBorder(BorderFactory.createTitledBorder("Prompt"));
        promptScrollPane.setPreferredSize(new Dimension(getWidth(), getHeight() / 10));
        add(promptScrollPane, BorderLayout.SOUTH);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(backgroundColor);

        generateButton = new JButton("Generate");
        generateButton.setBackground(buttonColor);
        generateButton.setForeground(Color.WHITE);
        generateButton.setFocusPainted(false);
        generateButton.setBorderPainted(false);
        generateButton.setOpaque(true);
        generateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateResponse();
            }
        });
        buttonPanel.add(generateButton);

        newChatButton = new JButton("New Chat");
        newChatButton.setBackground(buttonColor);
        newChatButton.setForeground(Color.WHITE);
        newChatButton.setFocusPainted(false);
        newChatButton.setBorderPainted(false);
        newChatButton.setOpaque(true);
        newChatButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startNewChat();
            }
        });
        buttonPanel.add(newChatButton);

        chooseFileButton = new JButton("Choose File (doc, pdf)");
        chooseFileButton.setBackground(buttonColor);
        chooseFileButton.setForeground(Color.WHITE);
        chooseFileButton.setFocusPainted(false);
        chooseFileButton.setBorderPainted(false);
        chooseFileButton.setOpaque(true);
        chooseFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chooseFile();
            }
        });
        buttonPanel.add(chooseFileButton);

        summarizeButton = new JButton("Summarize");
        summarizeButton.setBackground(buttonColor);
        summarizeButton.setForeground(Color.WHITE);
        summarizeButton.setFocusPainted(false);
        summarizeButton.setBorderPainted(false);
        summarizeButton.setOpaque(true);
        summarizeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                summarizeFile();
            }
        });
        buttonPanel.add(summarizeButton);
        summarizeButton.setEnabled(false);

        add(buttonPanel, BorderLayout.NORTH);

        setVisible(true);
    }

    private String toHexString(Color color) {
        return String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
    }

    private void generateResponse() {
        String prompt = promptArea.getText();
        if (prompt.isEmpty()) {
            return;
        }

        conversationHistory.add("User: " + prompt);
        appendToChatArea("<div style='padding: 5px; margin-bottom: 5px;'><b>User:</b> " + prompt + "</div>");

        promptArea.setText("");

        String apiKey = key.key;
        if (apiKey == null || apiKey.isEmpty()) {
            appendToChatArea("<div style='color: red;'>Error: API key not found.</div>");
            return;
        }

        String apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey;

        try {
            StringBuilder fullPrompt = new StringBuilder();
            for (String message : conversationHistory) {
                fullPrompt.append(message).append("\n");
            }
            fullPrompt.append("AI: ");

            String encodedPrompt = URLEncoder.encode(fullPrompt.toString(), StandardCharsets.UTF_8);

            String jsonPayload = String.format("{\"contents\": [{\"parts\":[{\"text\": \"%s\"}]}]}", encodedPrompt);

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                String responseString = response.toString();

                JSONObject jsonResponse = new JSONObject(responseString);
                String generatedText = extractTextFromResponse(jsonResponse);

                String formattedText = formatAIResponse(generatedText);

                conversationHistory.add("AI: " + generatedText);
                appendToChatArea("<div style='background-color: #e0e0e0; padding: 5px; margin-bottom: 5px;'>" + formattedText + "</div>");

            } finally {
                connection.disconnect();
            }

        } catch (IOException ex) {
            appendToChatArea("<div style='color: red;'>Error: " + ex.getMessage() + "</div>");
            ex.printStackTrace();
        } catch (Exception ex) {
            appendToChatArea("<div style='color: red;'>An unexpected error occurred: " + ex.getMessage() + "</div>");
            ex.printStackTrace();
        }
    }

    private void startNewChat() {
        conversationHistory.clear();
        chatArea.setText("<html><body style='font-family: Monospaced; background-color: " + toHexString(new Color(255,255,255)) + "; color: " + toHexString(new Color(33,37,41)) + "'>");
    }

    private void appendToChatArea(String html) {
        String currentHTML = chatArea.getText();
        String newHTML = currentHTML.replace("</body>", html + "</body>");
        chatArea.setText(newHTML);
    }

    private String formatAIResponse(String text) {
        text = text.replaceAll("\\*\\*(.+?)\\*\\*", "<b>$1</b>");
        text = text.replaceAll("\\n", "<br>");
        text = text.replaceAll("\\n\\n", "</p><p>");
        text = "<p>" + text + "</p>";
        return text;
    }

    private String extractTextFromResponse(JSONObject jsonResponse) throws Exception {
        try {
            if (jsonResponse.has("candidates")) {
                JSONObject candidate = jsonResponse.getJSONArray("candidates").getJSONObject(0);
                if (candidate.has("content")) {
                    JSONObject content = candidate.getJSONObject("content");
                    if (content.has("parts")) {
                        StringBuilder text = new StringBuilder();
                        for (int i = 0; i < content.getJSONArray("parts").length(); i++) {
                            JSONObject part = content.getJSONArray("parts").getJSONObject(i);
                            if (part.has("text")) {
                                text.append(part.getString("text"));
                            }
                        }
                        return text.toString();
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error extracting text: " + jsonResponse.toString(2));
            throw e;
        }

        throw new Exception("Unexpected response format: " + jsonResponse.toString(2));
    }

    private void chooseFile() {
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("DOC and PDF Files", "doc", "pdf");
        fileChooser.setFileFilter(filter);

        int returnVal = fileChooser.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            selectedFile = fileChooser.getSelectedFile();
            summarizeButton.setEnabled(true);
            JOptionPane.showMessageDialog(this, "File selected: " + selectedFile.getName());
        }
    }

    private void summarizeFile() {
        if (selectedFile == null) {
            return;
        }

        try {
            String fileContent = extractTextFromPDF(selectedFile); // Try PDF first
            if (fileContent == null || fileContent.isEmpty()) {
                fileContent = extractTextFromFile(selectedFile); // Fallback to generic file
                if (fileContent == null || fileContent.isEmpty()) {
                    appendToChatArea("<div style='color: red;'>Error: Could not extract text from file.</div>");
                    return;
                }
            }

            String prompt = "Summarize the following text and provide a dictionary meaning for each word:\n\n" + fileContent;
            String encodedPrompt = URLEncoder.encode(prompt, StandardCharsets.UTF_8);
            generateResponse(encodedPrompt);

        } catch (IOException ex) {
            appendToChatArea("<div style='color: red;'>Error reading or processing file: " + ex.getMessage() + "</div>");
            ex.printStackTrace();
        }
    }

    private String extractTextFromFile(File file) throws IOException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }
        return content.toString();
    }


    private String extractTextFromPDF(File file) throws IOException {
        try (PDDocument document = PDDocument.load(file)) {
            PDFTextStripper stripper = new PDFTextStripper();
            return stripper.getText(document);
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception
            return null; // Indicate failure
        }
    }

    private void generateResponse(String encodedPrompt) {
        String apiKey = key.key;
        if (apiKey == null || apiKey.isEmpty()) {
            appendToChatArea("<div style='color: red;'>Error: API key not found.</div>");
            return;
        }

        String apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey;

        try {
            String jsonPayload = String.format("{\"contents\": [{\"parts\":[{\"text\": \"%s\"}]}]}", encodedPrompt);

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                String responseString = response.toString();

                JSONObject jsonResponse = new JSONObject(responseString);
                String generatedText = extractTextFromResponse(jsonResponse);

                String formattedText = formatAIResponse(generatedText);

                conversationHistory.add("AI: " + generatedText);
                appendToChatArea("<div style='background-color: #e0e0e0; padding: 5px; margin-bottom: 5px;'>" + formattedText + "</div>");

            } finally {
                connection.disconnect();
            }

        } catch (IOException ex) {
            appendToChatArea("<div style='color: red;'>Error: " + ex.getMessage() + "</div>");
            ex.printStackTrace();
        } catch (Exception ex) {
            appendToChatArea("<div style='color: red;'>An unexpected error occurred: " + ex.getMessage() + "</div>");
            ex.printStackTrace();
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GeminiFlashUI());
    }
}