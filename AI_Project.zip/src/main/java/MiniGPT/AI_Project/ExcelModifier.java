package MiniGPT.AI_Project;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.Key;

public class ExcelModifier extends JFrame {

    private JTextArea promptArea;
    private JButton chooseFileButton;
    private JButton generateButton;
    private File selectedFile;
    private JFileChooser fileChooser;
    APIKey key = new APIKey();
    

    public ExcelModifier() {
    	
        setTitle("Excel Modifier");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        // UI Components
        promptArea = new JTextArea();
        JScrollPane promptScrollPane = new JScrollPane(promptArea);
        promptScrollPane.setBorder(BorderFactory.createTitledBorder("Prompt"));
        add(promptScrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        chooseFileButton = new JButton("Choose Excel File");
        chooseFileButton.addActionListener(e -> chooseFile());
        buttonPanel.add(chooseFileButton);

        generateButton = new JButton("Generate & Apply");
        generateButton.addActionListener(e -> generateAndApply());
        generateButton.setEnabled(false); // Initially disabled
        buttonPanel.add(generateButton);

        add(buttonPanel, BorderLayout.SOUTH);

        fileChooser = new JFileChooser(); // Initialize here
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Excel Files", "xlsx");
        fileChooser.setFileFilter(filter);

        setVisible(true);
    }

    private void chooseFile() {
        int returnVal = fileChooser.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            selectedFile = fileChooser.getSelectedFile();
            generateButton.setEnabled(true);
        }
    }

    private void generateAndApply() {
        if (selectedFile == null) {
            return;
        }

        String prompt = promptArea.getText();
        if (prompt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a prompt.");
            return;
        }

        try {
            // 1. Read Excel Data
            StringBuilder excelData = new StringBuilder();
            try (FileInputStream excelFile = new FileInputStream(selectedFile);
                 XSSFWorkbook workbook = new XSSFWorkbook(excelFile)) {

                for (Sheet sheet : workbook) {
                    excelData.append("Sheet: ").append(sheet.getSheetName()).append("\n");
                    for (Row row : sheet) {
                        for (Cell cell : row) {
                            excelData.append(cell.toString()).append("\t");
                        }
                        excelData.append("\n");
                    }
                    excelData.append("\n");
                }
            }

            // 2. Send to Gemini API
            String fullPrompt = prompt + "\n\nExcel Data:\n" + excelData.toString();
            String encodedPrompt = URLEncoder.encode(fullPrompt, StandardCharsets.UTF_8);

            String apiKey = key.key; // Replace with your actual API key
            String apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey;

            String jsonPayload = String.format("{\"contents\": [{\"parts\":[{\"text\": \"%s\"}]}]}", encodedPrompt);

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            String aiResponse = "";
            try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    aiResponse += responseLine.trim();
                }
            } finally {
                connection.disconnect();
            }



            JSONObject jsonResponse = new JSONObject(aiResponse);
            String generatedText = extractTextFromResponse(jsonResponse);


            // 3. Apply Changes (This is a simplified example; you'll need to adapt it)
            try (FileInputStream excelFile = new FileInputStream(selectedFile);
                 XSSFWorkbook workbook = new XSSFWorkbook(excelFile)) {

                // ***************************************************************
                // This is where you'll use Apache POI to apply the generatedText to the Excel file.
                // The generatedText might contain formulas, macros, or instructions.
                // You'll need to parse the generatedText and use POI to modify the workbook accordingly.
                // ***************************************************************

                // Example: If the AI response contains a new formula for cell A1:
                if (generatedText.contains("A1 = ")) {
                    String formula = generatedText.substring(generatedText.indexOf("A1 = ") + 5).trim();
                    Sheet sheet = workbook.getSheetAt(0); // Assuming you want to modify the first sheet
                    Row row = sheet.getRow(0); // Row 1
                    Cell cell = row.getCell(0); // Cell A1
                    if (cell == null) cell = row.createCell(0);
                    cell.setCellFormula(formula);
                }

                // ... (More logic to handle other changes based on the AI response)

                // 4. Save Modified Excel File
                try (FileOutputStream outputStream = new FileOutputStream("modified_" + selectedFile.getName())) {
                    workbook.write(outputStream);
                    JOptionPane.showMessageDialog(this, "Excel file modified and saved!");
                }
            }


        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            ex.printStackTrace();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "An unexpected error occurred: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private String extractTextFromResponse(JSONObject jsonResponse) throws Exception {
        try {
            if (jsonResponse.has("candidates")) {
                JSONObject candidate = jsonResponse.getJSONArray("candidates").getJSONObject(0);
                if (candidate.has("content")) {
                    JSONObject content = candidate.getJSONObject("content");
                    if (content.has("parts")) {
                        StringBuilder text = new StringBuilder();
                        for (int i = 0; i < content.getJSONArray("parts").length(); i++) {
                            JSONObject part = content.getJSONArray("parts").getJSONObject(i);
                            if (part.has("text")) {
                                text.append(part.getString("text"));
                            }
                        }
                        return text.toString();
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error extracting text: " + jsonResponse.toString(2));
            throw e;
        }

        throw new Exception("Unexpected response format: " + jsonResponse.toString(2));
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ExcelModifier());
    }
}