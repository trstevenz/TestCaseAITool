package GPT2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class MainFrame extends JFrame {
    private JTextArea logTextArea;
    private ExcelHandler excelHandler;
    private AIService aiService;

    public MainFrame() {
        setTitle("Excel Test Case Generator");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Initialize components
        logTextArea = new JTextArea();
        logTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logTextArea);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton uploadButton = new JButton("Upload Excel");
        JButton generateButton = new JButton("Generate Test Cases");

        uploadButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleUpload();
            }
        });

        generateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleGenerate();
            }
        });

        buttonPanel.add(uploadButton);
        buttonPanel.add(generateButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Initialize handlers
        excelHandler = new ExcelHandler();
        aiService = new AIService();
    }

    private void handleUpload() {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            excelHandler.setFile(file);
            logTextArea.append("Uploaded: " + file.getName() + "\n");
        }
    }

    private void handleGenerate() {
        if (excelHandler.getFile() == null) {
            logTextArea.append("Please upload an Excel file first.\n");
            return;
        }

        new Thread(new Runnable() {
            public void run() {
                logTextArea.append("Generating test cases...\n");
                String scenario = excelHandler.extractScenario();
                if (scenario != null) {
                    String aiResponse = aiService.getAIResponse(scenario);
                    excelHandler.writeTestCasesToExcel(aiResponse);
                    logTextArea.append("Test cases generated and saved.\n");
                } else {
                    logTextArea.append("Failed to extract scenario from Excel.\n");
                }
            }
        }).start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }
}
