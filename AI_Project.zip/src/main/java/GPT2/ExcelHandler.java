package GPT2;


import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.*;
import java.util.*;

public class ExcelHandler {
    private Workbook templateWorkbook;
    private List<String> headers = new ArrayList<>();

    public boolean loadTemplate(File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            templateWorkbook = WorkbookFactory.create(fis);
            analyzeTemplate();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void analyzeTemplate() {
        headers.clear();
        Sheet sheet = templateWorkbook.getSheetAt(0);
        Row headerRow = sheet.getRow(0);
        for (Cell cell : headerRow) {
            headers.add(cell.getStringCellValue());
        }
    }

    public String buildPrompt(String scenario) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("Generate test cases with these columns:\n");
        prompt.append(String.join("\t", headers)).append("\n");
        prompt.append("Scenario: ").append(scenario).append("\n");
        prompt.append("Generate 10-15 test cases with realistic data. Only return raw data, no explanations.");

        return prompt.toString();
    }

    public boolean processAIResponse(String response) {
        try {
            Workbook wb = new XSSFWorkbook();
            Sheet sheet = wb.createSheet("Test Cases");
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < headers.size(); i++) {
                headerRow.createCell(i).setCellValue(headers.get(i));
            }

            int rowNum = 1;
            for (String line : response.split("\n")) {
                Row row = sheet.createRow(rowNum++);
                String[] values = line.split("\t");
                for (int i = 0; i < values.length; i++) {
                    row.createCell(i).setCellValue(values[i]);
                }
            }

            templateWorkbook = wb;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean saveGeneratedFile(File file) {
        try (FileOutputStream fos = new FileOutputStream(file)) {
            templateWorkbook.write(fos);
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
