package GPT2;


import org.json.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AIService {
    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
    private static final String API_KEY = "AIzaSyB2RpjaWNVh4vl5xd9PrnPHfcLvgQBtC8s";

    public String getAIResponse(String prompt) {
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(API_URL + "?key=" + API_KEY).openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            JSONObject request = new JSONObject().put("prompt", prompt);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(request.toString().getBytes(StandardCharsets.UTF_8));
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            return br.readLine();
        } catch (Exception e) {
            return null;
        }
    }
}
