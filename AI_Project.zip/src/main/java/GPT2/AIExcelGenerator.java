package GPT2;


import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;

public class AIExcelGenerator extends JFrame {
    private JButton uploadBtn, generateBtn, downloadBtn;
    private JTextArea logArea;
    private JTextField promptField;
    private File selectedFile;
    private ExcelHandler excelHandler;
    private AIService aiService;

    public AIExcelGenerator() {
        excelHandler = new ExcelHandler();
        aiService = new AIService();

        initializeUI();
    }

    private void initializeUI() {
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception e) {
            logError("UI Error: " + e.getMessage());
        }

        setTitle("AI Excel Test Case Generator");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(Color.WHITE);

        // Header
        JLabel title = new JLabel("AI-Powered Test Case Generator", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(new Color(63, 81, 181));

        // Upload Panel
        uploadBtn = createButton("Upload Template");
        uploadBtn.addActionListener(this::handleUpload);

        // Prompt Panel
        promptField = new JTextField();
        promptField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        promptField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)));

        // Control Panel
        generateBtn = createButton("Generate Test Cases");
        generateBtn.addActionListener(this::handleGeneration);
        generateBtn.setEnabled(false);

        downloadBtn = createButton("Download Results");
        downloadBtn.addActionListener(this::handleDownload);
        downloadBtn.setEnabled(false);

        // Log Area
        logArea = new JTextArea();
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(logArea);

        // Layout
        mainPanel.add(title, BorderLayout.NORTH);
        mainPanel.add(uploadBtn, BorderLayout.WEST);
        mainPanel.add(promptField, BorderLayout.CENTER);
        mainPanel.add(generateBtn, BorderLayout.EAST);
        mainPanel.add(downloadBtn, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.NORTH);
        add(logScroll, BorderLayout.CENTER);
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(new Color(40, 167, 226));
        btn.setForeground(Color.WHITE);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        return btn;
    }

    private void handleUpload(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Excel Files", "xlsx", "xls"));

        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            selectedFile = fc.getSelectedFile();
            if (excelHandler.loadTemplate(selectedFile)) {
                logArea.append("✓ Template uploaded successfully: " + selectedFile.getName() + "\n");
                generateBtn.setEnabled(true);
            } else {
                logError("Failed to load template.");
            }
        }
    }

    private void handleGeneration(ActionEvent e) {
        if (selectedFile == null || promptField.getText().trim().isEmpty()) {
            logError("Upload a template and enter a prompt first.");
            return;
        }

        new SwingWorker<Void, String>() {
            @Override
            protected Void doInBackground() {
                logArea.append("\n=== Generating Test Cases ===\n");
                String prompt = excelHandler.buildPrompt(promptField.getText());
                String response = aiService.getAIResponse(prompt);
                if (response != null && excelHandler.processAIResponse(response)) {
                    logArea.append("✓ Test cases generated successfully!\n");
                    downloadBtn.setEnabled(true);
                } else {
                    logError("Failed to generate test cases.");
                }
                return null;
            }
        }.execute();
    }

    private void handleDownload(ActionEvent e) {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("Generated_Test_Cases.xlsx"));

        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            if (excelHandler.saveGeneratedFile(fc.getSelectedFile())) {
                logArea.append("✓ File saved successfully!\n");
            } else {
                logError("Failed to save the file.");
            }
        }
    }

    private void logError(String message) {
        logArea.append("ERROR: " + message + "\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AIExcelGenerator().setVisible(true));
    }
}
