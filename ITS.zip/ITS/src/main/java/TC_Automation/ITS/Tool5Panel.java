package TC_Automation.ITS;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * An interactive help panel that serves as a "Rule Book" for the user.
 * It describes the purpose and usage of each available automation action.
 */
public class Tool5Panel extends JPanel {

    // --- Inner class to hold all the documentation for a single rule ---
    private static class RuleDoc {
        private final String name;
        private final String icon;
        private final String description;
        private final String params;
        private final String example;

        RuleDoc(String name, String icon, String description, String params, String example) {
            this.name = name;
            this.icon = icon;
            this.description = description;
            this.params = params;
            this.example = example;
        }

        @Override
        public String toString() {
            return this.name; // This is what will be displayed in the JList
        }
    }

    // --- UI Components ---
    private final JList<RuleDoc> ruleList;
    private final DefaultListModel<RuleDoc> listModel;
    private final JPanel detailsPanel;
    private final JLabel ruleTitle;
    private final JTextArea ruleDescription;
    private final JTextArea ruleParams;
    private final JTextArea ruleExample;

    public Tool5Panel() {
        super(new BorderLayout());
        setBackground(Color.WHITE);

        // --- Create the list of all available rules ---
        List<RuleDoc> rules = createRuleDocumentation();
        listModel = new DefaultListModel<>();
        rules.forEach(listModel::addElement);

        // --- Left Panel: List of Rules ---
        ruleList = new JList<>(listModel);
        ruleList.setCellRenderer(new RuleListRenderer()); // Custom renderer for a nice look
        ruleList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        ruleList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                updateDetailsView(ruleList.getSelectedValue());
            }
        });
        
        JScrollPane listScrollPane = new JScrollPane(ruleList);
        listScrollPane.setBorder(new MatteBorder(0, 0, 0, 1, new Color(220, 220, 220)));

        // --- Right Panel: Details View ---
        detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.setBackground(Color.WHITE);
        detailsPanel.setBorder(new EmptyBorder(20, 25, 20, 25));

        // Initialize components for the details view
        ruleTitle = new JLabel("Select a rule from the left");
        ruleTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        ruleTitle.setForeground(new Color(41, 128, 185));
        ruleTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        ruleDescription = createStyledTextArea();
        ruleParams = createStyledTextArea();
        ruleExample = createStyledTextArea();
        
        detailsPanel.add(ruleTitle);
        detailsPanel.add(Box.createVerticalStrut(20));
        detailsPanel.add(createSectionHeader("Description"));
        detailsPanel.add(ruleDescription);
        detailsPanel.add(Box.createVerticalStrut(20));
        detailsPanel.add(createSectionHeader("Parameters"));
        detailsPanel.add(ruleParams);
        detailsPanel.add(Box.createVerticalStrut(20));
        detailsPanel.add(createSectionHeader("Example Usage in Tool 2"));
        detailsPanel.add(ruleExample);

        // --- Assemble the main panel ---
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, listScrollPane, new JScrollPane(detailsPanel));
        splitPane.setDividerLocation(250);
        splitPane.setBorder(null);
        
        add(splitPane, BorderLayout.CENTER);

        // Set initial selection
        ruleList.setSelectedIndex(0);
    }

    /**
     * Updates the right-hand details panel based on the selected rule.
     */
    private void updateDetailsView(RuleDoc rule) {
        if (rule == null) {
            ruleTitle.setText("Select a rule from the left");
            ruleDescription.setText("");
            ruleParams.setText("");
            ruleExample.setText("");
            return;
        }
        ruleTitle.setText(String.format("<html>%s %s</html>", rule.icon, rule.name));
        ruleDescription.setText(rule.description);
        ruleParams.setText(rule.params);
        ruleExample.setText(rule.example);
    }

    /**
     * Helper to create a styled header for sections in the details view.
     */
    private JLabel createSectionHeader(String text) {
        JLabel header = new JLabel(text);
        header.setFont(new Font("Segoe UI", Font.BOLD, 16));
        header.setAlignmentX(Component.LEFT_ALIGNMENT);
        header.setBorder(new EmptyBorder(0, 0, 5, 0));
        return header;
    }

    /**
     * Helper to create a consistently styled, non-editable JTextArea.
     */
    private JTextArea createStyledTextArea() {
        JTextArea textArea = new JTextArea();
        textArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textArea.setEditable(false);
        textArea.setOpaque(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setAlignmentX(Component.LEFT_ALIGNMENT);
        return textArea;
    }

    /**
     * Populates the list of all rules with their documentation.
     * This is the central "database" for the help content.
     */
    private List<RuleDoc> createRuleDocumentation() {
        List<RuleDoc> rules = new ArrayList<>();

        // Basic Rules
        rules.add(new RuleDoc("NAVIGATE TO URL", "🌐",
                "Opens the browser and navigates to a specific web address.",
                "• Locator: Not Used\n• Test Data: The full URL to navigate to (e.g., https://www.google.com).",
                "In the grid, this is typically the first step. The URL can be taken from the 'Start URL' field automatically when you click 'Run Test'."
        ));
        rules.add(new RuleDoc("CLICK", "🖱️",
                "Performs a standard left-click on a web element like a button, link, or radio button.",
                "• Locator: Required (to identify the element to click).\n• Test Data: Not Used.",
                "Find the 'Login' button using its ID and perform a click."
        ));
        rules.add(new RuleDoc("TYPE TEXT", "✏️",
                "Types a sequence of characters into an input field or text area. It clears the field before typing.",
                "• Locator: Required (to identify the text field).\n• Test Data: The text you want to type.",
                "Find the 'Username' field and type 'admin' into it."
        ));

        // Browser Rules
        rules.add(new RuleDoc("SWITCH WINDOW/TAB", "🔄",
                "Switches the driver's focus to the most recently opened window or browser tab.",
                "• Locator: Not Used.\n• Test Data: Not Used.",
                "Useful after clicking a link that opens a new tab, allowing subsequent steps to interact with the new tab's content."
        ));
        rules.add(new RuleDoc("HANDLE PROMPTS/ALERTS", "🔔",
                "Interacts with JavaScript alerts, confirmations, or prompts.",
                "• Locator: Not Used.\n• Test Data: The action to take ('accept', 'dismiss') or the text to type into a prompt.",
                "To click 'OK' on an alert, use 'accept'. To type into a prompt, just provide the text."
        ));
        
        // Complex Rules
        rules.add(new RuleDoc("SELECT FROM DROPDOWN", "🔽",
                "Selects an option from a dropdown (<select>) menu based on a specified strategy.",
                "• Locator: Required (to identify the dropdown).\n• Test Data: A string with the format 'strategy:value'.",
                "Strategies:\n" +
                "• text:United States (selects by visible text)\n" +
                "• value:US (selects by the option's 'value' attribute)\n" +
                "• index:1 (selects by its position, starting from 0)"
        ));
        rules.add(new RuleDoc("FILE UPLOAD", "📤",
                "Uploads a local file. This action should target an <input type=\"file\"> element.",
                "• Locator: Required (to find the file input element).\n• Test Data: The absolute local path to the file.",
                "Example: C:\\Users\\YourUser\\Documents\\profile_picture.png"
        ));
        rules.add(new RuleDoc("IFRAME HANDLING", "🖼️",
                "Switches the driver's context into or out of an iframe.",
                "• Locator: Required for switching into a frame.\n• Test Data: Not Used.",
                "To enter a frame, use this action with the frame's locator. To return to the main page from a frame, use the separate 'SWITCH TO DEFAULT' action."
        ));
        rules.add(new RuleDoc("EXECUTE JAVASCRIPT", "📜",
                "Executes a custom JavaScript command in the browser.",
                "• Locator: Not Used.\n• Test Data: The full JavaScript code to execute.",
                "Example: arguments[0].scrollIntoView(); (This script requires a locator, which Selenium provides separately)."
        ));
        return rules;
    }

    /**
     * Custom renderer to make the JList look polished with icons and proper spacing.
     */
    private static class RuleListRenderer extends DefaultListCellRenderer {
        private final Border PADDING_BORDER = new EmptyBorder(10, 15, 10, 15);
        private final Border LINE_BORDER = new MatteBorder(0, 0, 1, 0, new Color(240, 240, 240));

        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            label.setBorder(new CompoundBorder(LINE_BORDER, PADDING_BORDER));
            
            if (value instanceof RuleDoc) {
                RuleDoc rule = (RuleDoc) value;
                label.setText(String.format("<html>%s  %s</html>", rule.icon, rule.name));
                label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
            }
            
            if (isSelected) {
                label.setBackground(new Color(52, 152, 219));
                label.setForeground(Color.WHITE);
            } else {
                label.setBackground(Color.WHITE);
                label.setForeground(Color.DARK_GRAY);
            }
            
            return label;
        }
    }
}