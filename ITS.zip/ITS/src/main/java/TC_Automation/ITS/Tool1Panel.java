package TC_Automation.ITS;

//import io.github.bonigarcia.wdm.WebDriverManager;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import javax.net.ssl.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.prefs.Preferences;

/**
 * The final, stable, and complete web scraping tool with all functionality.
 * Features Move Up/Down reordering, a hierarchical Project/Collection storage system,
 * automated Selenium login, and Jsoup for session-aware scraping.
 */
public class Tool1Panel extends JPanel {
    //<editor-fold desc="UI Components Declaration">
    private static final Color PRIMARY_COLOR = new Color(41, 128, 185);
    private static final Color BUTTON_COLOR = new Color(52, 152, 219);
    private static final Color SUCCESS_COLOR = new Color(39, 174, 96);
    private static final Color DANGER_COLOR = new Color(231, 76, 60);
    private static final Font SANS_SERIF_14 = new Font("SansSerif", Font.PLAIN, 14);
    private final JTextField urlField = new JTextField("https://localhost:8080", 30);
    private final JButton scrapeButton = createModernButton("Scrape Now", BUTTON_COLOR);
    private final JButton browseButton = createModernButton("Import HTML", BUTTON_COLOR);
    private final JCheckBox loginCheckBox = new JCheckBox("Requires Login");
    private final JLabel statusLabel = new JLabel("Ready.");
    private final JProgressBar progressBar = new JProgressBar();
    private final JComboBox<String> configComboBox;
    private final JComboBox<String> userLocatorType;
    private final JTextField userLocatorPath;
    private final JComboBox<String> passLocatorType;
    private final JTextField passLocatorPath;
    private final JComboBox<String> submitLocatorType;
    private final JTextField submitLocatorPath;
    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private final DefaultTableModel tableModel;
    private JCheckBox selectAllCheckBox;
    private final JTree storedElementsTree;
    private final DefaultTreeModel treeModel;
    private final DefaultMutableTreeNode rootNode;
    private final JEditorPane storedElementDetailPane;
    private final JComboBox<String> projectLoaderComboBox;
    private String currentProjectName;
    private final Map<String, List<Object[]>> projectCollections = new LinkedHashMap<>();
    private final JPanel loginPanel;
    private Map<String, String> sessionCookies = new HashMap<>();
    private final Map<String, LoginConfig> loginConfigs = new HashMap<>();
    private final Preferences prefs = Preferences.userNodeForPackage(Tool1Panel.class);
    private final JButton moveUpButton = createModernButton("⬆ Move Element", BUTTON_COLOR);
    private final JButton moveDownButton = createModernButton("⬇ Move Element", BUTTON_COLOR);
    // NEW: Buttons for moving collections
    private final JButton moveCollectionUpButton = createModernButton("⬆ Move Collection", BUTTON_COLOR);
    private final JButton moveCollectionDownButton = createModernButton("⬇ Move Collection", BUTTON_COLOR);
    private TestExecutionPanel dashboard;
    //</editor-fold>

    public Tool1Panel(TestExecutionPanel dashboard) {
        super(new BorderLayout(10, 10));
        this.dashboard = dashboard;
        setBorder(new EmptyBorder(15, 15, 15, 15));
        initTrustAllCertificates();
        String[] currentColumnNames = {"Select", "Element Name", "Absolute XPath", "Relative XPath", "ID", "Tag", "Attributes"};
        this.tableModel = new DefaultTableModel(currentColumnNames, 0) {
            @Override public Class<?> getColumnClass(int c) { return c == 0 ? Boolean.class : String.class; }
            @Override public boolean isCellEditable(int r, int c) { return c == 0; }
        };
        this.rootNode = new DefaultMutableTreeNode("No Project Loaded");
        this.treeModel = new DefaultTreeModel(rootNode);
        this.storedElementsTree = new JTree(treeModel);
        this.storedElementDetailPane = new JEditorPane();
        this.storedElementDetailPane.setEditable(false);
        this.storedElementDetailPane.setContentType("text/html");
        this.storedElementDetailPane.setFont(new Font("Monospaced", Font.PLAIN, 12));
        this.storedElementDetailPane.setText("<html><i>Select an element to see its details.</i></html>");
        String[] locatorOptions = {"ID", "Name", "XPath", "CSS Selector", "Class Name"};
        configComboBox = new JComboBox<>();
        userLocatorType = new JComboBox<>(locatorOptions);
        userLocatorPath = new JTextField();
        passLocatorType = new JComboBox<>(locatorOptions);
        passLocatorPath = new JTextField();
        submitLocatorType = new JComboBox<>(locatorOptions);
        submitLocatorPath = new JTextField();
        usernameField = new JTextField();
        passwordField = new JPasswordField();

        projectLoaderComboBox = new JComboBox<>();

        loadConfigurations();
        refreshConfigComboBox();

        this.loginPanel = createLoginPanel();
		this.dashboard = null;
        add(createTopPanel(), BorderLayout.NORTH);
        add(createTablesPanel(), BorderLayout.CENTER);
        add(createBottomPanel(), BorderLayout.SOUTH);

        attachActionListeners();
        populateLoadProjectComboBox();
    }
    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setOpaque(false);
        JPanel urlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        urlPanel.setOpaque(false);
        urlPanel.add(new JLabel("URL:"));
        urlPanel.add(urlField);
        urlPanel.add(scrapeButton);
        urlPanel.add(browseButton);
        JPanel loginCheckPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        loginCheckPanel.setOpaque(false);
        loginCheckPanel.add(loginCheckBox);
        topPanel.add(urlPanel);
        topPanel.add(loginCheckPanel);
        topPanel.add(loginPanel);
        return topPanel;
    }
    private JPanel createLoginPanel() {
        JPanel mainLoginPanel = new JPanel();
        mainLoginPanel.setLayout(new BoxLayout(mainLoginPanel, BoxLayout.Y_AXIS));
        mainLoginPanel.setBorder(BorderFactory.createTitledBorder("Selenium Login Configuration"));
        mainLoginPanel.setVisible(false);
        JPanel configPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton saveConfigBtn = createModernButton("Save Config", BUTTON_COLOR);
        JButton newConfigBtn = createModernButton("New Config", BUTTON_COLOR);
        configPanel.add(new JLabel("Config:"));
        configPanel.add(configComboBox);
        configPanel.add(saveConfigBtn);
        configPanel.add(newConfigBtn);
        saveConfigBtn.addActionListener(e -> saveCurrentConfig());
        newConfigBtn.addActionListener(e -> createNewConfig());
        JPanel locatorsPanel = new JPanel(new GridLayout(0, 3, 5, 5));
        locatorsPanel.setBorder(BorderFactory.createTitledBorder("Step 1: Define Locators"));
        locatorsPanel.add(new JLabel("Username Field:"));
        locatorsPanel.add(userLocatorType);
        locatorsPanel.add(userLocatorPath);
        locatorsPanel.add(new JLabel("Password Field:"));
        locatorsPanel.add(passLocatorType);
        locatorsPanel.add(passLocatorPath);
        locatorsPanel.add(new JLabel("Login Button:"));
        locatorsPanel.add(submitLocatorType);
        locatorsPanel.add(submitLocatorPath);
        JPanel credentialsPanel = new JPanel(new BorderLayout(10,10));
        credentialsPanel.setBorder(BorderFactory.createTitledBorder("Step 2: Enter Credentials & Login"));
        JPanel fieldsGrid = new JPanel(new GridLayout(0, 2, 5, 5));
        fieldsGrid.add(new JLabel("Username:"));
        fieldsGrid.add(usernameField);
        fieldsGrid.add(new JLabel("Password:"));
        fieldsGrid.add(passwordField);
        JButton loginBtn = createModernButton("Login with Selenium", SUCCESS_COLOR);
        loginBtn.addActionListener(e -> performSeleniumLogin());
        credentialsPanel.add(fieldsGrid, BorderLayout.CENTER);
        credentialsPanel.add(loginBtn, BorderLayout.SOUTH);
        mainLoginPanel.add(configPanel);
        mainLoginPanel.add(locatorsPanel);
        mainLoginPanel.add(credentialsPanel);
        return mainLoginPanel;
    }
    private JSplitPane createTablesPanel() {
        selectAllCheckBox = new JCheckBox();
        JTable resultsTable = createModernTable(tableModel);
        TableColumn selectColumn = resultsTable.getColumnModel().getColumn(0);
        selectColumn.setMinWidth(40);
        selectColumn.setMaxWidth(40);
        selectColumn.setHeaderRenderer((t, v, isS, hasF, r, c) -> selectAllCheckBox);
        JPanel storedPanel = new JPanel(new BorderLayout());

        JPanel storedHeader = new JPanel(new BorderLayout());
        storedHeader.add(createSectionHeader("Stored Project"), BorderLayout.WEST);

        JPanel projectLoaderPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        projectLoaderPanel.add(new JLabel("Load Project:"));
        projectLoaderPanel.add(projectLoaderComboBox);
        JButton loadProjectButton = createModernButton("Load", BUTTON_COLOR);
        loadProjectButton.addActionListener(e -> loadProjectFromFile());
        projectLoaderPanel.add(loadProjectButton);

        JButton deleteProjectButton = createModernButton("Delete", DANGER_COLOR);
        deleteProjectButton.addActionListener(e -> deleteSelectedProject());
        projectLoaderPanel.add(deleteProjectButton);

        storedHeader.add(projectLoaderPanel, BorderLayout.EAST);

        storedPanel.add(storedHeader, BorderLayout.NORTH);

        JSplitPane storedSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                new JScrollPane(storedElementsTree),
                new JScrollPane(storedElementDetailPane));
        storedSplitPane.setResizeWeight(0.4);
        storedPanel.add(storedSplitPane, BorderLayout.CENTER);
        JPanel storedButtonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveBtn = createModernButton("Save Project", SUCCESS_COLOR);
        JButton addBtn = createModernButton("Add...", BUTTON_COLOR);
        JButton editBtn = createModernButton("Edit...", BUTTON_COLOR);
        JButton deleteBtn = createModernButton("Delete Item", BUTTON_COLOR);

        // MODIFIED: Set all move buttons to disabled initially
        moveUpButton.setEnabled(false);
        moveDownButton.setEnabled(false);
        moveCollectionUpButton.setEnabled(false);
        moveCollectionDownButton.setEnabled(false);

        // MODIFIED: Add all move buttons to the panel
        storedButtonsPanel.add(moveCollectionUpButton);
        storedButtonsPanel.add(moveCollectionDownButton);
        storedButtonsPanel.add(moveUpButton);
        storedButtonsPanel.add(moveDownButton);
        storedButtonsPanel.add(new JSeparator(SwingConstants.VERTICAL));
        storedButtonsPanel.add(saveBtn);
        storedButtonsPanel.add(addBtn);
        storedButtonsPanel.add(editBtn);
        storedButtonsPanel.add(deleteBtn);

        saveBtn.addActionListener(e -> saveProjectToFile());
        addBtn.addActionListener(e -> handleAddAction());
        editBtn.addActionListener(e -> handleEditAction());
        deleteBtn.addActionListener(e -> handleDeleteAction());
        moveUpButton.addActionListener(e -> handleMoveAction(true));
        moveDownButton.addActionListener(e -> handleMoveAction(false));

        // NEW: Add action listeners for collection move buttons
        moveCollectionUpButton.addActionListener(e -> handleMoveCollectionAction(true));
        moveCollectionDownButton.addActionListener(e -> handleMoveCollectionAction(false));

        storedPanel.add(storedButtonsPanel, BorderLayout.SOUTH);
        JPanel resultsPanel = new JPanel(new BorderLayout());
        resultsPanel.add(createSectionHeader("Current Scrape Results"), BorderLayout.NORTH);
        resultsPanel.add(new JScrollPane(resultsTable), BorderLayout.CENTER);
        JSplitPane mainSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, storedPanel, resultsPanel);
        mainSplitPane.setResizeWeight(0.5);
        return mainSplitPane;
    }
    private JPanel createBottomPanel() {
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 0));
        statusLabel.setFont(SANS_SERIF_14);
        progressBar.setVisible(false);

        JPanel actionButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton storeBtn = createModernButton("Store Selected", BUTTON_COLOR);
        JButton clearBtn = createModernButton("Clear Project", DANGER_COLOR);
        JButton exportBtn = createModernButton("Export Stored", BUTTON_COLOR);

        storeBtn.addActionListener(e -> storeSelectedRows());
        clearBtn.addActionListener(e -> clearStoredProject());
        exportBtn.addActionListener(e -> exportStoredToCSV());
        actionButtonPanel.add(storeBtn);
        actionButtonPanel.add(clearBtn);
        actionButtonPanel.add(exportBtn);
        bottomPanel.add(statusLabel, BorderLayout.WEST);
        bottomPanel.add(progressBar, BorderLayout.CENTER);
        bottomPanel.add(actionButtonPanel, BorderLayout.EAST);
        return bottomPanel;
    }

    private void attachActionListeners() {
        scrapeButton.addActionListener(e -> scrapeSource());
        browseButton.addActionListener(e -> browseForFile());
        configComboBox.addActionListener(e -> loadSelectedConfig());
        loginCheckBox.addActionListener(e -> {
            loginPanel.setVisible(loginCheckBox.isSelected());
            Window ancestor = SwingUtilities.getWindowAncestor(this);
            if (ancestor != null) {
                ancestor.pack();
            }
        });
        selectAllCheckBox.addActionListener(e -> {
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                tableModel.setValueAt(selectAllCheckBox.isSelected(), i, 0);
            }
        });

        // MODIFIED: Updated tree selection listener to handle both elements and collections
        storedElementsTree.addTreeSelectionListener(e -> {
            DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) storedElementsTree.getLastSelectedPathComponent();

            // Disable all move buttons by default
            moveUpButton.setEnabled(false);
            moveDownButton.setEnabled(false);
            moveCollectionUpButton.setEnabled(false);
            moveCollectionDownButton.setEnabled(false);

            if (selectedNode == null) {
                storedElementDetailPane.setText("<html><i>Select an item to see its details.</i></html>");
                return;
            }

            // Check if a leaf node (element) is selected
            if (selectedNode.isLeaf() && (selectedNode.getUserObject() instanceof Object[])) {
                Object[] data = (Object[]) selectedNode.getUserObject();
                displayStoredElementDetails(data);

                DefaultMutableTreeNode parent = (DefaultMutableTreeNode) selectedNode.getParent();
                if (parent != null && !parent.isRoot()) {
                    int index = parent.getIndex(selectedNode);
                    if (index > 0) moveUpButton.setEnabled(true);
                    if (index < parent.getChildCount() - 1) moveDownButton.setEnabled(true);
                }
            }
            // Check if a collection node is selected
            else if (!selectedNode.isLeaf() && selectedNode.getParent() == rootNode) {
                int index = rootNode.getIndex(selectedNode);
                if (index > 0) moveCollectionUpButton.setEnabled(true);
                if (index < rootNode.getChildCount() - 1) moveCollectionDownButton.setEnabled(true);
                storedElementDetailPane.setText("<html><i>Select an element to see its details.</i></html>");
            }
            // Otherwise, clear details
            else {
                storedElementDetailPane.setText("<html><i>Select an element to see its details.</i></html>");
            }
        });
    }
    private void refreshStoredTree() {
        TreePath lastSelectedPath = storedElementsTree.getSelectionPath();
        rootNode.removeAllChildren();
        rootNode.setUserObject(currentProjectName != null ? "Project: " + currentProjectName : "No Project Loaded");
        for (Map.Entry<String, List<Object[]>> entry : projectCollections.entrySet()) {
            String collectionName = entry.getKey();
            List<Object[]> elements = entry.getValue();
            CollectionNodeData nodeData = new CollectionNodeData(collectionName, elements.size());
            DefaultMutableTreeNode collectionNode = new DefaultMutableTreeNode(nodeData);
            for (Object[] elementData : elements) {
                DefaultMutableTreeNode leafNode = new DefaultMutableTreeNode(elementData);
                collectionNode.add(leafNode);
            }
            rootNode.add(collectionNode);
        }
        treeModel.reload();
        expandAllTreeNodes();

        if(lastSelectedPath != null){
            storedElementsTree.setSelectionPath(lastSelectedPath);
        }

        storedElementsTree.setCellRenderer(new DefaultTreeCellRenderer() {
            @Override
            public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
                super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
                Object userObject = ((DefaultMutableTreeNode) value).getUserObject();
                if (userObject instanceof CollectionNodeData) {
                    setText(userObject.toString());
                } else if (leaf && userObject instanceof Object[]) {
                    setText(((Object[]) userObject)[0].toString());
                }
                return this;
            }
        });
    }

    private void expandAllTreeNodes() {
        for (int i = 0; i < storedElementsTree.getRowCount(); i++) {
            storedElementsTree.expandRow(i);
        }
    }
    private void storeSelectedRows() {
        List<Integer> selectedRowIndices = new ArrayList<>();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((Boolean) tableModel.getValueAt(i, 0)) {
                selectedRowIndices.add(i);
            }
        }
        if (selectedRowIndices.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No rows selected to store.", "Nothing Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String collectionName;
        if (currentProjectName == null) {
            JTextField projectField = new JTextField();
            JTextField collectionField = new JTextField();
            JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
            panel.add(new JLabel("Enter New Project Name:"));
            panel.add(projectField);
            panel.add(new JLabel("Enter First Collection Name:"));
            panel.add(collectionField);
            int result = JOptionPane.showConfirmDialog(this, panel, "Create New Project", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result == JOptionPane.OK_OPTION) {
                String projectName = projectField.getText().trim();
                collectionName = collectionField.getText().trim();
                if (projectName.isEmpty() || collectionName.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Project and Collection names cannot be empty.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                this.currentProjectName = projectName;
            } else {
                return;
            }
        } else {
            JComboBox<String> existingCollections = new JComboBox<>(projectCollections.keySet().toArray(new String[0]));
            JTextField newCollectionField = new JTextField();
            JRadioButton useExistingRadio = new JRadioButton("Use Existing Collection", projectCollections.size() > 0);
            JRadioButton createNewRadio = new JRadioButton("Create New Collection", projectCollections.isEmpty());
            ButtonGroup group = new ButtonGroup();
            group.add(useExistingRadio);
            group.add(createNewRadio);
            useExistingRadio.addActionListener(e -> {
                existingCollections.setEnabled(true);
                newCollectionField.setEnabled(false);
            });
            createNewRadio.addActionListener(e -> {
                existingCollections.setEnabled(false);
                newCollectionField.setEnabled(true);
            });

            existingCollections.setEnabled(useExistingRadio.isSelected());
            newCollectionField.setEnabled(createNewRadio.isSelected());
            JPanel panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST; gbc.insets = new Insets(2,2,2,2);
            panel.add(useExistingRadio, gbc);
            gbc.gridx = 1; panel.add(existingCollections, gbc);
            gbc.gridy = 1; gbc.gridx = 0; panel.add(createNewRadio, gbc);
            gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; panel.add(newCollectionField, gbc);
            int result = JOptionPane.showConfirmDialog(this, panel, "Select or Create Collection", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result == JOptionPane.OK_OPTION) {
                if (useExistingRadio.isSelected()) {
                    collectionName = (String) existingCollections.getSelectedItem();
                } else {
                    collectionName = newCollectionField.getText().trim();
                }
                if (collectionName == null || collectionName.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Collection name cannot be empty.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } else {
                return;
            }
        }
        List<Object[]> collectionList = projectCollections.computeIfAbsent(collectionName, k -> new ArrayList<>());
        for (int i = selectedRowIndices.size() - 1; i >= 0; i--) {
            int rowIndex = selectedRowIndices.get(i);
            Object[] rowData = new Object[tableModel.getColumnCount() - 1];
            for(int j = 1; j < tableModel.getColumnCount(); j++) {
                rowData[j-1] = tableModel.getValueAt(rowIndex, j);
            }
            collectionList.add(rowData);
            tableModel.removeRow(rowIndex);
        }
        refreshStoredTree();
    }

    private void displayStoredElementDetails(Object[] data) {
        if (data == null || data.length < 6) return;
        String[] headers = {"Element Name", "Absolute XPath", "Relative XPath", "ID", "Tag", "Attributes"};
        StringBuilder html = new StringBuilder("<html><body style='font-family:SansSerif; font-size:10pt;'>");
        for (int i = 0; i < data.length; i++) {
            html.append("<b>").append(headers[i]).append(":</b> ");
            html.append(escapeHtml(data[i])).append("<br>");
        }
        html.append("</body></html>");
        storedElementDetailPane.setText(html.toString());
        storedElementDetailPane.setCaretPosition(0);
    }

    private String escapeHtml(Object obj) {
        if (obj == null) return "";
        return obj.toString().replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
    private void clearStoredProject() {
        if (currentProjectName == null) {
            JOptionPane.showMessageDialog(this, "There is no project to clear.", "Project Empty", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to clear the entire project '" + currentProjectName + "'?",
                "Confirm Clear Project", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (choice == JOptionPane.YES_OPTION) {
            projectCollections.clear();
            currentProjectName = null;
            refreshStoredTree();
            statusLabel.setText("Project cleared.");
        }
    }
    private void exportStoredToCSV() {
        if (currentProjectName == null || projectCollections.isEmpty()) {
            JOptionPane.showMessageDialog(this, "There is no stored data to export.", "Export Empty", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Stored Project as CSV");
        fileChooser.setFileFilter(new FileNameExtensionFilter("CSV Files", "csv"));
        fileChooser.setSelectedFile(new File(currentProjectName.replaceAll("[^a-zA-Z0-9.-]", "_") + ".csv"));

        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (FileWriter writer = new FileWriter(file)) {
                String[] headers = {"Project","Collection","Element Name","Absolute XPath","Relative XPath","ID","Tag","Attributes"};
                writer.write(String.join(",", headers) + "\n");

                for (Map.Entry<String, List<Object[]>> entry : projectCollections.entrySet()) {
                    String collectionName = entry.getKey();
                    for (Object[] rowData : entry.getValue()) {
                        writer.write("\"" + escapeCsv(currentProjectName) + "\",");
                        writer.write("\"" + escapeCsv(collectionName) + "\",");
                        for (int i = 0; i < rowData.length; i++) {
                            writer.write("\"" + escapeCsv(rowData[i]) + (i == rowData.length - 1 ? "" : ",") + "\"");
                        }
                        writer.write("\n");
                    }
                }
                JOptionPane.showMessageDialog(this, "Stored project exported successfully!", "Export Complete", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error exporting file: " + ex.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void handleAddAction() {
        if (currentProjectName == null) {
            JOptionPane.showMessageDialog(this, "Please create or load a project first.", "No Project", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String[] options = {"New Element", "New Collection"};
        int choice = JOptionPane.showOptionDialog(this, "What would you like to add to the project?", "Add Item",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
        if (choice == 1) { // New Collection
            String newCollectionName = JOptionPane.showInputDialog(this, "Enter name for the new collection:");
            if (newCollectionName != null && !newCollectionName.trim().isEmpty()) {
                projectCollections.putIfAbsent(newCollectionName.trim(), new ArrayList<>());
                refreshStoredTree();
            }
        } else if (choice == 0) { // New Element
            if (projectCollections.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please create a collection first before adding an element.", "No Collections", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String[] existingCollections = projectCollections.keySet().toArray(new String[0]);
            String targetCollection = (String) JOptionPane.showInputDialog(this,
                    "Select the collection for the new element:", "Select Collection",
                    JOptionPane.PLAIN_MESSAGE, null, existingCollections, existingCollections[0]);

            if (targetCollection != null && !targetCollection.isEmpty()) {
                showElementDialog(null, targetCollection);
            }
        }
    }
    private void handleEditAction() {
        TreePath selectionPath = storedElementsTree.getSelectionPath();
        if (selectionPath == null) {
            JOptionPane.showMessageDialog(this, "Please select an item to edit.", "Nothing Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) selectionPath.getLastPathComponent();
        DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode) selectedNode.getParent();
        // Handle collection renaming
        if (parentNode != null && parentNode.isRoot() && !selectedNode.isLeaf()) {
            CollectionNodeData data = (CollectionNodeData) selectedNode.getUserObject();
            String oldName = data.name;
            String newName = JOptionPane.showInputDialog(this, "Enter new name for collection:", oldName);
            if (newName != null && !newName.trim().isEmpty() && !newName.trim().equals(oldName)) {
                if (projectCollections.containsKey(newName.trim())) {
                    JOptionPane.showMessageDialog(this, "A collection with this name already exists.", "Duplicate Name", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                List<Object[]> dataList = projectCollections.remove(oldName);
                projectCollections.put(newName.trim(), dataList);
                data.name = newName.trim();
                treeModel.nodeChanged(selectedNode);
            }
        }
        // Handle element editing
        else if (selectedNode.isLeaf()) {
            Object[] data = (Object[]) selectedNode.getUserObject();
            String collectionName = ((CollectionNodeData) parentNode.getUserObject()).name;
            showElementDialog(data, collectionName);
        }
    }

    private void handleDeleteAction() {
        TreePath selectionPath = storedElementsTree.getSelectionPath();
        if (selectionPath == null) {
            JOptionPane.showMessageDialog(this, "Please select an item to delete.", "Nothing Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) selectionPath.getLastPathComponent();
        DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode) selectedNode.getParent();

        // Handle collection deletion
        if (parentNode != null && parentNode.isRoot() && !selectedNode.isLeaf()) {
            CollectionNodeData data = (CollectionNodeData) selectedNode.getUserObject();
            String collectionName = data.name;

            int choice = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete collection '" + collectionName + "'?",
                    "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

            if (choice == JOptionPane.YES_OPTION) {
                projectCollections.remove(collectionName);
                treeModel.removeNodeFromParent(selectedNode);
                refreshStoredTree();
            }
        }
        // Handle element deletion
        else if (selectedNode.isLeaf()) {
            Object userObject = selectedNode.getUserObject();
            if (userObject instanceof Object[]) {
                Object[] data = (Object[]) userObject;
                String elementName = data[0].toString();

                int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete '" + elementName + "'?",
                        "Confirm Deletion", JOptionPane.YES_NO_OPTION);

                if (choice == JOptionPane.YES_OPTION) {
                    if (parentNode != null) {
                        CollectionNodeData collectionData = (CollectionNodeData) parentNode.getUserObject();
                        String collectionName = collectionData.name;
                        List<Object[]> elements = projectCollections.get(collectionName);
                        if (elements != null) {
                            elements.remove(userObject);
                            collectionData.count = elements.size();

                            // Remove element node from tree
                            treeModel.removeNodeFromParent(selectedNode);

                            // Check if collection is now empty
                            if (elements.isEmpty()) {
                                // Delete the collection too
                                projectCollections.remove(collectionName);
                                treeModel.removeNodeFromParent(parentNode);
                            } else {
                                // Update collection node display
                                treeModel.nodeChanged(parentNode);
                            }
                        }
                    }
                }
            }
        }
        // Handle root node case
        else if (selectedNode.isRoot()) {
            JOptionPane.showMessageDialog(this, "Cannot delete the project root. Use 'Clear Project' instead.",
                    "Action Not Allowed", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void handleMoveAction(boolean moveUp) {
        TreePath selectionPath = storedElementsTree.getSelectionPath();
        if (selectionPath == null) return;

        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) selectionPath.getLastPathComponent();
        if (!selectedNode.isLeaf()) return;
        DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode) selectedNode.getParent();
        int currentIndex = parentNode.getIndex(selectedNode);

        int newIndex = moveUp ? currentIndex - 1 : currentIndex + 1;
        if (newIndex < 0 || newIndex >= parentNode.getChildCount()) return;
        CollectionNodeData collectionData = (CollectionNodeData) parentNode.getUserObject();
        String collectionName = collectionData.name;
        List<Object[]> elements = projectCollections.get(collectionName);
        if (elements != null) {
            Object[] dataToMove = (Object[]) selectedNode.getUserObject();
            int dataIndex = elements.indexOf(dataToMove);

            if (dataIndex != -1) {
                int newModelIndex = moveUp ? dataIndex - 1 : dataIndex + 1;
                 if (newModelIndex >= 0 && newModelIndex < elements.size()) {
                    Collections.swap(elements, dataIndex, newModelIndex);
                }
            }
        }

        refreshStoredTree();

        // Reselect the moved node
        TreePath newPath = new TreePath(parentNode.getPath()).pathByAddingChild(selectedNode);
        storedElementsTree.setSelectionPath(newPath);
        storedElementsTree.scrollPathToVisible(newPath);
    }

    // NEW: Method to handle moving a collection up or down
    private void handleMoveCollectionAction(boolean moveUp) {
        TreePath selectionPath = storedElementsTree.getSelectionPath();
        if (selectionPath == null) return;

        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) selectionPath.getLastPathComponent();
        // Ensure it's a collection node (not a leaf, parent is root)
        if (selectedNode.isLeaf() || selectedNode.getParent() != rootNode) return;

        int currentIndex = rootNode.getIndex(selectedNode);
        int newIndex = moveUp ? currentIndex - 1 : currentIndex + 1;

        if (newIndex < 0 || newIndex >= rootNode.getChildCount()) return;

        // Get the name of the collection to move
        CollectionNodeData nodeData = (CollectionNodeData) selectedNode.getUserObject();
        String collectionNameToMove = nodeData.name;

        // Convert the LinkedHashMap entries to a List to reorder them
        List<Map.Entry<String, List<Object[]>>> entries = new ArrayList<>(projectCollections.entrySet());

        // Find the index of the collection to move in the list
        int modelIndex = -1;
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).getKey().equals(collectionNameToMove)) {
                modelIndex = i;
                break;
            }
        }

        if (modelIndex == -1) return; // Should not happen if UI and data are in sync

        // Swap the entry with its neighbor
        Collections.swap(entries, modelIndex, moveUp ? modelIndex - 1 : modelIndex + 1);

        // Create a new LinkedHashMap with the new order
        Map<String, List<Object[]>> reorderedMap = new LinkedHashMap<>();
        for (Map.Entry<String, List<Object[]>> entry : entries) {
            reorderedMap.put(entry.getKey(), entry.getValue());
        }

        // Replace the old map with the reordered one
        projectCollections.clear();
        projectCollections.putAll(reorderedMap);

        // Refresh the tree and re-select the moved node
        refreshStoredTree();
        TreePath newPath = new TreePath(rootNode).pathByAddingChild(selectedNode);
        storedElementsTree.setSelectionPath(newPath);
        storedElementsTree.scrollPathToVisible(newPath);
    }

    private void showElementDialog(Object[] existingData, String collectionName) {
        String[] headers = {"Element Name", "Absolute XPath", "Relative XPath", "ID", "Tag", "Attributes"};
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        JTextField[] fields = new JTextField[headers.length];
        for (int i = 0; i < headers.length; i++) {
            panel.add(new JLabel(headers[i] + ":"));
            fields[i] = new JTextField(30);
            if (existingData != null && existingData.length > i) {
                fields[i].setText(existingData[i] != null ? existingData[i].toString() : "");
            }
            panel.add(fields[i]);
        }
        String title = (existingData == null) ? "Add New Element to '" + collectionName + "'" : "Edit Element";
        int result = JOptionPane.showConfirmDialog(this, panel, title, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            Object[] newData = new Object[headers.length];
            for (int i = 0; i < headers.length; i++) {
                newData[i] = fields[i].getText();
            }

            List<Object[]> elements = projectCollections.computeIfAbsent(collectionName, k -> new ArrayList<>());

            if(existingData != null) {
                 int index = -1;
                 for(int i=0; i<elements.size(); i++){
                     if(elements.get(i) == existingData){
                         index = i;
                         break;
                     }
                 }
                 if(index != -1){
                     elements.set(index, newData);
                 }
            } else {
                 elements.add(newData);
            }
            refreshStoredTree();
        }
    }

    // MODIFIED: Save project using a JSONArray for collections to preserve order
    private void saveProjectToFile() {
        if (currentProjectName == null || projectCollections.isEmpty()) {
            JOptionPane.showMessageDialog(this, "There is no project data to save.", "Save Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        File execDir = new File("executionList");
        if (!execDir.exists()) {
            execDir.mkdirs();
        }
        File saveFile = new File(execDir, currentProjectName + ".json");

        JSONObject projectJson = new JSONObject();
        projectJson.put("projectName", currentProjectName);

        // Use a JSONArray to store collections, which preserves their order
        JSONArray collectionsArray = new JSONArray();
        for (Map.Entry<String, List<Object[]>> entry : projectCollections.entrySet()) {
            JSONObject collectionObj = new JSONObject();
            collectionObj.put("collectionName", entry.getKey());

            JSONArray elementsArray = new JSONArray();
            for (Object[] elementData : entry.getValue()) {
                elementsArray.put(new JSONArray(elementData));
            }
            collectionObj.put("elements", elementsArray);
            collectionsArray.put(collectionObj);
        }
        projectJson.put("collections", collectionsArray);

        try (FileWriter writer = new FileWriter(saveFile)) {
            writer.write(projectJson.toString(4)); // Indented for readability
            JOptionPane.showMessageDialog(this, "Project '" + currentProjectName + "' saved successfully!", "Save Complete", JOptionPane.INFORMATION_MESSAGE);
            populateLoadProjectComboBox();
            if (dashboard != null) {
                dashboard.onProjectListChanged();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving project: " + e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    void populateLoadProjectComboBox() {
        projectLoaderComboBox.removeAllItems();
        File execDir = new File("executionList");
        if (execDir.exists() && execDir.isDirectory()) {
            File[] files = execDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".json"));
            if (files != null) {
                for (File file : files) {
                    projectLoaderComboBox.addItem(file.getName().replace(".json", ""));
                }
            }
        }
    }

    // MODIFIED: Load project handling both old and new (ordered) JSON formats
    private void loadProjectFromFile() {
        String selectedProject = (String) projectLoaderComboBox.getSelectedItem();
        if (selectedProject == null) {
            JOptionPane.showMessageDialog(this, "No project selected to load.", "Load Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        File projectFile = new File("executionList", selectedProject + ".json");
        try {
            String content = new String(Files.readAllBytes(Paths.get(projectFile.toURI())));
            JSONObject projectJson = new JSONObject(content);

            this.projectCollections.clear();
            this.currentProjectName = projectJson.getString("projectName");

            // Check if the file uses the new ordered array format or the old object format
            if (projectJson.get("collections") instanceof JSONArray) {
                // New format: "collections" is a JSONArray, which preserves order
                JSONArray collectionsArray = projectJson.getJSONArray("collections");
                for (int i = 0; i < collectionsArray.length(); i++) {
                    JSONObject collectionObj = collectionsArray.getJSONObject(i);
                    String collectionName = collectionObj.getString("collectionName");
                    JSONArray elementsArray = collectionObj.getJSONArray("elements");

                    List<Object[]> elementList = new ArrayList<>();
                    for (int j = 0; j < elementsArray.length(); j++) {
                        JSONArray elementJson = elementsArray.getJSONArray(j);
                        Object[] elementData = new Object[elementJson.length()];
                        for (int k = 0; k < elementJson.length(); k++) {
                            elementData[k] = elementJson.optString(k, "");
                        }
                        elementList.add(elementData);
                    }
                    this.projectCollections.put(collectionName, elementList);
                }
            } else {
                // Old format (for backward compatibility): "collections" is a JSONObject
                JSONObject collectionsJson = projectJson.getJSONObject("collections");
                Iterator<String> keys = collectionsJson.keys();
                while(keys.hasNext()) {
                    String collectionName = keys.next();
                    JSONArray elementsArray = collectionsJson.getJSONArray(collectionName);
                    List<Object[]> elementList = new ArrayList<>();
                    for (int i = 0; i < elementsArray.length(); i++) {
                        JSONArray elementJson = elementsArray.getJSONArray(i);
                        Object[] elementData = new Object[elementJson.length()];
                        for (int j = 0; j < elementJson.length(); j++) {
                            elementData[j] = elementJson.optString(j, "");
                        }
                        elementList.add(elementData);
                    }
                    this.projectCollections.put(collectionName, elementList);
                }
            }

            refreshStoredTree();
            JOptionPane.showMessageDialog(this, "Project '" + currentProjectName + "' loaded successfully.", "Load Complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException | org.json.JSONException e) {
            JOptionPane.showMessageDialog(this, "Error loading project: " + e.getMessage(), "Load Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void deleteSelectedProject() {
        String selectedProject = (String) projectLoaderComboBox.getSelectedItem();
        if (selectedProject == null) {
            JOptionPane.showMessageDialog(this, "No project selected to delete.", "Delete Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to permanently delete project '" + selectedProject + "'?\nThis action cannot be undone.",
                "Confirm Project Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (choice == JOptionPane.YES_OPTION) {
            File projectFile = new File("executionList", selectedProject + ".json");
            if (projectFile.exists()) {
                if (projectFile.delete()) {
                    JOptionPane.showMessageDialog(this, "Project '" + selectedProject + "' has been deleted.", "Delete Successful", JOptionPane.INFORMATION_MESSAGE);
                    if (selectedProject.equals(currentProjectName)) {
                        clearStoredProject();
                    }
                    populateLoadProjectComboBox();
                    if (dashboard != null) {
                        dashboard.onProjectListChanged();
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Could not delete the project file.", "Delete Failed", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                 JOptionPane.showMessageDialog(this, "Project file not found.", "Delete Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void loadConfigurations() {
        try {
            String[] keys = prefs.keys();
            for (String key : keys) {
                if (key.startsWith("loginConfig_")) {
                    String name = key.substring("loginConfig_".length());
                    String configData = prefs.get(key, "");
                    String[] parts = configData.split("\\|", -1);
                    if (parts.length == 8) {
                        loginConfigs.put(name, new LoginConfig(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6], parts[7]));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void saveConfigurations() {
        try {
            for (Map.Entry<String, LoginConfig> entry : loginConfigs.entrySet()) {
                LoginConfig config = entry.getValue();
                String data = String.join("|",
                    config.userLocatorType, config.userLocatorPath,
                    config.passLocatorType, config.passLocatorPath,
                    config.submitLocatorType, config.submitLocatorPath,
                    config.username, config.password
                );
                prefs.put("loginConfig_" + entry.getKey(), data);
            }
            prefs.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void refreshConfigComboBox() {
        String selectedItem = (String) configComboBox.getSelectedItem();
        configComboBox.removeAllItems();
        for(String name : loginConfigs.keySet()) {
            configComboBox.addItem(name);
        }
        configComboBox.setSelectedItem(selectedItem);
    }
    private void loadSelectedConfig() {
        String selected = (String) configComboBox.getSelectedItem();
        if (selected != null && loginConfigs.containsKey(selected)) {
            LoginConfig config = loginConfigs.get(selected);
            userLocatorType.setSelectedItem(config.userLocatorType);
            userLocatorPath.setText(config.userLocatorPath);
            passLocatorType.setSelectedItem(config.passLocatorType);
            passLocatorPath.setText(config.passLocatorPath);
            submitLocatorType.setSelectedItem(config.submitLocatorType);
            submitLocatorPath.setText(config.submitLocatorPath);
            usernameField.setText(config.username);
            passwordField.setText(config.password);
        }
    }
    private void saveCurrentConfig() {
        String selected = (String) configComboBox.getSelectedItem();
        if (selected == null || selected.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No configuration selected.", "Save Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        LoginConfig currentConfig = new LoginConfig(
            (String)userLocatorType.getSelectedItem(), userLocatorPath.getText(),
            (String)passLocatorType.getSelectedItem(), passLocatorPath.getText(),
            (String)submitLocatorType.getSelectedItem(), submitLocatorPath.getText(),
            usernameField.getText(), new String(passwordField.getPassword())
        );
        loginConfigs.put(selected, currentConfig);
        saveConfigurations();
        JOptionPane.showMessageDialog(this, "Configuration '" + selected + "' saved!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    private void createNewConfig() {
        String configName = JOptionPane.showInputDialog(this, "Enter new configuration name:");
        if (configName != null && !configName.trim().isEmpty()) {
            configName = configName.trim();
            if (loginConfigs.containsKey(configName)) {
                JOptionPane.showMessageDialog(this, "This name already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            LoginConfig newConfig = new LoginConfig("ID", "username", "ID", "password", "XPath", "//button[@type='submit']", "", "");
            loginConfigs.put(configName, newConfig);
            saveConfigurations();
            refreshConfigComboBox();
            configComboBox.setSelectedItem(configName);
            loadSelectedConfig();
        }
    }
    private void performSeleniumLogin() {
        setAllButtonsEnabled(false);
        statusLabel.setText("Selenium starting...");
        progressBar.setIndeterminate(true);
        progressBar.setVisible(true);
        SwingWorker<Map<String, String>, String> worker = new SwingWorker<Map<String, String>, String>() {
            @Override
            protected Map<String, String> doInBackground() throws Exception {
                publish("Initializing WebDriver...");
               // WebDriverManager.chromedriver().setup();

                ChromeOptions options = new ChromeOptions();
                options.addArguments("--headless", "--disable-gpu", "--window-size=1920,1080");
                options.addArguments("--allow-insecure-localhost", "--ignore-certificate-errors", "--no-sandbox", "--disable-dev-shm-usage");

                WebDriver driver = null;
                try {
                    driver = new ChromeDriver(options);
                    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
                    publish("Navigating to URL...");
                    driver.get(urlField.getText().trim());
                    publish("Locating elements...");
                    WebElement userEl = findElementWithSelenium(driver, (String)userLocatorType.getSelectedItem(), userLocatorPath.getText());
                    userEl.sendKeys(usernameField.getText());
                    WebElement passEl = findElementWithSelenium(driver, (String)passLocatorType.getSelectedItem(), passLocatorPath.getText());
                    passEl.sendKeys(new String(passwordField.getPassword()));
                    publish("Clicking login button...");
                    WebElement submitEl = findElementWithSelenium(driver, (String)submitLocatorType.getSelectedItem(), submitLocatorPath.getText());
                    submitEl.click();

                    publish("Login submitted. Capturing session...");
                    Thread.sleep(2000);

                    Map<String, String> cookieMap = new HashMap<>();
                    for (org.openqa.selenium.Cookie cookie : driver.manage().getCookies()) {
                        cookieMap.put(cookie.getName(), cookie.getValue());
                    }
                    if (cookieMap.isEmpty()) {
                        throw new Exception("Login likely failed: No session cookies were captured.");
                    }

                    return cookieMap;
                } finally {
                    if (driver != null) {
                        driver.quit();
                    }
                }
            }

            @Override
            protected void process(List<String> chunks) {
                statusLabel.setText(chunks.get(chunks.size() - 1));
            }
            @Override
            protected void done() {
                try {
                    sessionCookies = get();
                    statusLabel.setText("Selenium Login Succeeded! Session is active.");
                } catch (Exception e) {
                    sessionCookies.clear();
                    statusLabel.setText("Selenium Login Failed.");
                    JOptionPane.showMessageDialog(Tool1Panel.this, "Login Failed:\n" + e.getCause().getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    progressBar.setIndeterminate(false);
                    progressBar.setVisible(false);
                    setAllButtonsEnabled(true);
                }
            }
        };
        worker.execute();
    }
    private WebElement findElementWithSelenium(WebDriver driver, String type, String path) {
        switch (type) {
            case "ID": return driver.findElement(By.id(path));
            case "Name": return driver.findElement(By.name(path));
            case "XPath": return driver.findElement(By.xpath(path));
            case "CSS Selector": return driver.findElement(By.cssSelector(path));
            case "Class Name": return driver.findElement(By.className(path));
            default: throw new IllegalArgumentException("Unsupported locator type: " + type);
        }
    }
    private void scrapeSource() {
        if (loginCheckBox.isSelected() && sessionCookies.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please Login with Selenium first.", "Authentication Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        setAllButtonsEnabled(false);
        statusLabel.setText("Scraping with Jsoup...");
        progressBar.setIndeterminate(true);
        progressBar.setVisible(true);
        tableModel.setRowCount(0);
        SwingWorker<Document, Void> worker = new SwingWorker<Document, Void>() {
            @Override
            protected Document doInBackground() throws Exception {
                String url = urlField.getText().trim();
                if (url.toLowerCase().startsWith("http")) {
                    return Jsoup.connect(url).cookies(sessionCookies).timeout(60000).get();
                } else {
                    return Jsoup.parse(new File(url), "UTF-8");
                }
            }
            @Override
            protected void done() {
                try {
                    Document doc = get();
                    Elements elements = doc.select("a, button, input, select, textarea, [onclick], [href]");
                    for (Element el : elements) {
                        if (isInteractableElement(el)) {
                            tableModel.addRow(new Object[]{ false, getFieldName(el), generateAbsoluteXPath(el), generateRelativeXPath(el), el.id(), el.tagName(), getKeyAttributes(el) });
                        }
                    }
                    statusLabel.setText("Scrape complete. Found " + tableModel.getRowCount() + " elements.");
                } catch (Exception e) {
                    statusLabel.setText("Error during scrape: " + e.getMessage());
                } finally {
                    progressBar.setIndeterminate(false);
                    progressBar.setVisible(false);
                    setAllButtonsEnabled(true);
                }
            }
        };
        worker.execute();
    }

    private void setAllButtonsEnabled(boolean enabled) {
        scrapeButton.setEnabled(enabled);
        browseButton.setEnabled(enabled);
        for(Component comp : loginPanel.getComponents()){
            if(comp instanceof JPanel){
                for(Component subComp : ((JPanel) comp).getComponents()){
                    if(subComp instanceof JButton){
                        subComp.setEnabled(enabled);
                    } else if (subComp instanceof JPanel) {
                         for(Component nestedComp : ((JPanel) subComp).getComponents()){
                             if(nestedComp instanceof JButton){
                                nestedComp.setEnabled(enabled);
                             }
                         }
                    }
                }
            }
        }
    }
    private void browseForFile() {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("HTML Files", "html", "htm"));
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            urlField.setText(fc.getSelectedFile().getAbsolutePath());
        }
    }

    private String getFieldName(Element el) {
        String name = el.attr("name");
        if (!name.isEmpty()) return "name: " + name;
        String id = el.id();
        if (!id.isEmpty()) return "id: " + id;
        String text = el.text().trim();
        if (!text.isEmpty()) return "text: " + (text.length() > 30 ? text.substring(0, 30) + "..." : text);
        return el.tagName();
    }
    private String getKeyAttributes(Element el) {
        StringBuilder attrs = new StringBuilder();
        if (el.hasAttr("class") && !el.attr("class").isEmpty()) attrs.append("class: ").append(el.attr("class")).append("; ");
        if (el.hasAttr("type") && !el.attr("type").isEmpty()) attrs.append("type: ").append(el.attr("type")).append("; ");
        if (el.hasAttr("href") && !el.attr("href").isEmpty()) attrs.append("href: ").append(el.attr("href")).append("; ");
        return attrs.toString();
    }
    private String generateAbsoluteXPath(Element element) {
        ArrayList<String> path = new ArrayList<>();
        for (Element el = element; el != null && el.parent() != null; el = el.parent()) {
            if (el.tagName().equals("#root")) continue;
            String segment = el.tagName();
            if (!el.tagName().equals("html")) {
                int index = 1;
                for (Element sibling : el.parent().children()) {
                    if (sibling.tagName().equals(el.tagName())) {
                        if (sibling == el) {
                            segment += "[" + index + "]";
                            break;
                        }
                        index++;
                    }
                }
            }
            path.add(segment);
        }
        Collections.reverse(path);
        return "/" + String.join("/", path);
    }
    private String generateRelativeXPath(Element element) {
        if (element.hasAttr("id") && !element.id().isEmpty()) return "//" + element.tagName() + "[@id='" + element.id() + "']";
        if (element.hasAttr("name") && !element.attr("name").isEmpty()) return "//" + element.tagName() + "[@name='" + element.attr("name") + "']";
        return generateAbsoluteXPath(element);
    }
    private boolean isInteractableElement(Element el) {
        String tag = el.tagName().toLowerCase();
        return (tag.matches("a|button|select|textarea") ||
               (tag.equals("input") && !el.attr("type").equalsIgnoreCase("hidden"))) &&
               !el.hasAttr("disabled");
    }
    private String escapeCsv(Object input) {
        if (input == null) return "";
        return input.toString().replace("\"", "\"\"");
    }

    private void initTrustAllCertificates() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() { return null; }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
            }};
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private JButton createModernButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { button.setBackground(bgColor.darker()); }
            @Override public void mouseExited(MouseEvent e) { button.setBackground(bgColor); }
        });
        return button;
    }
    private JTable createModernTable(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setOpaque(false);
        header.setBackground(new Color(240, 240, 240));
        return table;
    }
    private JPanel createSectionHeader(String title) {
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setOpaque(false);
        JLabel label = new JLabel(title);
        label.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label.setForeground(PRIMARY_COLOR);
        headerPanel.add(label);
        return headerPanel;
    }

    private static class ShadowBorder implements javax.swing.border.Border {
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setColor(new Color(0, 0, 0, 15));
            for(int i=0; i < 4; i++){
                g2d.drawRoundRect(x+i, y+i, w-i*2-1, h-i*2-1, 15, 15);
            }
            g2d.dispose();
        }
        public Insets getBorderInsets(Component c) { return new Insets(5, 5, 5, 5); }
        public boolean isBorderOpaque() { return false; }
    }

    private static class CollectionNodeData {
        String name;
        int count;
        CollectionNodeData(String name, int count) {
            this.name = name;
            this.count = count;
        }
        @Override
        public String toString() {
            return name + " (" + count + " items)";
        }
    }
}
class LoginConfig {
    String userLocatorType, userLocatorPath, passLocatorType, passLocatorPath,
           submitLocatorType, submitLocatorPath,
           username, password;
    public LoginConfig(String uType, String uPath, String pType, String pPath,
                       String sType, String sPath, String user, String pass) {
        this.userLocatorType = uType;
        this.userLocatorPath = uPath;
        this.passLocatorType = pType;
        this.passLocatorPath = pPath;
        this.submitLocatorType = sType;
        this.submitLocatorPath = sPath;
        this.username = user;
        this.password = pass;
    }
}