package TC_Automation.ITS;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Modern, sleek dashboard panel with a responsive UI.
 * This panel now loads Tool1Panel, Tool2Panel, and Tool5Panel, and facilitates communication between them.
 */
public class TestExecutionPanel extends JPanel {

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cardsPanel = new JPanel(cardLayout);
    private final List<JButton> toolButtons = new ArrayList<>();
    private String currentCardName = "WELCOME";

    // Keep references to the tool panels to facilitate communication
    private Tool1Panel tool1PanelInstance;
    private Tool2Panel tool2PanelInstance;
    private Tool5Panel tool5PanelInstance; // Instance for the new panel

    private final Color PRIMARY_COLOR = new Color(41, 128, 185);
    private final Color CARD_COLOR = Color.WHITE;
    private final Color HIGHLIGHT_COLOR = new Color(236, 240, 241);
    private final Color ACCENT_COLOR = new Color(46, 204, 113);
    private final Color BACKGROUND_COLOR = new Color(245, 245, 245);

    private final String[] toolNames = {
            "Execution Template Builder", "Execution Data Feeder", "DOM Comparator",
            "Form Field Analyzer", "Execution Rules", "Accessibility Checker",
            "Session Replay Tool", "Visual Regression Detector"
    };
    private final String[] toolIcons = {"🔍", "✓", "⇄", "📝", "⏱", "♿", "📼", "🖼"};

    public TestExecutionPanel(JPanel mainCardsPanel) {
        super(new GridBagLayout());
        setBackground(BACKGROUND_COLOR);
        setBorder(new EmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 3; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0; gbc.insets = new Insets(0, 0, 20, 0);
        add(createTopPanel(mainCardsPanel), gbc);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.VERTICAL; gbc.weightx = 0; gbc.weighty = 1.0; gbc.anchor = GridBagConstraints.PAGE_START; gbc.insets = new Insets(0, 0, 0, 10);
        add(createMenuPanel(0, 3), gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.fill = GridBagConstraints.BOTH; gbc.weightx = 1.0; gbc.weighty = 1.0; gbc.insets = new Insets(0, 0, 0, 10);
        setupCardPanel();
        add(cardsPanel, gbc);
        gbc.gridx = 2; gbc.gridy = 1; gbc.fill = GridBagConstraints.VERTICAL; gbc.weightx = 0; gbc.weighty = 1.0; gbc.anchor = GridBagConstraints.PAGE_START; gbc.insets = new Insets(0, 0, 0, 0);
        add(createMenuPanel(4, 7), gbc);
    }

    private JPanel createTopPanel(JPanel mainCardsPanel) {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        JButton backButton = createModernButton("← Back to Main");
        backButton.setPreferredSize(new Dimension(150, 40));
        backButton.addActionListener(e -> {
            CardLayout cl = (CardLayout) (mainCardsPanel.getLayout());
            cl.show(mainCardsPanel, "main");
            resetToWelcomeScreen();
        });
        JPanel backButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        backButtonPanel.setOpaque(false);
        backButtonPanel.add(backButton);
        topPanel.add(backButtonPanel, BorderLayout.WEST);

        JLabel titleLabel = new JLabel("QA Automation Suite");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setForeground(PRIMARY_COLOR);
        topPanel.add(titleLabel, BorderLayout.CENTER);
        
        JButton refreshButton = createModernButton("Refresh UI 🔄");
        refreshButton.setPreferredSize(new Dimension(150, 40));
        refreshButton.addActionListener(e -> refreshCurrentCard());
        JPanel refreshButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshButtonPanel.setOpaque(false);
        refreshButtonPanel.add(refreshButton);
        topPanel.add(refreshButtonPanel, BorderLayout.EAST);
        return topPanel;
    }

    private JPanel createMenuPanel(int start, int end) {
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setOpaque(false);

        for (int i = start; i <= end; i++) {
            String buttonText = "<html><center><font size='4'>" + toolIcons[i] + "</font><br>" + toolNames[i] + "</center></html>";
            JButton toolButton = createModernButton(buttonText);
            toolButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            toolButton.setPreferredSize(new Dimension(180, 70));
            toolButton.setMaximumSize(new Dimension(180, 70));

            final String cardName = "TOOL" + (i + 1);
            toolButton.addActionListener(e -> {
                currentCardName = cardName;
                cardLayout.show(cardsPanel, cardName);
                setSelectedToolButton(toolButton);
            });

            menuPanel.add(toolButton);
            menuPanel.add(Box.createRigidArea(new Dimension(0, 10)));
            toolButtons.add(toolButton);
        }
        return menuPanel;
    }

    private JButton createModernButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        button.setFocusPainted(false);
        button.setBackground(CARD_COLOR);
        button.setForeground(Color.DARK_GRAY);
        button.setBorder(new CompoundBorder(
                new MatteBorder(1, 1, 1, 1, new Color(220, 220, 220)),
                new EmptyBorder(10, 15, 10, 15)
        ));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);
        return button;
    }
    
    private void setupCardPanel() {
        cardsPanel.setOpaque(false);
        cardsPanel.add(createWelcomePanel(), "WELCOME");

        // Instantiate all tool panels
        this.tool1PanelInstance = new Tool1Panel(this);
        this.tool2PanelInstance = new Tool2Panel();
        this.tool5PanelInstance = new Tool5Panel(); // Instantiate Tool5Panel

        // Add panels to the card layout
        cardsPanel.add(tool1PanelInstance, "TOOL1");
        cardsPanel.add(tool2PanelInstance, "TOOL2");
        cardsPanel.add(createPlaceholderToolPanel(toolNames[2]), "TOOL3"); // Placeholder
        cardsPanel.add(createPlaceholderToolPanel(toolNames[3]), "TOOL4"); // Placeholder
        cardsPanel.add(tool5PanelInstance, "TOOL5"); // Add the actual Tool5Panel
        cardsPanel.add(createPlaceholderToolPanel(toolNames[5]), "TOOL6"); // Placeholder
        cardsPanel.add(createPlaceholderToolPanel(toolNames[6]), "TOOL7"); // Placeholder
        cardsPanel.add(createPlaceholderToolPanel(toolNames[7]), "TOOL8"); // Placeholder

        cardLayout.show(cardsPanel, "WELCOME");
    }

    /**
     * Public method called by Tool1Panel to trigger a refresh in other panels.
     */
    public void onProjectListChanged() {
        if (tool2PanelInstance != null) {
            tool2PanelInstance.populateProjectComboBox();
        }
        if (tool1PanelInstance != null) {
            tool1PanelInstance.populateLoadProjectComboBox();
        }
    }

    private void refreshCurrentCard() {
        if (currentCardName == null || currentCardName.equals("WELCOME")) {
            JOptionPane.showMessageDialog(this, "The Welcome Screen cannot be refreshed.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JPanel newPanel;
        int toolIndex = -1;
        switch (currentCardName) {
            case "TOOL1":
                this.tool1PanelInstance = new Tool1Panel(this);
                newPanel = this.tool1PanelInstance;
                toolIndex = 0;
                break;
            case "TOOL2":
                this.tool2PanelInstance = new Tool2Panel();
                newPanel = this.tool2PanelInstance;
                toolIndex = 1;
                break;
            case "TOOL5":
                this.tool5PanelInstance = new Tool5Panel();
                newPanel = this.tool5PanelInstance;
                toolIndex = 4;
                break;
            default:
                try {
                    toolIndex = Integer.parseInt(currentCardName.substring(4)) - 1;
                    newPanel = createPlaceholderToolPanel(toolNames[toolIndex]);
                } catch (Exception e) {
                    return; // Should not happen
                }
                break;
        }
        
        cardsPanel.add(newPanel, currentCardName);
        cardLayout.show(cardsPanel, currentCardName);
        JOptionPane.showMessageDialog(this, "'" + toolNames[toolIndex] + "' has been refreshed.", "UI Refreshed", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private JPanel createWelcomePanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(CARD_COLOR);
        panel.setBorder(new CompoundBorder(
                new ShadowBorder(5, 0.2f, 8),
                new EmptyBorder(20, 20, 20, 20)
        ));
        JPanel header = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        header.setOpaque(false);
        JLabel icon = new JLabel("🚀");
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
        header.add(icon);
        JLabel title = new JLabel("Welcome to QA Automation Suite");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(PRIMARY_COLOR);
        header.add(title);
        panel.add(header, BorderLayout.NORTH);
        JPanel tipPanel = new JPanel(new BorderLayout(10, 10));
        tipPanel.setOpaque(false);
        tipPanel.setBorder(new EmptyBorder(20, 0, 20, 0));
        JLabel tipTitle = new JLabel("💡 Tip of the Day");
        tipTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        tipTitle.setForeground(ACCENT_COLOR);
        tipPanel.add(tipTitle, BorderLayout.NORTH);
        JTextArea tipContent = new JTextArea(getRandomTip());
        tipContent.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tipContent.setLineWrap(true);
        tipContent.setWrapStyleWord(true);
        tipContent.setEditable(false);
        tipContent.setOpaque(false);
        tipPanel.add(new JScrollPane(tipContent), BorderLayout.CENTER);
        panel.add(tipPanel, BorderLayout.CENTER);
        return panel;
    }
    
    private JPanel createPlaceholderToolPanel(String toolName) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        JLabel label = new JLabel(toolName, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.BOLD, 24));
        label.setForeground(PRIMARY_COLOR.darker());
        panel.add(label, BorderLayout.CENTER);
        return panel;
    }
    
    private String getRandomTip() {
        List<String> qaTips = Arrays.asList(
                "Think like the end-user, not the developer. Understand their workflows to create effective tests.",
                "The most severe bug is often the one you haven't found yet. Always assume there's one more critical issue lurking.",
                "Test boundary conditions religiously. The edges of acceptable input ranges are where most defects hide.",
                "Prioritize bug reports based on impact and likelihood. Not all bugs need to be fixed immediately.",
                "Exploratory testing can uncover bugs that scripted tests miss. Schedule time for unscripted testing sessions."
        );
        return qaTips.get(new Random().nextInt(qaTips.size()));
    }
    
    private void setSelectedToolButton(JButton selectedButton) {
        for (JButton button : toolButtons) {
            button.setBackground(button == selectedButton ? PRIMARY_COLOR : CARD_COLOR);
            button.setForeground(button == selectedButton ? Color.WHITE : Color.DARK_GRAY);
        }
    }
    
    public void resetToWelcomeScreen() {
        cardLayout.show(cardsPanel, "WELCOME");
        currentCardName = "WELCOME";
        for (JButton button : toolButtons) {
            button.setBackground(CARD_COLOR);
            button.setForeground(Color.DARK_GRAY);
        }
    }
    
    private static class ShadowBorder implements Border {
        private final int shadowSize;
        private final float opacity;
        private final int cornerRadius;
        public ShadowBorder(int shadowSize, float opacity, int cornerRadius) {
            this.shadowSize = shadowSize;
            this.opacity = opacity;
            this.cornerRadius = cornerRadius;
        }
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            for (int i = 0; i < shadowSize; i++) {
                float alpha = opacity * (1.0f - (float) i / shadowSize);
                g2d.setColor(new Color(0, 0, 0, alpha));
                g2d.drawRoundRect(x + i, y + i, width - 2 * i - 1, height - 2 * i - 1, cornerRadius, cornerRadius);
            }
            g2d.dispose();
        }
        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(shadowSize, shadowSize, shadowSize, shadowSize);
        }
        @Override
        public boolean isBorderOpaque() {
            return false;
        }
    }
}