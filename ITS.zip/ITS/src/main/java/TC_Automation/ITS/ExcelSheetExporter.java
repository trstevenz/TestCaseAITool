package TC_Automation.ITS;

import com.formdev.flatlaf.FlatDarculaLaf;
import com.formdev.flatlaf.FlatIntelliJLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.FlatDarkLaf;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import java.awt.Color;
import java.awt.Component;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.stream.Collectors;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.Box;
import javax.swing.JToggleButton;
import javax.swing.border.LineBorder;
import java.awt.CardLayout;

/**
 * A Java Swing application that automatically loads Excel templates to generate a final test case document.
 * This version includes a powerful custom component and scenario manager.
 */
public class ExcelSheetExporter extends JFrame {
    final JTabbedPane mainTabbedPane = new JTabbedPane();
    private final JComboBox<String> primarySheetComboBox = new JComboBox<>();
    private final JButton downloadButton = new JButton("Download Sheets");
    private final JButton previewButton = new JButton("Preview");
    private final JLabel statusLabel = new JLabel("Loading Excel files...");
    private File primaryFile, secondaryFile, thirdTemplateFile;
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel mainCardsPanel = new JPanel(cardLayout);

    final List<DynamicFormField> dynamicFormFields = new ArrayList<>();
    private final Map<String, JTextField> dynamicFieldTextFields = new LinkedHashMap<>();

    private final JCheckBox newBusinessCheckBox = new JCheckBox("New Business");
    private final JCheckBox endorsementCheckBox = new JCheckBox("Endorsement");
    private final JCheckBox renewalCheckBox = new JCheckBox("Renewal");
    private final JCheckBox rewriteCheckBox = new JCheckBox("Rewrite");

    final Map<String, ComponentData> componentDataMap = new LinkedHashMap<>();
    final List<CustomComponentModel> customComponents = new ArrayList<>();
    final List<TestScenario> testScenarios = new ArrayList<>();
    private int globalSequenceCounter;
    private JPanel topWrapperPanel;
    
    // Track enabled/disabled state for all components
    private final Map<String, Boolean> enabledComponents = new LinkedHashMap<>();

    private static class AppState implements Serializable {
        private static final long serialVersionUID = 3L;
        Map<String, String> dynamicFieldValues;
        String selectedSheet;
        List<String> selectedTransactions;
        @SuppressWarnings("rawtypes")
        Map<String, Vector<Vector>> allTableData = new HashMap<>();
        Map<String, Boolean> enabledComponents;
    }

    public static class DynamicFormField implements Serializable {
        private static final long serialVersionUID = 1L;
        String label;
        String placeholder;

        public DynamicFormField(String label, String placeholder) {
            this.label = label;
            this.placeholder = placeholder;
        }

        @Override
        public String toString() {
            return label + " (" + placeholder + ")";
        }
    }

    static class ComponentData {
        final DefaultTableModel model;
        final JTable table;
        final JButton addButton;
        final JButton generateButton;
        ComponentData(String[] columns, String type) {
            this.model = new DefaultTableModel(columns, 0) {
                @Override public boolean isCellEditable(int row, int column) { return column == getColumnCount() - 1; }
            };
            this.table = new JTable(model);
            this.addButton = new JButton("Add " + type);
            this.generateButton = new JButton("Generate Multiple...");
        }
    }
    public static class CustomComponentModel implements Serializable {
        private static final long serialVersionUID = 2L;
        String name;
        String blockIdentifier;
        List<String> uiFields = new ArrayList<>();
        List<String> placeholders = new ArrayList<>();
    }
    
    public static class TestScenario implements Serializable {
        private static final long serialVersionUID = 1L;
        String name;
        Map<String, Vector<Vector<Object>>> scenarioData = new HashMap<>();
        Map<String, List<Integer>> selectedRows = new HashMap<>();
    }
    
    public ExcelSheetExporter() {
        super("Test Case Generator");
        setupFlatLafTheme();
        initializeComponentData();
        loadDynamicFormFields();
        loadCustomComponents();
        loadTestScenarios();
        initComponents();
        layoutComponents();
        autoLoadPredefinedFiles();
        
        // Add window listener to save scenarios on exit
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                saveTestScenarios();
                saveCustomComponents();
                saveDynamicFormFields();
            }
        });
    }
    
    private void initializeComponentData() {
        // Initialize all components as enabled by default
        String[] defaultComponents = {
            "Header", "Footer", "Dynamic", "Logo", "Date", "Page", "Policy"
        };
        
        for (String comp : defaultComponents) {
            enabledComponents.put(comp, true);
        }
        
        // Initialize component data
        componentDataMap.put("Header", new ComponentData(new String[]{"Name", "Font Size", "Font Style", "Font Family", "Position", "Actions"}, "Header"));
        componentDataMap.put("Footer", new ComponentData(new String[]{"Name", "Font Size", "Font Style", "Font Family", "Position", "Actions"}, "Footer"));
        componentDataMap.put("Dynamic", new ComponentData(new String[]{"Dynamic Field Name", "Form Field", "Value Type", "Characters Count", "Actions"}, "Dynamic Field"));
        componentDataMap.put("Logo", new ComponentData(new String[]{"Logo Position", "Header/Footer", "Actions"}, "Logo"));
        componentDataMap.put("Date", new ComponentData(new String[]{"Form Date Field", "UI Date Field", "Date Format", "Actions"}, "Date"));
        componentDataMap.put("Page", new ComponentData(new String[]{"Total Page", "Page No Format", "Odd Pos", "Even Pos", "Actions"}, "Page Number"));
        componentDataMap.put("Policy", new ComponentData(new String[]{"Policy No Format", "Policy No Position", "Actions"}, "Policy Number"));
    }
    
    private void setupFlatLafTheme() {
        try { UIManager.setLookAndFeel(new FlatLightLaf()); } catch (Exception ex) { System.err.println("FlatLaf failed"); }
    }
    
    private void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 950);
        setLocationRelativeTo(null);
        downloadButton.setEnabled(false);
        downloadButton.addActionListener(this::downloadAction);
        previewButton.addActionListener(e -> previewOutput());
        for (Map.Entry<String, ComponentData> entry : componentDataMap.entrySet()) {
            final String type = entry.getKey();
            ComponentData data = entry.getValue();
            data.addButton.addActionListener(e -> openEditDialog(-1, type));
            data.generateButton.addActionListener(e -> openGenerateDialog(type));
            setupTable(data.table, type);
        }
    }
    
    private void setupTable(JTable table, String type) {
        table.getColumn("Actions").setCellRenderer(new ButtonColumnRenderer(type));
        table.getColumn("Actions").setCellEditor(new ButtonColumnEditor(new JCheckBox(), type));
        table.setRowHeight(40);
        int actionColIndex = table.getColumnCount() - 1;
        table.getColumnModel().getColumn(actionColIndex).setPreferredWidth(260);
        table.getColumnModel().getColumn(actionColIndex).setMinWidth(260);
    }
    
    private void stylePrimaryButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBackground(new Color(0, 122, 204));
        button.setForeground(Color.WHITE);
        button.setMargin(new Insets(8, 16, 8, 16));
    }
    
    private void styleTableButton(JButton button, Color background, Color foreground) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBackground(background);
        button.setForeground(foreground);
        button.setOpaque(true);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setMargin(new Insets(5, 12, 5, 12));
    }
    
    private void layoutComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        setJMenuBar(createMenuBar());
        stylePrimaryButton(downloadButton);
        stylePrimaryButton(previewButton);
        mainTabbedPane.removeAll();
        for (Map.Entry<String, ComponentData> entry : componentDataMap.entrySet()) {
            if (isComponentEnabled(entry.getKey())) {
                mainTabbedPane.addTab(entry.getKey(), createComponentTabPanel(entry.getValue().addButton, entry.getValue().generateButton, entry.getValue().table));
            }
        }
        rebuildCustomComponentTabs();
        JPanel southPanel = new JPanel(new BorderLayout(10, 0));
        southPanel.add(statusLabel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(previewButton);
        buttonPanel.add(downloadButton);
        southPanel.add(buttonPanel, BorderLayout.SOUTH);

        topWrapperPanel = new JPanel(new BorderLayout(0, 15));
        JLabel titleLabel = new JLabel("Test Case Generator", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        
        JButton refreshButton = new JButton("Refresh");
        stylePrimaryButton(refreshButton);
        refreshButton.addActionListener(e -> {
            loadCustomComponents();
            rebuildCustomComponentTabs();
        });
        JPanel topRightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topRightPanel.add(refreshButton);
        JPanel titleContainer = new JPanel(new BorderLayout());
        titleContainer.add(titleLabel, BorderLayout.CENTER);
        titleContainer.add(topRightPanel, BorderLayout.EAST);
        
        topWrapperPanel.add(titleContainer, BorderLayout.NORTH);
        topWrapperPanel.add(createTopInputPanel(), BorderLayout.CENTER);
        mainPanel.add(topWrapperPanel, BorderLayout.NORTH);
        mainPanel.add(mainTabbedPane, BorderLayout.CENTER);
        mainPanel.add(southPanel, BorderLayout.SOUTH);
        setContentPane(mainPanel);
        
        TestExecutionPanel testExecutionPanel = new TestExecutionPanel(mainCardsPanel);
        mainCardsPanel.add(mainPanel, "main"); // Give the main view a name
        mainCardsPanel.add(testExecutionPanel, "testExecution"); // Give the other view a name
        
        setJMenuBar(createMenuBar()); // Set the menu bar here
        setContentPane(mainCardsPanel); // The CardLayout panel

    }
    
    private JMenuBar createMenuBar() {
    	
    	
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem loadItem = new JMenuItem("Load Configuration...");
        JMenuItem TCExecution = new JMenuItem("Go to Test Execution");
        loadItem.addActionListener(e -> loadConfiguration());
        TCExecution.addActionListener(e -> {
            cardLayout.show(mainCardsPanel, "testExecution");
        });
    
        fileMenu.add(loadItem);
        fileMenu.add(TCExecution);
        
        fileMenu.addSeparator();
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu editMenu = new JMenu("Edit");
        JMenuItem findReplaceItem = new JMenuItem("Find and Replace...");
        findReplaceItem.addActionListener(e -> openFindAndReplaceDialog());
        editMenu.add(findReplaceItem);
        
        JMenu dataMenu = new JMenu("Data");
        JMenuItem exportItem = new JMenuItem("Export Data to Excel...");
        exportItem.addActionListener(e -> exportDataToExcel());
        JMenuItem importItem = new JMenuItem("Import Data from Excel...");
        importItem.addActionListener(e -> importDataFromExcel());
        dataMenu.add(exportItem);
        dataMenu.add(importItem);
        
        JMenuItem loadScenarioItem = new JMenuItem("Load Scenario...");
        loadScenarioItem.addActionListener(e -> loadTestScenario());
        dataMenu.addSeparator();
        dataMenu.add(loadScenarioItem);
        
        JMenu manageMenu = new JMenu("Manage");
        JMenuItem customItem = new JMenuItem("Custom Components...");
        customItem.addActionListener(e -> manageCustomComponents());
        JMenuItem scenarioItem = new JMenuItem("Test Scenarios...");
        scenarioItem.addActionListener(e -> manageTestScenarios());
        JMenuItem formDataItem = new JMenuItem("Form & Data Fields...");
        formDataItem.addActionListener(e -> manageDynamicFormFields());
        
        // Menu item for managing components
        JMenuItem componentsItem = new JMenuItem("Manage Components...");
        componentsItem.addActionListener(e -> manageComponents());
        manageMenu.add(componentsItem);

        manageMenu.add(customItem);
        manageMenu.add(scenarioItem);
        manageMenu.add(formDataItem);
        
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(dataMenu);
        menuBar.add(manageMenu);
        menuBar.add(createSettingsMenu());
        
        return menuBar;
    }
    
    private JRadioButtonMenuItem createThemeMenuItem(String name, String lafClassName, ButtonGroup group, boolean selected) {
        JRadioButtonMenuItem menuItem = new JRadioButtonMenuItem(name, selected);
        menuItem.addActionListener(e -> {
            try {
                UIManager.setLookAndFeel(lafClassName);
                SwingUtilities.updateComponentTreeUI(this);
            } catch (Exception ex) {
                showError("Failed to set theme: " + ex.getMessage());
            }
        });
        group.add(menuItem);
        return menuItem;
    }

    private JMenu createSettingsMenu() {
        JMenu settingsMenu = new JMenu("Settings");
        JMenu themeMenu = new JMenu("Theme");
        ButtonGroup themeGroup = new ButtonGroup();

        themeMenu.add(createThemeMenuItem("Light", FlatLightLaf.class.getName(), themeGroup, true));
        themeMenu.add(createThemeMenuItem("Dark", FlatDarkLaf.class.getName(), themeGroup, false));
        themeMenu.add(createThemeMenuItem("IntelliJ", FlatIntelliJLaf.class.getName(), themeGroup, false));
        themeMenu.add(createThemeMenuItem("Darcula", FlatDarculaLaf.class.getName(), themeGroup, false));
        
        settingsMenu.add(themeMenu);
        return settingsMenu;
    }

    private JPanel createTopInputPanel() {
        JPanel topInputPanel = new JPanel(new GridBagLayout());
        topInputPanel.setBorder(BorderFactory.createTitledBorder("Current Configuration"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 8, 4, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        dynamicFieldTextFields.clear();
        int gridY = 0;
        for (DynamicFormField field : dynamicFormFields) {
            gbc.gridx = 0; gbc.gridy = gridY; topInputPanel.add(new JLabel(field.label + ":"), gbc);
            JTextField textField = new JTextField(15);
            dynamicFieldTextFields.put(field.placeholder, textField);
            gbc.gridx = 1; topInputPanel.add(textField, gbc);
            gridY++;
        }
        
        gbc.gridx = 2; gbc.gridy = 0; gbc.weightx = 0; topInputPanel.add(new JLabel("Additional Page:"), gbc);
        gbc.gridx = 3; gbc.gridy = 0; gbc.weightx = 1.0; topInputPanel.add(primarySheetComboBox, gbc);
        
        JPanel transactionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        transactionPanel.setBorder(BorderFactory.createTitledBorder("Transactions"));
        transactionPanel.add(newBusinessCheckBox);
        transactionPanel.add(endorsementCheckBox);
        transactionPanel.add(renewalCheckBox);
        transactionPanel.add(rewriteCheckBox);
        
        gbc.gridx = 2; gbc.gridy = 1; gbc.gridwidth = 2; gbc.gridheight = 2;
        topInputPanel.add(transactionPanel, gbc);

        return topInputPanel;
    }
    
    private JPanel createComponentTabPanel(JButton addButton, JButton generateButton, JTable table) {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBorder(new EmptyBorder(8, 8, 8, 8));
        stylePrimaryButton(addButton);
        stylePrimaryButton(generateButton);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(addButton);
        buttonPanel.add(generateButton);
        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }
    
    private void openEditDialog(int rowIndex, String type) {
        CustomComponentModel customModel = findCustomComponentByName(type);
        if (customModel != null) {
            editCustomRow(rowIndex, customModel);
        } else {
            editPredefinedComponentRow(rowIndex, type);
        }
    }
    
    private void openGenerateDialog(String type) {
        ComponentData compData = componentDataMap.get(type);
        int numFields = compData.model.getColumnCount() - 1;
        JPanel p = new JPanel(new GridLayout(0, 2, 5, 5));
        List<JTextField> fields = new ArrayList<>();
        JSpinner countSpinner = new JSpinner(new SpinnerNumberModel(10, 1, 1000, 1));
        
        for(int i=0; i < numFields; i++) {
            p.add(new JLabel(compData.model.getColumnName(i) + ":"));
            JTextField field = new JTextField();
            if (i == 0) {
                field.setText(type + "_{{i}}");
            }
            p.add(field);
            fields.add(field);
        }
        p.add(new JLabel("Number to Generate:"));
        p.add(countSpinner);
        if(JOptionPane.showConfirmDialog(this, p, "Generate Multiple " + type + "s", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION) {
            int count = (Integer) countSpinner.getValue();
            for (int i = 1; i <= count; i++) {
                Vector<Object> data = new Vector<>();
                for(JTextField field : fields) {
                    data.add(field.getText().replace("{{i}}", String.valueOf(i)));
                }
                compData.model.addRow(data);
            }
        }
    }
    
    private void editPredefinedComponentRow(int rowIndex, String type) {
        ComponentData compData = componentDataMap.get(type);
        int numFields = compData.model.getColumnCount() - 1;
        JPanel p = new JPanel(new GridLayout(0, 2, 5, 5));
        List<JTextField> fields = new ArrayList<>();
        
        for(int i=0; i < numFields; i++) {
            p.add(new JLabel(compData.model.getColumnName(i) + ":"));
            JTextField field = new JTextField();
            fields.add(field);
            p.add(field);
        }
        if(rowIndex != -1) {
            for(int i=0; i<numFields; i++) {
                fields.get(i).setText(compData.model.getValueAt(rowIndex, i).toString());
            }
        }
        
        if(JOptionPane.showConfirmDialog(this, p, "Edit " + type + " Component", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION) {
            Vector<Object> data = new Vector<>();
            for(JTextField field : fields) {
                data.add(field.getText());
            }
            if(rowIndex == -1) {
                compData.model.addRow(data);
            } else {
                for(int i=0; i < data.size(); i++) compData.model.setValueAt(data.get(i), rowIndex, i);
            }
        }
    }
    
    private void editCustomRow(int rowIndex, CustomComponentModel model) {
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        List<JTextField> fields = new ArrayList<>();
        
        for (String fieldName : model.uiFields) {
            JTextField field = new JTextField();
            fields.add(field);
            panel.add(new JLabel(fieldName + ":"));
            panel.add(field);
        }
        DefaultTableModel tableModel = componentDataMap.get(model.name).model;
        if (rowIndex != -1) {
            @SuppressWarnings("rawtypes")
            Vector rowData = (Vector) tableModel.getDataVector().get(rowIndex);
            for (int i = 0; i < fields.size(); i++) {
                fields.get(i).setText(rowData.get(i).toString());
            }
        }
        if (JOptionPane.showConfirmDialog(this, panel, "Edit " + model.name, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION) {
            Vector<Object> rowData = new Vector<>();
            for (JTextField field : fields) {
                rowData.add(field.getText());
            }
            if (rowIndex == -1) {
                tableModel.addRow(rowData);
            } else {
                for (int i = 0; i < rowData.size(); i++) {
                    tableModel.setValueAt(rowData.get(i), rowIndex, i);
                }
            }
        }
    }
    
    private void autoLoadPredefinedFiles() {
        primaryFile = new File("templates/template_testcase.xlsx");
        if (!primaryFile.exists() || primaryFile.isDirectory()) showError("Primary file not found: " + primaryFile.getAbsolutePath());
        else loadPrimarySheetNames();
        
        secondaryFile = new File("templates/secondary_template.xlsx");
        if (!secondaryFile.exists() || secondaryFile.isDirectory()) showError("Secondary file not found: " + secondaryFile.getAbsolutePath());
        
        thirdTemplateFile = new File("templates/header_page_template.xlsx");
        if (!thirdTemplateFile.exists() || thirdTemplateFile.isDirectory()) showError("Header template not found: " + thirdTemplateFile.getAbsolutePath());
        
        statusLabel.setText("Files loaded successfully.");
        downloadButton.setEnabled(true);
    }
    
    private void loadPrimarySheetNames() {
        primarySheetComboBox.removeAllItems();
        primarySheetComboBox.addItem("None");
        try (FileInputStream fis = new FileInputStream(primaryFile); Workbook wb = new XSSFWorkbook(fis)) {
            for (int i = 1; i < wb.getNumberOfSheets(); i++) primarySheetComboBox.addItem(wb.getSheetName(i));
        } catch (IOException ex) {
            showError("Error reading primary Excel: " + ex.getMessage());
        }
    }
    
    private void downloadAction(ActionEvent e) {
        stopAllTableEditing();
        String sheet = (String) primarySheetComboBox.getSelectedItem();
        List<String> sheets = new ArrayList<>();
        if (sheet != null && !"None".equals(sheet)) sheets.add(sheet);
        
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Save New Excel File");
        
        String formId = dynamicFieldTextFields.get("{{formID}}").getText();
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String suggestedName = formId + "_" + timestamp + "_TC.xlsx";
        
        fc.setSelectedFile(new File(suggestedName));
        fc.setFileFilter(new FileNameExtensionFilter("Excel Files", "xlsx"));
        
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            if (!file.getName().toLowerCase().endsWith(".xlsx")) file = new File(file.getParentFile(), file.getName() + ".xlsx");
            createAndSaveNewWorkbook(sheets, file);
        }
    }
    
    private void createAndSaveNewWorkbook(List<String> additionalSheets, File fileToSave) {
        try (Workbook newWorkbook = new XSSFWorkbook()) {
            if (primaryFile.exists()){
                try (FileInputStream fis = new FileInputStream(primaryFile); Workbook sourceWb = new XSSFWorkbook(fis)) {
                    if (sourceWb.getNumberOfSheets() > 0) {
                        copySheet(sourceWb.getSheetAt(0), newWorkbook.createSheet(sourceWb.getSheetAt(0).getSheetName()), false, new HashMap<>());
                    }
                    for (String sheetName : additionalSheets) {
                        Sheet source = sourceWb.getSheet(sheetName);
                        if (source != null) copySheet(source, newWorkbook.createSheet(sheetName), false, new HashMap<>());
                    }
                }
            }
            
            Workbook templateWorkbook = new XSSFWorkbook();
            int baseTcCount = processSingleTransactionSheet(templateWorkbook, "{{transName}}");
            Sheet templateSheet = templateWorkbook.getSheet("{{transName}}");
            List<String> selectedTransactions = getSelectedTransactions();
            int totalTcCount = baseTcCount * selectedTransactions.size();
            for (String transName : selectedTransactions) {
                Sheet newSheet = newWorkbook.createSheet(transName);
                copySheet(templateSheet, newSheet, false, new HashMap<>());
                
                Map<String, String> transReplacement = new HashMap<>();
                transReplacement.put("{{transName}}", transName);
                for (Row row : newSheet) {
                    replacePlaceholdersInRow(row, transReplacement, newWorkbook, new HashMap<>());
                }
            }
            Map<String, String> finalReplacements = new HashMap<>();
            for(Map.Entry<String, JTextField> entry : dynamicFieldTextFields.entrySet()){
                finalReplacements.put(entry.getKey(), entry.getValue().getText());
            }

            finalReplacements.put("{{currDate}}", new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
            finalReplacements.put("{{tcCount}}", String.valueOf(totalTcCount));
            Map<CellStyle, CellStyle> finalCache = new HashMap<>();
            for(Sheet sheet : newWorkbook) {
                for (Row row : sheet) {
                    replacePlaceholdersInRow(row, finalReplacements, newWorkbook, finalCache);
                }
            }
            
            try (FileOutputStream fos = new FileOutputStream(fileToSave)) {
                newWorkbook.write(fos);
                JOptionPane.showMessageDialog(this, "Successfully saved sheets to:\n" + fileToSave.getAbsolutePath(), "Export Successful", JOptionPane.INFORMATION_MESSAGE);
                saveConfiguration();
            }
        } catch (IOException ex) {
            showError("Error during file creation: " + ex.getMessage());
        }
    }
    
    private List<String> getSelectedTransactions() {
        List<String> selected = new ArrayList<>();
        if(newBusinessCheckBox.isSelected()) selected.add("New Business");
        if(endorsementCheckBox.isSelected()) selected.add("Endorsement");
        if(renewalCheckBox.isSelected()) selected.add("Renewal");
        if(rewriteCheckBox.isSelected()) selected.add("Rewrite");
        return selected;
    }
    
    private int processSingleTransactionSheet(Workbook outputWorkbook, String transactionName) {
        this.globalSequenceCounter = 1;
        Sheet sheet = outputWorkbook.createSheet(transactionName);
        int outputRowIdx = 0;
        if (thirdTemplateFile.exists()) {
             try(FileInputStream fis = new FileInputStream(thirdTemplateFile); Workbook headerWb = new XSSFWorkbook(fis)) {
                if(headerWb.getNumberOfSheets() > 0) {
                    Row srcRow = headerWb.getSheetAt(0).getRow(0);
                    if(srcRow != null) copyRow(srcRow, sheet.createRow(outputRowIdx++), outputWorkbook, new HashMap<>());
                }
            } catch (IOException e){ showError("Error inserting header row: " + e.getMessage()); }
        }
        for (String componentName : componentDataMap.keySet()) {
            if (isComponentEnabled(componentName)) {
                 outputRowIdx = processDynamicBlock(outputWorkbook, sheet, outputRowIdx, componentName, componentDataMap.get(componentName).model, transactionName);
            }
        }
        return this.globalSequenceCounter - 1;
    }
    
    @SuppressWarnings("rawtypes")
    private int processDynamicBlock(Workbook wb, Sheet sheet, int startRow, String id, DefaultTableModel model, String transactionName) {
        Vector<Vector> data = model.getDataVector();
        int rowIdx = startRow;
        
        CustomComponentModel customModel = findCustomComponentByName(id);
        String blockId = (customModel != null) ? customModel.blockIdentifier : id.toUpperCase();
        
        if (data.isEmpty() || !secondaryFile.exists()) return rowIdx;
        
        List<Row> tRows = new ArrayList<>();
        List<CellRangeAddress> tRegions = new ArrayList<>();
        int tHeight = 0, tStartRow = -1;
        
        try (FileInputStream fis = new FileInputStream(secondaryFile); Workbook bpWb = new XSSFWorkbook(fis)) {
            Sheet bpSheet = findSheetWithText(bpWb, blockId);
            if (bpSheet != null) {
                for (int i = 1; i < bpSheet.getRow(0).getLastCellNum(); i++) sheet.setColumnWidth(i - 1, bpSheet.getColumnWidth(i));
                CellRangeAddress tRegion = findMergedRegionWithText(bpSheet, blockId);
                if (tRegion != null) {
                    tStartRow = tRegion.getFirstRow();
                    tHeight = tRegion.getLastRow() - tStartRow + 1;
                    
                    try (Workbook tempWb = new XSSFWorkbook()) {
                        Sheet tempSheet = tempWb.createSheet();
                        for (int i=0; i<tHeight; i++) {
                            Row srcRow = bpSheet.getRow(tStartRow + i);
                            Row newRow = tempSheet.createRow(i);
                            if (srcRow != null) copyRow(srcRow, newRow, tempWb, new HashMap<>(), true);
                            tRows.add(newRow);
                        }
                        for (CellRangeAddress r : bpSheet.getMergedRegions()) {
                            if (r.getFirstRow() >= tStartRow && r.getLastRow() <= tRegion.getLastRow()) tRegions.add(r.copy());
                        }
                    }
                }
            } else {
                if(!"HEADER".equals(blockId) && customModel == null)
                  System.err.println("Block identifier not found in template: " + blockId);
            }
        } catch (IOException e) {
            showError("Error caching " + id + " blueprint: " + e.getMessage());
            return rowIdx;
        }
        if (tRows.isEmpty()) return rowIdx;
        
        Map<CellStyle, CellStyle> wrappedStyleCache = new HashMap<>();
        for (int i = 0; i < data.size(); i++) {
            int blockStart = rowIdx;
            for (int j = 0; j < tHeight; j++) copyRow(tRows.get(j), sheet.createRow(rowIdx++), wb, new HashMap<>());
            
            for(CellRangeAddress r : tRegions){
                 CellRangeAddress newR = new CellRangeAddress(r.getFirstRow()-tStartRow+blockStart, r.getLastRow()-tStartRow+blockStart, r.getFirstColumn()-1, r.getLastColumn()-1);
                if (newR.getFirstColumn() >= 0) sheet.addMergedRegion(newR);
            }
            
            @SuppressWarnings("unchecked")
            Vector<String> rowData = (Vector<String>) data.get(i);
            Map<String, String> reps = new HashMap<>();
            reps.put("{{seq}}", String.valueOf(this.globalSequenceCounter++));
            reps.put("{{transName}}", transactionName);
            if(customModel != null) {
                for(int j=0; j<customModel.placeholders.size(); j++) {
                    reps.put(customModel.placeholders.get(j), rowData.get(j));
                }
            } else {
                 switch(id) {
                    case "Header": case "Footer":
                        reps.put(id.equals("Header") ? "{{header}}" : "{{footer}}", rowData.get(0));
                        reps.put("{{fontSize}}", rowData.get(1)); reps.put("{{fontStyle}}", rowData.get(2));
                        reps.put("{{fontFamily}}", rowData.get(3)); reps.put("{{fontPosition}}", rowData.get(4));
                        break;
                    case "Dynamic":
                        reps.put("{{dynamicField}}", rowData.get(0)); reps.put("{{formField}}", rowData.get(1));
                        reps.put("{{datatype}}", rowData.get(2)); reps.put("{{count}}", rowData.get(3));
                        break;
                    case "Logo":
                        reps.put("{{position}}", rowData.get(0)); reps.put("{{headerOrFooter}}", rowData.get(1));
                        break;
                    case "Date":
                        reps.put("{{dateField}}", rowData.get(0)); reps.put("{{mappedDate}}", rowData.get(1));
                        reps.put("{{dateFormat}}", rowData.get(2));
                        break;
                    case "Page":
                        reps.put("{{pageCount}}", rowData.get(0)); reps.put("{{pageNumFormat}}", rowData.get(1));
                        reps.put("{{ODDpageNumPosition}}", rowData.get(2)); reps.put("{{EVEpageNumPosition}}", rowData.get(3));
                        break;
                    case "Policy":
                        reps.put("{{policyFormat}}", rowData.get(0)); reps.put("{{position}}", rowData.get(1));
                        break;
                }
            }
            
            for (int j=0; j<tHeight; j++) replacePlaceholdersInRow(sheet.getRow(blockStart + j), reps, wb, wrappedStyleCache);
        }
        return rowIdx;
    }
    
    private Sheet findSheetWithText(Workbook wb, String txt) {
        for (Sheet s : wb) if (findMergedRegionWithText(s, txt) != null) return s;
        return null;
    }
    
    private CellRangeAddress findMergedRegionWithText(Sheet s, String txt) {
        for (int i=0; i<s.getNumMergedRegions(); i++) {
            CellRangeAddress r = s.getMergedRegion(i);
            Row firstRow = s.getRow(r.getFirstRow());
            if (firstRow != null) {
                Cell c = firstRow.getCell(r.getFirstColumn());
                if (c != null && c.getCellType() == CellType.STRING && txt.equals(c.getStringCellValue())) return r;
            }
        }
        return null;
    }
    
    private void replacePlaceholdersInRow(Row r, Map<String,String> reps, Workbook wb, Map<CellStyle, CellStyle> wrappedStyleCache){
        if(r == null) return;
        for (Cell c : r) {
            if (c != null && c.getCellType() == CellType.STRING) {
                String val = c.getStringCellValue();
                String temp = val;
                for (Map.Entry<String, String> entry : reps.entrySet()) {
                    if (temp.contains(entry.getKey())) temp = temp.replace(entry.getKey(), entry.getValue());
                }
                if (!val.equals(temp)) {
                    c.setCellValue(temp);
                    CellStyle originalStyle = c.getCellStyle();
                    CellStyle wrappedStyle = wrappedStyleCache.computeIfAbsent(originalStyle, style -> {
                        CellStyle newStyle = wb.createCellStyle();
                        newStyle.cloneStyleFrom(style);
                        newStyle.setWrapText(true);
                        return newStyle;
                    });
                    c.setCellStyle(wrappedStyle);
                }
            }
        }
    }
    
    public static void copyRow(Row src, Row dest, Workbook wb, Map<CellStyle, CellStyle> smap) {
        copyRow(src, dest, wb, smap, false);
    }
    public static void copyRow(Row src, Row dest, Workbook wb, Map<CellStyle, CellStyle> smap, boolean ignoreFirst) {
         if (src == null) return;
         dest.setHeight(src.getHeight());
         int offset = ignoreFirst ? 1 : 0;
         for (int i=offset; i<src.getLastCellNum(); i++) {
             Cell oldC = src.getCell(i), newC = dest.createCell(i - offset);
             if (oldC != null) {
                 CellStyle newS = smap.computeIfAbsent(oldC.getCellStyle(), s -> { CellStyle cs = wb.createCellStyle(); cs.cloneStyleFrom(s); return cs; });
                 newC.setCellStyle(newS);
                 switch (oldC.getCellType()) {
                    case STRING: newC.setCellValue(oldC.getStringCellValue()); break;
                    case NUMERIC: newC.setCellValue(oldC.getNumericCellValue()); break;
                    case BOOLEAN: newC.setCellValue(oldC.getBooleanCellValue()); break;
                    case FORMULA: newC.setCellFormula(oldC.getCellFormula()); break;
                    default: break;
                 }
             }
         }
    }
    
    public static void copySheet(Sheet src, Sheet dest, boolean ignoreFirst, Map<CellStyle, CellStyle> smap) {
        int offset = ignoreFirst ? 1 : 0;
        for (int i=0; i<src.getNumMergedRegions(); i++) {
            CellRangeAddress r = src.getMergedRegion(i);
            if (!ignoreFirst || r.getFirstColumn() >= 1) dest.addMergedRegion(new CellRangeAddress(r.getFirstRow(), r.getLastRow(), r.getFirstColumn()-offset, r.getLastColumn()-offset));
        }
        int maxCol = 0;
        for (Row r : src) maxCol = Math.max(maxCol, r.getLastCellNum());
        for (int i=offset; i<maxCol; i++) dest.setColumnWidth(i-offset, src.getColumnWidth(i));
        dest.setDefaultColumnWidth(src.getDefaultColumnWidth());
        for (int i=0; i<=src.getLastRowNum(); i++) {
            Row srcRow = src.getRow(i);
            if (srcRow != null) copyRow(srcRow, dest.createRow(i), dest.getWorkbook(), smap, ignoreFirst);
        }
    }
    
    private void showError(String msg) {
        statusLabel.setText("Error: See message dialog.");
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void saveConfiguration() {
        AppState state = new AppState();
        state.selectedSheet = (String) primarySheetComboBox.getSelectedItem();
        
        state.dynamicFieldValues = new HashMap<>();
        for(Map.Entry<String, JTextField> entry : dynamicFieldTextFields.entrySet()){
            state.dynamicFieldValues.put(entry.getKey(), entry.getValue().getText());
        }
        
        List<String> selectedTransactions = new ArrayList<>();
        if(newBusinessCheckBox.isSelected()) selectedTransactions.add("New Business");
        if(endorsementCheckBox.isSelected()) selectedTransactions.add("Endorsement");
        if(renewalCheckBox.isSelected()) selectedTransactions.add("Renewal");
        if(rewriteCheckBox.isSelected()) selectedTransactions.add("Rewrite");
        state.selectedTransactions = selectedTransactions;

        state.allTableData = new HashMap<>();
        for (Map.Entry<String, ComponentData> entry : componentDataMap.entrySet()) {
            state.allTableData.put(entry.getKey(), new Vector<>(entry.getValue().model.getDataVector()));
        }
        
        // Save enabled components state
        state.enabledComponents = new HashMap<>(enabledComponents);
        
        File historyDir = new File("history");
        if (!historyDir.exists()) historyDir.mkdir();
        String formId = dynamicFieldTextFields.get("{{formID}}").getText();
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String filename = "history/" + formId + "_" + timestamp + "_TC.ser";
        
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(state);
            statusLabel.setText("Configuration saved to " + filename);
        } catch (IOException e) {
            showError("Failed to save configuration: " + e.getMessage());
        }
    }
    
    private void loadConfiguration() {
        JFileChooser fc = new JFileChooser("history");
        fc.setDialogTitle("Load Configuration");
        fc.setFileFilter(new FileNameExtensionFilter("Configuration Files", "ser"));
        JPanel accessoryPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton deleteButton = new JButton("Delete Selected File");
        stylePrimaryButton(deleteButton);
        deleteButton.addActionListener(e -> {
            File selectedFile = fc.getSelectedFile();
            if (selectedFile != null && selectedFile.exists()) {
                int response = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to permanently delete this configuration?\n" + selectedFile.getName(),
                    "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
                );
                if (response == JOptionPane.YES_OPTION) {
                    if (selectedFile.delete()) {
                        fc.rescanCurrentDirectory();
                    } else {
                        showError("Could not delete the file: " + selectedFile.getName());
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "No file selected to delete.", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        });
        accessoryPanel.add(deleteButton);
        fc.setAccessory(accessoryPanel);
        
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fc.getSelectedFile()))) {
                AppState state = (AppState) ois.readObject();
                applyState(state);
                statusLabel.setText("Configuration loaded from " + fc.getSelectedFile().getName());
            } catch (IOException | ClassNotFoundException e) {
                showError("Failed to load configuration: " + e.getMessage());
            }
        }
    }
    
    @SuppressWarnings({"unchecked", "rawtypes"})
    private void applyState(AppState state) {
        if (state == null) return;
        
        if (state.selectedSheet != null) {
            primarySheetComboBox.setSelectedItem(state.selectedSheet);
        }
        
        if(state.dynamicFieldValues != null){
            for(Map.Entry<String, String> entry : state.dynamicFieldValues.entrySet()){
                if(dynamicFieldTextFields.containsKey(entry.getKey())){
                    dynamicFieldTextFields.get(entry.getKey()).setText(entry.getValue());
                }
            }
        }
        
        if(state.selectedTransactions != null){
            newBusinessCheckBox.setSelected(state.selectedTransactions.contains("New Business"));
            endorsementCheckBox.setSelected(state.selectedTransactions.contains("Endorsement"));
            renewalCheckBox.setSelected(state.selectedTransactions.contains("Renewal"));
            rewriteCheckBox.setSelected(state.selectedTransactions.contains("Rewrite"));
        }

        for(Map.Entry<String, Vector<Vector>> entry : state.allTableData.entrySet()) {
            ComponentData data = componentDataMap.get(entry.getKey());
            if(data != null) {
                loadTableData(data.model, entry.getValue());
            }
        }
        
        // Load enabled components state
        if (state.enabledComponents != null) {
            enabledComponents.clear();
            enabledComponents.putAll(state.enabledComponents);
            updateComponentVisibility();
        }
    }
    
    @SuppressWarnings({"rawtypes", "unchecked"})
    private void loadTableData(DefaultTableModel model, Vector<Vector> data) {
        model.setRowCount(0); 
        if (data != null) {
            for (Vector row : data) {
                model.addRow(row);
            }
        }
    }
    
    private void manageCustomComponents() {
        new CustomComponentManagerDialog(this, customComponents).setVisible(true);
    }
    
    void saveCustomComponents() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("custom_components.ser"))) {
            oos.writeObject(customComponents);
        } catch (IOException e) {
            showError("Could not save custom components: " + e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    private void loadCustomComponents() {
        File customFile = new File("custom_components.ser");
        if(customFile.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(customFile))) {
                customComponents.clear();
                customComponents.addAll((List<CustomComponentModel>) ois.readObject());
                
                // Ensure custom components are in enabledComponents map
                for (CustomComponentModel comp : customComponents) {
                    enabledComponents.putIfAbsent(comp.name, true);
                }
            } catch (IOException | ClassNotFoundException e) {
                showError("Could not load custom components: " + e.getMessage());
            }
        }
    }
    
    void rebuildCustomComponentTabs() {
        // Remove old custom components
        for(String key : new ArrayList<>(componentDataMap.keySet())) {
            if(findCustomComponentByName(key) != null) {
                componentDataMap.remove(key);
            }
        }
        for (int i = mainTabbedPane.getTabCount() - 1; i >= 0; i--) {
            String tabTitle = mainTabbedPane.getTitleAt(i);
            if(!isPredefined(tabTitle)) {
                 mainTabbedPane.remove(i);
            }
        }
        
        // Add new custom components
        for (CustomComponentModel custom : customComponents) {
            if (!componentDataMap.containsKey(custom.name)) {
                List<String> columns = new ArrayList<>(custom.uiFields != null ? custom.uiFields : new ArrayList<>());
                columns.add("Actions");
                ComponentData data = new ComponentData(columns.toArray(new String[0]), "Add " + custom.name);
                componentDataMap.put(custom.name, data);
                
                data.addButton.addActionListener(e -> openEditDialog(-1, custom.name));
                data.generateButton.addActionListener(e -> openGenerateDialog(custom.name));
                setupTable(data.table, custom.name);
                
                // Only add tab if component is enabled
                if (isComponentEnabled(custom.name)) {
                    mainTabbedPane.addTab(custom.name, createComponentTabPanel(data.addButton, data.generateButton, data.table));
                }
            }
        }
    }
    
    private boolean isPredefined(String name) {
        return Arrays.asList("Header", "Footer", "Dynamic", "Logo", "Date", "Page", "Policy").contains(name);
    }
    
    private CustomComponentModel findCustomComponentByName(String name) {
        return customComponents.stream().filter(c -> c.name.equals(name)).findFirst().orElse(null);
    }
    
    public List<CustomComponentModel> getCustomComponents(){
        return this.customComponents;
    }
    
    public List<TestScenario> getTestScenarios() {
        return this.testScenarios;
    }
    
    // Check if a component is enabled
    private boolean isComponentEnabled(String componentName) {
        return enabledComponents.getOrDefault(componentName, true);
    }
    
    // Manage all components
    private void manageComponents() {
        new ComponentManagerDialog(this, enabledComponents).setVisible(true);
    }
    
    // Update UI after changing component visibility
    public void updateComponentVisibility() {
        // Rebuild the main tabbed pane
        mainTabbedPane.removeAll();
        
        // Add enabled components
        for (Map.Entry<String, ComponentData> entry : componentDataMap.entrySet()) {
            if (isComponentEnabled(entry.getKey())) {
                mainTabbedPane.addTab(entry.getKey(), createComponentTabPanel(
                    entry.getValue().addButton, 
                    entry.getValue().generateButton, 
                    entry.getValue().table
                ));
            }
        }
        
        // Add enabled custom components
        rebuildCustomComponentTabs();
        
        // Refresh the UI
        revalidate();
        repaint();
    }
    
    private void exportDataToExcel() {
        stopAllTableEditing();
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Export Data to Excel File");
        fc.setFileFilter(new FileNameExtensionFilter("Excel Files (*.xlsx)", "xlsx"));
        fc.setSelectedFile(new File("data_export.xlsx"));
        if(fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try (Workbook wb = new SXSSFWorkbook()) {
                Sheet formSheet = wb.createSheet("_FormData");
                int rowNum = 0;
                for(DynamicFormField field : dynamicFormFields){
                    formSheet.createRow(rowNum).createCell(0).setCellValue(field.label);
                    formSheet.getRow(rowNum++).createCell(1).setCellValue(dynamicFieldTextFields.get(field.placeholder).getText());
                }
                
                Row transHeader = formSheet.createRow(rowNum++);
                transHeader.createCell(0).setCellValue("Transactions");
                int transCol = 1;
                for(String trans : getSelectedTransactions()){
                    transHeader.createCell(transCol++).setCellValue(trans);
                }
                for(Map.Entry<String, ComponentData> entry : componentDataMap.entrySet()) {
                    Sheet sheet = wb.createSheet(entry.getKey());
                    DefaultTableModel model = entry.getValue().model;
                    
                    Row headerRow = sheet.createRow(0);
                    for(int i = 0; i < model.getColumnCount() - 1; i++) { 
                        headerRow.createCell(i).setCellValue(model.getColumnName(i));
                    }
                    for(int i = 0; i < model.getRowCount(); i++) {
                        Row row = sheet.createRow(i + 1);
                        for(int j = 0; j < model.getColumnCount() - 1; j++) {
                           row.createCell(j).setCellValue(model.getValueAt(i, j).toString());
                        }
                    }
                }
                try (FileOutputStream fos = new FileOutputStream(fc.getSelectedFile())) {
                    wb.write(fos);
                    JOptionPane.showMessageDialog(this, "Data exported successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (IOException ex) {
                showError("Error exporting data: " + ex.getMessage());
            }
        }
    }
    
    private void importDataFromExcel() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Import Data from Excel File");
        fc.setFileFilter(new FileNameExtensionFilter("Excel Files (*.xlsx)", "xlsx"));
        if(fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try (FileInputStream fis = new FileInputStream(fc.getSelectedFile()); Workbook wb = new XSSFWorkbook(fis)) {
                Sheet formSheet = wb.getSheet("_FormData");
                if(formSheet != null) {
                    for(DynamicFormField field : dynamicFormFields){
                        for(Row row : formSheet){
                            if(row.getCell(0) != null && field.label.equals(row.getCell(0).getStringCellValue())){
                                dynamicFieldTextFields.get(field.placeholder).setText(row.getCell(1).getStringCellValue());
                            }
                        }
                    }
                    
                    Row transHeader = formSheet.getRow(dynamicFormFields.size());
                    if(transHeader != null && "Transactions".equals(transHeader.getCell(0).getStringCellValue())){
                        List<String> trans = new ArrayList<>();
                        for(int i=1; i < transHeader.getLastCellNum(); i++) {
                            trans.add(transHeader.getCell(i).getStringCellValue());
                        }
                        newBusinessCheckBox.setSelected(trans.contains("New Business"));
                        endorsementCheckBox.setSelected(trans.contains("Endorsement"));
                        renewalCheckBox.setSelected(trans.contains("Renewal"));
                        rewriteCheckBox.setSelected(trans.contains("Rewrite"));
                    }
                }
                
                for (Sheet sheet : wb) {
                    if("_FormData".equals(sheet.getSheetName())) continue;
                    ComponentData data = componentDataMap.get(sheet.getSheetName());
                    if(data != null) {
                        DefaultTableModel model = data.model;
                        model.setRowCount(0);
                        DataFormatter formatter = new DataFormatter();
                        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                            Row row = sheet.getRow(i);
                            Vector<String> rowData = new Vector<>();
                            for(int j = 0; j < model.getColumnCount() - 1; j++) {
                                rowData.add(formatter.formatCellValue(row.getCell(j)));
                            }
                            model.addRow(rowData);
                        }
                    }
                }
                 JOptionPane.showMessageDialog(this, "Data imported successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                showError("Error importing data: " + ex.getMessage());
            }
        }
    }
    
    private void stopAllTableEditing() {
        for(ComponentData data : componentDataMap.values()) {
            if(data.table.isEditing()) {
                data.table.getCellEditor().stopCellEditing();
            }
        }
    }
    
    private void openFindAndReplaceDialog() {
        stopAllTableEditing();
        new FindAndReplaceDialog(this, componentDataMap).setVisible(true);
    }
    
    private void manageTestScenarios() {
        new TestScenarioManagerDialog(this, testScenarios, componentDataMap).setVisible(true);
    }
    
    private void loadTestScenario() {
        if(testScenarios.isEmpty()){
            JOptionPane.showMessageDialog(this, "No scenarios found. Please create one first via the Manage menu.", "No Scenarios", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        String[] scenarioNames = testScenarios.stream().map(s -> s.name).toArray(String[]::new);
        String selected = (String) JOptionPane.showInputDialog(this, "Select a scenario to load:", "Load Scenario", JOptionPane.QUESTION_MESSAGE, null, scenarioNames, scenarioNames[0]);
        
        if(selected != null) {
            TestScenario scenario = testScenarios.stream().filter(s -> s.name.equals(selected)).findFirst().orElse(null);
            if(scenario != null) {
                for (Map.Entry<String, Vector<Vector<Object>>> entry : scenario.scenarioData.entrySet()) {
                    ComponentData compData = componentDataMap.get(entry.getKey());
                    if (compData != null) {
                        DefaultTableModel currentModel = (DefaultTableModel) compData.table.getModel();
                        currentModel.setRowCount(0);
                        for(Vector<Object> row : entry.getValue()){
                            currentModel.addRow(new Vector<>(row)); // Clone the row
                        }
                    }
                }
                statusLabel.setText("Scenario '" + selected + "' loaded successfully.");
            }
        }
    }
    
    void saveTestScenarios() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("scenarios.ser"))) {
            oos.writeObject(testScenarios);
        } catch (IOException e) {
            showError("Could not save scenarios: " + e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    private void loadTestScenarios() {
        File scenarioFile = new File("scenarios.ser");
        if(scenarioFile.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(scenarioFile))) {
                testScenarios.clear();
                testScenarios.addAll((List<TestScenario>) ois.readObject());
            } catch (IOException | ClassNotFoundException e) {
                showError("Could not load scenarios: " + e.getMessage());
            }
        }
    }
    
    private void previewOutput() {
        stopAllTableEditing();
        List<String> selectedTransactions = getSelectedTransactions();
        if (selectedTransactions.isEmpty()) {
            showError("Please select at least one transaction type to preview.");
            return;
        }

        try (Workbook previewWorkbook = new XSSFWorkbook()) {
            processSingleTransactionSheet(previewWorkbook, selectedTransactions.get(0));
            new PreviewDialog(this, previewWorkbook.getSheetAt(0)).setVisible(true);
        } catch (IOException e) {
            showError("Error generating preview: " + e.getMessage());
        }
    }
    
    private void manageDynamicFormFields(){
        new DynamicFormFieldManagerDialog(this, this.dynamicFormFields).setVisible(true);
    }

    void saveDynamicFormFields() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("dynamic_form_fields.ser"))) {
            oos.writeObject(dynamicFormFields);
        } catch (IOException e) {
            showError("Could not save dynamic form fields: " + e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    private void loadDynamicFormFields() {
        File fieldsFile = new File("dynamic_form_fields.ser");
        if(fieldsFile.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fieldsFile))) {
                dynamicFormFields.clear();
                dynamicFormFields.addAll((List<DynamicFormField>) ois.readObject());
            } catch (IOException | ClassNotFoundException e) {
                showError("Could not load dynamic form fields: " + e.getMessage());
            }
        } else {
            // Create default fields if none exist
            dynamicFormFields.add(new DynamicFormField("Form ID", "{{formID}}"));
            dynamicFormFields.add(new DynamicFormField("Form Name", "{{formName}}"));
            dynamicFormFields.add(new DynamicFormField("State", "{{state}}"));
        }
    }
    
    public void updateFormDisplay() {
        if(topWrapperPanel != null && topWrapperPanel.getComponentCount() > 1){
            topWrapperPanel.remove(1);
            topWrapperPanel.add(createTopInputPanel(), BorderLayout.CENTER);
            topWrapperPanel.revalidate();
            topWrapperPanel.repaint();
        }
    }
    
    class ButtonColumnEditor extends DefaultCellEditor {
        private String type;
        private int row;
        public ButtonColumnEditor(JCheckBox cb, String type) {
            super(cb);
            this.type = type;
        }
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.row = row;
            
            JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 5));
            panel.setOpaque(true);
            panel.setBackground(table.getSelectionBackground());
            JButton editButton = new JButton("Edit");
            JButton deleteButton = new JButton("Delete");
            JButton duplicateButton = new JButton("Duplicate");
            styleTableButton(editButton, new Color(80, 150, 220), Color.WHITE);
            styleTableButton(deleteButton, new Color(220, 85, 85), Color.WHITE);
            styleTableButton(duplicateButton, new Color(255, 152, 0), Color.WHITE);
            panel.add(editButton);
            panel.add(deleteButton);
            panel.add(duplicateButton);
            editButton.addActionListener(e -> {
                fireEditingStopped();
                openEditDialog(row, type);
            });
            deleteButton.addActionListener(e -> {
                fireEditingStopped();
                handleDeleteAction();
            });
            duplicateButton.addActionListener(e -> {
                fireEditingStopped();
                handleDuplicateAction();
            });
            return panel;
        }
        
        private void handleDeleteAction() {
            if (JOptionPane.showConfirmDialog(ExcelSheetExporter.this, "Delete this row?", "Confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                SwingUtilities.invokeLater(() -> {
                    DefaultTableModel model = componentDataMap.get(type).model;
                    if (row < model.getRowCount()) {
                        model.removeRow(row);
                    }
                });
            }
        }
        private void handleDuplicateAction() {
            SwingUtilities.invokeLater(() -> {
                DefaultTableModel model = componentDataMap.get(type).model;
                if (row < model.getRowCount()) {
                    @SuppressWarnings("unchecked")
                    Vector<Object> rowData = (Vector<Object>) model.getDataVector().get(row);
                    model.addRow(new Vector<>(rowData)); // Fixed: Use copy constructor
                }
            });
        }
        @Override
        public Object getCellEditorValue() {
            return null;
        }
    }
    
    class ButtonColumnRenderer extends JPanel implements TableCellRenderer {
        public ButtonColumnRenderer(String type) {
            super(new FlowLayout(FlowLayout.CENTER, 8, 5));
            setOpaque(true);
            JButton edit = new JButton("Edit"), delete = new JButton("Delete"), duplicate = new JButton("Duplicate");
            styleTableButton(edit, new Color(80, 150, 220), Color.WHITE);
            styleTableButton(delete, new Color(220, 85, 85), Color.WHITE);
            styleTableButton(duplicate, new Color(255, 152, 0), Color.WHITE);
            add(edit);
            add(delete);
            add(duplicate);
        }
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            setBackground(sel ? t.getSelectionBackground() : (r % 2 == 0 ? t.getBackground() : new Color(248, 248, 248)));
            return this;
        }
    }
    
    // =============== MODERN COMPONENT MANAGER DIALOG ===============
    class ComponentManagerDialog extends JDialog {
        private final Map<String, Boolean> originalEnabledComponents;
        private final Map<String, Boolean> modifiedEnabledComponents;
        
        public ComponentManagerDialog(JFrame owner, Map<String, Boolean> enabledComponents) {
            super(owner, "Manage Components", true);
            this.originalEnabledComponents = enabledComponents;
            this.modifiedEnabledComponents = new LinkedHashMap<>(enabledComponents);
            
            setSize(450, 500);
            setLocationRelativeTo(owner);
            setLayout(new BorderLayout(10, 10));
            
            // Header panel
            JPanel headerPanel = new JPanel();
            headerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            JLabel titleLabel = new JLabel("Component Visibility");
            titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
            headerPanel.add(titleLabel);
            add(headerPanel, BorderLayout.NORTH);
            
            // Main component list
            JPanel componentPanel = new JPanel();
            componentPanel.setLayout(new BoxLayout(componentPanel, BoxLayout.Y_AXIS));
            componentPanel.setBorder(new EmptyBorder(10, 20, 10, 20));
            
            for (String component : modifiedEnabledComponents.keySet()) {
                JPanel compPanel = new JPanel(new BorderLayout(10, 0));
                compPanel.setBorder(new EmptyBorder(5, 0, 5, 0));
                compPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
                
                JLabel label = new JLabel(component);
                label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                
                JToggleButton toggle = new JToggleButton();
                toggle.setSelected(modifiedEnabledComponents.get(component));
                toggle.setPreferredSize(new Dimension(70, 30));
                toggle.setFocusPainted(false);
                styleToggleButton(toggle);
                
                toggle.addActionListener(e -> {
                    boolean selected = toggle.isSelected();
                    modifiedEnabledComponents.put(component, selected);
                    styleToggleButton(toggle);
                });
                
                compPanel.add(label, BorderLayout.WEST);
                compPanel.add(toggle, BorderLayout.EAST);
                componentPanel.add(compPanel);
                componentPanel.add(Box.createVerticalStrut(10));
            }
            
            JScrollPane scrollPane = new JScrollPane(componentPanel);
            scrollPane.setBorder(BorderFactory.createEmptyBorder());
            add(scrollPane, BorderLayout.CENTER);
            
            // Footer buttons
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            
            JButton saveButton = new JButton("Save Changes");
            saveButton.addActionListener(e -> saveChanges());
            stylePrimaryButton(saveButton);
            buttonPanel.add(saveButton);
            
            JButton closeButton = new JButton("Cancel");
            closeButton.addActionListener(e -> dispose());
            buttonPanel.add(closeButton);
            
            add(buttonPanel, BorderLayout.SOUTH);
        }
        
        private void styleToggleButton(JToggleButton toggle) {
            if (toggle.isSelected()) {
                toggle.setText("ON");
                toggle.setBackground(new Color(76, 175, 80)); // Green
                toggle.setForeground(Color.WHITE);
            } else {
                toggle.setText("OFF");
                toggle.setBackground(new Color(244, 67, 54)); // Red
                toggle.setForeground(Color.WHITE);
            }
            toggle.setFont(new Font("Segoe UI", Font.BOLD, 12));
            toggle.setBorder(new LineBorder(Color.GRAY, 1));
        }
        
        private void saveChanges() {
            // Update the main application's state
            ExcelSheetExporter.this.enabledComponents.clear();
            ExcelSheetExporter.this.enabledComponents.putAll(modifiedEnabledComponents);
            
            // Update the UI
            ExcelSheetExporter.this.updateComponentVisibility();
            
            // Save the configuration
            ExcelSheetExporter.this.saveConfiguration();
            
            dispose();
        }
    }
    
    // =============== MAIN METHOD =============== 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ExcelSheetExporter exporter = new ExcelSheetExporter();
            exporter.setVisible(true);
        });
    }
}

// =============== SUPPORTING DIALOG CLASSES =============== 

class CustomComponentManagerDialog extends JDialog {
    private final List<ExcelSheetExporter.CustomComponentModel> customComponents;
    private final DefaultListModel<String> listModel = new DefaultListModel<>();
    private final JList<String> componentList = new JList<>(listModel);
    
    private final JTextField nameField = new JTextField();
    private final JTextField blockIdField = new JTextField();
    private final JPanel fieldsPanel = new JPanel();
    
    private final ExcelSheetExporter parentFrame;
    public CustomComponentManagerDialog(JFrame owner, List<ExcelSheetExporter.CustomComponentModel> components) {
        super(owner, "Manage Custom Components", true);
        this.parentFrame = (ExcelSheetExporter) owner;
        this.customComponents = new ArrayList<>(components); // Work on a copy
        
        setSize(800, 600);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10, 10));
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        JPanel listPanel = new JPanel(new BorderLayout());
        listPanel.setBorder(BorderFactory.createTitledBorder("Components"));
        listPanel.add(new JScrollPane(componentList), BorderLayout.CENTER);
        
        JPanel listButtons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton addButton = new JButton("Add");
        JButton deleteButton = new JButton("Delete");
        listButtons.add(addButton);
        listButtons.add(deleteButton);
        listPanel.add(listButtons, BorderLayout.SOUTH);
        splitPane.setLeftComponent(listPanel);
        JPanel editorPanel = new JPanel(new BorderLayout(10, 10));
        editorPanel.setBorder(BorderFactory.createTitledBorder("Component Details"));
        
        JPanel topEditorPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        topEditorPanel.add(new JLabel("UI Tab Name:"));
        topEditorPanel.add(nameField);
        topEditorPanel.add(new JLabel("Block Identifier (in Excel):"));
        topEditorPanel.add(blockIdField);
        
        fieldsPanel.setLayout(new BoxLayout(fieldsPanel, BoxLayout.Y_AXIS));
        JScrollPane fieldsScrollPane = new JScrollPane(fieldsPanel);
        fieldsScrollPane.setBorder(BorderFactory.createTitledBorder("UI Fields & Placeholders"));
        JButton addFieldButton = new JButton("Add Value Field");
        
        editorPanel.add(topEditorPanel, BorderLayout.NORTH);
        editorPanel.add(fieldsScrollPane, BorderLayout.CENTER);
        editorPanel.add(addFieldButton, BorderLayout.SOUTH);
        
        splitPane.setRightComponent(editorPanel);
        splitPane.setDividerLocation(250);
        
        JPanel bottomButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save and Close");
        JButton cancelButton = new JButton("Cancel");
        bottomButtons.add(saveButton);
        bottomButtons.add(cancelButton);
        add(splitPane, BorderLayout.CENTER);
        add(bottomButtons, BorderLayout.SOUTH);
        componentList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                displayComponentDetails(componentList.getSelectedIndex());
            }
        });
        addButton.addActionListener(e -> addNewComponent());
        deleteButton.addActionListener(e -> deleteSelectedComponent());
        addFieldButton.addActionListener(e -> addFieldRow(null, null));
        saveButton.addActionListener(e -> saveAndClose());
        cancelButton.addActionListener(e -> setVisible(false));
        
        refreshComponentList();
    }
    private void refreshComponentList() {
        listModel.clear();
        for (ExcelSheetExporter.CustomComponentModel component : customComponents) {
            listModel.addElement(component.name);
        }
    }
    private void displayComponentDetails(int index) {
        if (index < 0) {
            nameField.setText("");
            blockIdField.setText("");
            fieldsPanel.removeAll();
            fieldsPanel.revalidate();
            fieldsPanel.repaint();
            return;
        }
        
        ExcelSheetExporter.CustomComponentModel component = customComponents.get(index);
        nameField.setText(component.name);
        blockIdField.setText(component.blockIdentifier);
        
        fieldsPanel.removeAll();
        if(component.uiFields != null) {
            for (int i = 0; i < component.uiFields.size(); i++) {
                addFieldRow(component.uiFields.get(i), component.placeholders.get(i));
            }
        }
        fieldsPanel.revalidate();
        fieldsPanel.repaint();
    }
    
    private void addFieldRow(String uiName, String placeholder) {
        JPanel rowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField uiField = new JTextField(15);
        if(uiName != null) uiField.setText(uiName);
        
        JTextField placeholderField = new JTextField(15);
        if(placeholder != null) placeholderField.setText(placeholder);
        
        JButton removeButton = new JButton("X");
        removeButton.setForeground(Color.RED);
        
        rowPanel.add(new JLabel("UI Field:"));
        rowPanel.add(uiField);
        rowPanel.add(new JLabel("Placeholder:"));
        rowPanel.add(placeholderField);
        rowPanel.add(removeButton);
        
        removeButton.addActionListener(e -> {
            fieldsPanel.remove(rowPanel);
            fieldsPanel.revalidate();
            fieldsPanel.repaint();
        });
        
        fieldsPanel.add(rowPanel);
        fieldsPanel.revalidate();
        fieldsPanel.repaint();
    }
    private void addNewComponent() {
        componentList.clearSelection();
        displayComponentDetails(-1);
    }
    
    private void deleteSelectedComponent() {
        int selectedIndex = componentList.getSelectedIndex();
        if (selectedIndex != -1) {
            int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this component?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (response == JOptionPane.YES_OPTION) {
                customComponents.remove(selectedIndex);
                refreshComponentList();
                displayComponentDetails(-1);
            }
        }
    }
    
    private void saveAndClose() {
        int selectedIndex = componentList.getSelectedIndex();
        if (selectedIndex != -1) {
            saveComponentDetails(selectedIndex);
        } else if (!nameField.getText().trim().isEmpty()) {
             saveComponentDetails(-1);
        }
        parentFrame.getCustomComponents().clear();
        parentFrame.getCustomComponents().addAll(this.customComponents);
        parentFrame.saveCustomComponents();
        parentFrame.rebuildCustomComponentTabs();
        
        setVisible(false);
    }
    private void saveComponentDetails(int index) {
        ExcelSheetExporter.CustomComponentModel component;
        if(index == -1) {
            component = new ExcelSheetExporter.CustomComponentModel();
            customComponents.add(component);
        } else {
            component = customComponents.get(index);
        }
        
        component.name = nameField.getText();
        component.blockIdentifier = blockIdField.getText();
        component.uiFields = new ArrayList<>();
        component.placeholders = new ArrayList<>();
        for (Component rowComp : fieldsPanel.getComponents()) {
            if (rowComp instanceof JPanel) {
                JPanel rowPanel = (JPanel) rowComp;
                JTextField uiField = (JTextField) rowPanel.getComponent(1);
                JTextField placeholderField = (JTextField) rowPanel.getComponent(3);
                component.uiFields.add(uiField.getText());
                component.placeholders.add(placeholderField.getText());
            }
        }
        refreshComponentList();
        componentList.setSelectedIndex(customComponents.indexOf(component));
    }
}

class FindAndReplaceDialog extends JDialog {
    private final ExcelSheetExporter parentFrame;
    private final Map<String, JCheckBox> scopeCheckBoxes = new LinkedHashMap<>();
    private final JTextField findField = new JTextField(20);
    private final JTextField replaceField = new JTextField(20);
    private final JCheckBox caseSensitiveCheckBox = new JCheckBox("Case Sensitive");
    
    private int findRow = 0;
    private int findCol = -1;
    private int findTabIndex = 0;
    public FindAndReplaceDialog(ExcelSheetExporter owner, Map<String, ExcelSheetExporter.ComponentData> componentDataMap) {
        super(owner, "Find and Replace", false);
        this.parentFrame = owner;
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        JPanel fieldsPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        fieldsPanel.add(new JLabel("Find what:"));
        fieldsPanel.add(findField);
        fieldsPanel.add(new JLabel("Replace with:"));
        fieldsPanel.add(replaceField);
        fieldsPanel.add(caseSensitiveCheckBox);
        
        JPanel scopePanel = new JPanel(new GridLayout(0, 3));
        scopePanel.setBorder(BorderFactory.createTitledBorder("Scope"));
        for(String componentName : componentDataMap.keySet()) {
            JCheckBox cb = new JCheckBox(componentName, true);
            scopeCheckBoxes.put(componentName, cb);
            scopePanel.add(cb);
        }
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton findNextButton = new JButton("Find Next");
        JButton replaceButton = new JButton("Replace");
        JButton replaceAllButton = new JButton("Replace All");
        JButton cancelButton = new JButton("Cancel");
        
        buttonPanel.add(findNextButton);
        buttonPanel.add(replaceButton);
        buttonPanel.add(replaceAllButton);
        buttonPanel.add(cancelButton);
        
        mainPanel.add(fieldsPanel, BorderLayout.NORTH);
        mainPanel.add(scopePanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
        pack();
        setLocationRelativeTo(owner);
        
        findNextButton.addActionListener(e -> findNext());
        replaceButton.addActionListener(e -> replaceCurrent());
        replaceAllButton.addActionListener(e -> replaceAll());
        cancelButton.addActionListener(e -> setVisible(false));
    }
    private void findNext() {
        String findText = findField.getText();
        if(findText.isEmpty()) return;
        boolean caseSensitive = caseSensitiveCheckBox.isSelected();
        List<String> selectedScopes = scopeCheckBoxes.entrySet().stream()
            .filter(e -> e.getValue().isSelected())
            .map(Map.Entry::getKey)
            .collect(Collectors.toList());
        JTabbedPane tabbedPane = parentFrame.mainTabbedPane;
        for (int i = findTabIndex; i < tabbedPane.getTabCount(); i++) {
            String title = tabbedPane.getTitleAt(i);
            if(selectedScopes.contains(title)) {
                JTable table = ((ExcelSheetExporter.ComponentData)parentFrame.componentDataMap.get(title)).table;
                for (int r = findRow; r < table.getRowCount(); r++) {
                    for (int c = (r == findRow) ? findCol + 1 : 0; c < table.getColumnCount() -1; c++) {
                        String cellValue = table.getValueAt(r, c).toString();
                        String textToSearch = caseSensitive ? cellValue : cellValue.toLowerCase();
                        String find = caseSensitive ? findText : findText.toLowerCase();
                        if(textToSearch.contains(find)) {
                            tabbedPane.setSelectedIndex(i);
                            table.setRowSelectionInterval(r, r);
                            table.setColumnSelectionInterval(c, c);
                            table.scrollRectToVisible(table.getCellRect(r, c, true));
                            findTabIndex = i;
                            findRow = r;
                            findCol = c;
                            return;
                        }
                    }
                }
            }
            findRow = 0;
            findCol = -1;
        }
        // Reset search if nothing was found
        findTabIndex = 0;
        findRow = 0;
        findCol = -1;
        JOptionPane.showMessageDialog(this, "End of search.", "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    private void replaceCurrent() {
        JTable currentTable = parentFrame.componentDataMap.get(parentFrame.mainTabbedPane.getTitleAt(findTabIndex)).table;
        if(currentTable.getSelectedRow() != -1){
            int r = currentTable.getSelectedRow();
            int c = currentTable.getSelectedColumn();
            String findText = findField.getText();
            String replaceText = replaceField.getText();
            boolean caseSensitive = caseSensitiveCheckBox.isSelected();
            String cellValue = currentTable.getValueAt(r, c).toString();
            String textToSearch = caseSensitive ? cellValue : cellValue.toLowerCase();
            String find = caseSensitive ? findText : findText.toLowerCase();
            if(textToSearch.contains(find)){
                String newValue = cellValue.replaceAll("(?i)" + findText, replaceText);
                currentTable.setValueAt(newValue, r, c);
            }
        }
        findNext();
    }
    
    private void replaceAll() {
        String findText = findField.getText();
        String replaceText = replaceField.getText();
        if(findText.isEmpty()) return;
        boolean caseSensitive = caseSensitiveCheckBox.isSelected();
        int count = 0;
        for(Map.Entry<String, JCheckBox> scopeEntry : scopeCheckBoxes.entrySet()){
            if(scopeEntry.getValue().isSelected()){
                JTable table = parentFrame.componentDataMap.get(scopeEntry.getKey()).table;
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                for(int r=0; r < model.getRowCount(); r++){
                    for(int c=0; c < model.getColumnCount() -1; c++){
                        String cellValue = model.getValueAt(r, c).toString();
                        String textToSearch = caseSensitive ? cellValue : cellValue.toLowerCase();
                        String find = caseSensitive ? findText : findText.toLowerCase();
                        if(textToSearch.contains(find)){
                            String newValue = cellValue.replaceAll("(?i)" + findText, replaceText);
                            model.setValueAt(newValue, r, c);
                            count++;
                        }
                    }
                }
            }
        }
        JOptionPane.showMessageDialog(this, count + " replacements made.", "Replace All", JOptionPane.INFORMATION_MESSAGE);
    }
}

class TestScenarioManagerDialog extends JDialog {
    private final List<ExcelSheetExporter.TestScenario> testScenarios;
    private final Map<String, ExcelSheetExporter.ComponentData> componentDataMap;
    private final DefaultListModel<String> listModel = new DefaultListModel<>();
    private final JList<String> scenarioList = new JList<>(listModel);
    
    private final JTabbedPane componentTabbedPane = new JTabbedPane();
    
    private final ExcelSheetExporter parentFrame;
    private int currentlyEditingIndex = -1;
    private boolean isProgrammaticSelectionChange = false;

    public TestScenarioManagerDialog(JFrame owner, List<ExcelSheetExporter.TestScenario> scenarios, Map<String, ExcelSheetExporter.ComponentData> components) {
        super(owner, "Manage Test Scenarios", true);
        this.parentFrame = (ExcelSheetExporter) owner;
        this.testScenarios = new ArrayList<>();
        for(ExcelSheetExporter.TestScenario scenario : scenarios) {
            this.testScenarios.add(cloneScenario(scenario));
        }
        
        this.componentDataMap = components;
        
        setSize(900, 700);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10, 10));
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        JPanel listPanel = new JPanel(new BorderLayout());
        listPanel.setBorder(BorderFactory.createTitledBorder("Scenarios"));
        listPanel.add(new JScrollPane(scenarioList), BorderLayout.CENTER);
        
        JPanel listButtons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton addButton = new JButton("Add");
        JButton renameButton = new JButton("Rename");
        JButton deleteButton = new JButton("Delete");
        listButtons.add(addButton);
        listButtons.add(renameButton);
        listButtons.add(deleteButton);
        listPanel.add(listButtons, BorderLayout.SOUTH);
        splitPane.setLeftComponent(listPanel);
        componentTabbedPane.setBorder(BorderFactory.createTitledBorder("Select Components for Scenario"));
        splitPane.setRightComponent(componentTabbedPane);
        splitPane.setDividerLocation(200);
        
        JPanel bottomButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save and Close");
        JButton cancelButton = new JButton("Cancel");
        bottomButtons.add(saveButton);
        bottomButtons.add(cancelButton);
        add(splitPane, BorderLayout.CENTER);
        add(bottomButtons, BorderLayout.SOUTH);
        scenarioList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && !isProgrammaticSelectionChange) {
                if(currentlyEditingIndex != -1 && currentlyEditingIndex < testScenarios.size()) {
                    saveScenarioDetails(currentlyEditingIndex);
                }
                displayScenarioDetails(scenarioList.getSelectedIndex());
                currentlyEditingIndex = scenarioList.getSelectedIndex();
            }
        });
        
        addButton.addActionListener(e -> addNewScenario());
        renameButton.addActionListener(e -> renameSelectedScenario());
        deleteButton.addActionListener(e -> deleteSelectedScenario());
        saveButton.addActionListener(e -> saveAndClose());
        cancelButton.addActionListener(e -> setVisible(false));
        
        refreshScenarioList();
        if(!testScenarios.isEmpty()){
            scenarioList.setSelectedIndex(0);
        }
    }
    
    private ExcelSheetExporter.TestScenario cloneScenario(ExcelSheetExporter.TestScenario original){
        ExcelSheetExporter.TestScenario copy = new ExcelSheetExporter.TestScenario();
        copy.name = original.name;
        copy.scenarioData = new HashMap<>();
        if(original.scenarioData != null){
            for(Map.Entry<String, Vector<Vector<Object>>> entry : original.scenarioData.entrySet()){
                // Create deep copy of the outer vector
                Vector<Vector<Object>> outerVector = new Vector<>();
                for (Vector<Object> innerVector : entry.getValue()) {
                    // Create shallow copy of inner vector (elements are Strings/immutable)
                    outerVector.add(new Vector<>(innerVector));
                }
                copy.scenarioData.put(entry.getKey(), outerVector);
            }
        }
        copy.selectedRows = new HashMap<>();
        if(original.selectedRows != null){
            for(Map.Entry<String, List<Integer>> entry : original.selectedRows.entrySet()){
                 copy.selectedRows.put(entry.getKey(), new ArrayList<>(entry.getValue()));
            }
        }
        return copy;
    }
    
    private void refreshScenarioList() {
        isProgrammaticSelectionChange = true;
        listModel.clear();
        for (ExcelSheetExporter.TestScenario scenario : testScenarios) {
            listModel.addElement(scenario.name);
        }
        isProgrammaticSelectionChange = false;
    }
    private void displayScenarioDetails(int index) {
        componentTabbedPane.removeAll();
        if (index < 0 || index >= testScenarios.size()) {
            componentTabbedPane.repaint();
            return;
        }
        ExcelSheetExporter.TestScenario scenario = testScenarios.get(index);
        for (Map.Entry<String, ExcelSheetExporter.ComponentData> entry : componentDataMap.entrySet()) {
            JPanel panel = new JPanel(new BorderLayout());
            DefaultTableModel model = entry.getValue().model;
            JTable table = new JTable(model);
            table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            
            List<Integer> selectedRows = scenario.selectedRows.get(entry.getKey());
            if(selectedRows != null) {
                for(int rowIndex : selectedRows) {
                    if(rowIndex < table.getRowCount()){
                        table.addRowSelectionInterval(rowIndex, rowIndex);
                    }
                }
            }
            panel.add(new JScrollPane(table), BorderLayout.CENTER);
            componentTabbedPane.addTab(entry.getKey(), panel);
        }
        componentTabbedPane.repaint();
        componentTabbedPane.revalidate();
    }
    private void addNewScenario() {
        String name = JOptionPane.showInputDialog(this, "Enter scenario name:");
        if (name != null && !name.trim().isEmpty()) {
            ExcelSheetExporter.TestScenario newScenario = new ExcelSheetExporter.TestScenario();
            newScenario.name = name;
            testScenarios.add(newScenario);
            refreshScenarioList();
            scenarioList.setSelectedValue(name, true);
        }
    }
    private void renameSelectedScenario() {
        int selectedIndex = scenarioList.getSelectedIndex();
        if (selectedIndex != -1) {
            String newName = JOptionPane.showInputDialog(this, "Enter new name:", testScenarios.get(selectedIndex).name);
            if (newName != null && !newName.trim().isEmpty()) {
                testScenarios.get(selectedIndex).name = newName;
                refreshScenarioList();
                scenarioList.setSelectedIndex(selectedIndex);
            }
        }
    }
    
    private void deleteSelectedScenario() {
        int selectedIndex = scenarioList.getSelectedIndex();
        if (selectedIndex != -1) {
            int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this scenario?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (response == JOptionPane.YES_OPTION) {
                isProgrammaticSelectionChange = true;
                testScenarios.remove(selectedIndex);
                refreshScenarioList();
                componentTabbedPane.removeAll();
                componentTabbedPane.repaint();
                currentlyEditingIndex = -1;
                isProgrammaticSelectionChange = false;
            }
        }
    }
    private void saveAndClose() {
        int selectedIndex = scenarioList.getSelectedIndex();
        if (selectedIndex != -1) {
            saveScenarioDetails(selectedIndex);
        }
        
        parentFrame.getTestScenarios().clear();
        parentFrame.getTestScenarios().addAll(this.testScenarios);
        parentFrame.saveTestScenarios();
        
        setVisible(false);
    }
    private void saveScenarioDetails(int index) {
        if(index < 0 || index >= testScenarios.size()) return;
        ExcelSheetExporter.TestScenario scenario = testScenarios.get(index);
        scenario.selectedRows.clear();
        scenario.scenarioData.clear();
        
        for (int i = 0; i < componentTabbedPane.getTabCount(); i++) {
            String compName = componentTabbedPane.getTitleAt(i);
            Component tabContent = componentTabbedPane.getComponentAt(i);
            if (tabContent instanceof JScrollPane) {
                JTable table = (JTable) ((JScrollPane) tabContent).getViewport().getView();
                List<Integer> selectedRows = new ArrayList<>();
                Vector<Vector<Object>> selectedData = new Vector<>();
                for (int row : table.getSelectedRows()) {
                    selectedRows.add(row);
                    DefaultTableModel model = (DefaultTableModel) table.getModel();
                    // Create a new Vector for the row (shallow copy, elements are immutable)
                    selectedData.add(new Vector<>(model.getDataVector().get(row)));
                }
                scenario.selectedRows.put(compName, selectedRows);
                scenario.scenarioData.put(compName, selectedData);
            }
        }
    }
}

class PreviewDialog extends JDialog {
    public PreviewDialog(JFrame owner, Sheet sheet) {
        super(owner, "Preview", true);
        setSize(800, 600);
        setLocationRelativeTo(owner);
        
        DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        
        int maxCols = 0;
        for (Row row : sheet) {
            if(row.getLastCellNum() > maxCols) {
                maxCols = row.getLastCellNum();
            }
        }
        for(int i = 0; i < maxCols; i++){
            model.addColumn("Col " + (i + 1));
        }

        DataFormatter formatter = new DataFormatter();
        for (Row row : sheet) {
            Vector<Object> rowData = new Vector<>();
            for (int i = 0; i < maxCols; i++) {
                Cell cell = row.getCell(i, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                if(cell != null) {
                    rowData.add(formatter.formatCellValue(cell));
                } else {
                    rowData.add("");
                }
            }
            model.addRow(rowData);
        }
        
        add(new JScrollPane(table));
    }
}

class DynamicFormFieldManagerDialog extends JDialog {
    private final List<ExcelSheetExporter.DynamicFormField> dynamicFormFields;
    private final DefaultListModel<String> listModel = new DefaultListModel<>();
    private final JList<String> fieldList = new JList<>(listModel);
    
    public DynamicFormFieldManagerDialog(JFrame owner, List<ExcelSheetExporter.DynamicFormField> fields) {
        super(owner, "Manage Dynamic Form Fields", true);
        this.dynamicFormFields = new ArrayList<>(fields);
        
        setSize(500, 400);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10, 10));
        
        JPanel listPanel = new JPanel(new BorderLayout());
        listPanel.setBorder(BorderFactory.createTitledBorder("Form Fields"));
        listPanel.add(new JScrollPane(fieldList), BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton addButton = new JButton("Add");
        JButton editButton = new JButton("Edit");
        JButton deleteButton = new JButton("Delete");
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save and Close");
        JButton cancelButton = new JButton("Cancel");
        bottomPanel.add(saveButton);
        bottomPanel.add(cancelButton);

        add(listPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.NORTH);
        add(bottomPanel, BorderLayout.SOUTH);
        
        // Set component names for testing
        fieldList.setName("fieldList");
        addButton.setName("addButton");
        editButton.setName("editButton");
        deleteButton.setName("deleteButton");
        
        refreshFieldList();

        addButton.addActionListener(e -> addField());
        editButton.addActionListener(e -> editField());
        deleteButton.addActionListener(e -> deleteField());
        saveButton.addActionListener(e -> saveAndClose());
        cancelButton.addActionListener(e -> setVisible(false));
    }
    
    private void refreshFieldList() {
        listModel.clear();
        for (ExcelSheetExporter.DynamicFormField field : dynamicFormFields) {
            listModel.addElement(field.label + " (" + field.placeholder + ")");
        }
    }
    
    private void addField() {
        JTextField labelField = new JTextField();
        JTextField placeholderField = new JTextField();
        Object[] message = {
            "Label:", labelField,
            "Placeholder (e.g., {{myPlaceholder}}):", placeholderField
        };
        int option = JOptionPane.showConfirmDialog(this, message, "Add Field", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            dynamicFormFields.add(new ExcelSheetExporter.DynamicFormField(
                labelField.getText().trim(), 
                placeholderField.getText().trim()
            ));
            refreshFieldList();
        }
    }
    
    private void editField() {
        int selectedIndex = fieldList.getSelectedIndex();
        if (selectedIndex != -1) {
            ExcelSheetExporter.DynamicFormField field = dynamicFormFields.get(selectedIndex);
            JTextField labelField = new JTextField(field.label);
            JTextField placeholderField = new JTextField(field.placeholder);
            Object[] message = {
                "Label:", labelField,
                "Placeholder (e.g., {{myPlaceholder}}):", placeholderField
            };
            int option = JOptionPane.showConfirmDialog(this, message, "Edit Field", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                field.label = labelField.getText().trim();
                field.placeholder = placeholderField.getText().trim();
                refreshFieldList();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a field to edit", "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void deleteField() {
        int selectedIndex = fieldList.getSelectedIndex();
        if (selectedIndex != -1) {
            int response = JOptionPane.showConfirmDialog(
                this, 
                "Are you sure you want to delete this field?", 
                "Confirm Deletion", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.WARNING_MESSAGE
            );
            if (response == JOptionPane.YES_OPTION) {
                dynamicFormFields.remove(selectedIndex);
                refreshFieldList();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a field to delete", "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void saveAndClose() {
        ExcelSheetExporter parent = (ExcelSheetExporter) getOwner();
        parent.dynamicFormFields.clear();
        parent.dynamicFormFields.addAll(this.dynamicFormFields);
        parent.saveDynamicFormFields();
        parent.updateFormDisplay();
        setVisible(false);
    }
}