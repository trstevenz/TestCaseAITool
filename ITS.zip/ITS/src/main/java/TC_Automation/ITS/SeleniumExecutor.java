package TC_Automation.ITS;

//import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Set;
import java.util.function.Consumer;

/**
 * The core automation engine that executes test steps using Selenium.
 * Updated to handle a Before-Main-After action sequence for each step and dynamic file uploads.
 */
public class SeleniumExecutor {
    private WebDriver driver;
    private final Consumer<String> logger;
    private String originalWindowHandle;

    public enum Browser {CHROME, FIREFOX}

    public SeleniumExecutor(Consumer<String> logger) {
        this.logger = logger;
    }

    /**
     * Executes a full test case from start to finish.
     * @param testData The package containing the list of steps to execute.
     * @param browser  The browser to run the test on.
     * @param keepBrowserOpen If true, the browser will not be closed after the test.
     */
    public void executeTest(Tool2Panel.TestDataPackage testData, Browser browser, boolean keepBrowserOpen) {
        try {
            log("--- Test Execution Started: " + testData.getTabName() + " ---");
            setupDriver(browser);
            if (driver != null) originalWindowHandle = driver.getWindowHandle();
            for (Tool2Panel.TableRow row : testData.getTestSteps()) {
                if (row instanceof Tool2Panel.ElementDataRow) {
                    executeActionSequence((Tool2Panel.ElementDataRow) row);
                }
            }
            log("--- Test Execution Finished Successfully ---");
        } catch (Exception e) {
            log("FATAL ERROR: " + e.getMessage());
            e.printStackTrace();
            log("--- Test Execution Aborted ---");
        } finally {
            if (driver != null) {
                if (keepBrowserOpen) {
                    log("Test finished. Browser remains open as per setting.");
                } else {
                    driver.quit();
                    log("Browser closed as per setting.");
                }
            }
        }
    }

    private void setupDriver(Browser browser) {
        log("Setting up " + browser + " driver...");
        switch (browser) {
            case CHROME:
                // WebDriverManager.chromedriver().setup();
                ChromeOptions options = new ChromeOptions();
                //  options.addArguments("--headless", "--disable-gpu", "--window-size=1920,1080");
                options.addArguments("--allow-insecure-localhost", "--ignore-certificate-errors", "--no-sandbox", "--disable-dev-shm-usage");

                driver = new ChromeDriver(options);
                break;
            case FIREFOX:
                // WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;
        }
        driver.manage().window().maximize();
        log("Browser launched successfully.");
    }

    /**
     * Executes the Before, Main, and After actions for a single test step (a single row).
     */
    private void executeActionSequence(Tool2Panel.ElementDataRow step) throws Exception {
        log("Processing Element: '" + step.getElementName() + "'");
        // 1. Execute the "Before" action if it exists
        if (step.getBeforeAction() != null && !step.getBeforeAction().isEmpty()) {
            performSingleAction(step.getBeforeAction(), step, "[Before] ");
        }
        // 2. Execute the "Main" action if it exists
        if (step.getMainAction() != null && !step.getMainAction().isEmpty()) {
            performSingleAction(step.getMainAction(), step, "[Main] ");
        }
        // 3. Execute the "After" action if it exists
        if (step.getAfterAction() != null && !step.getAfterAction().isEmpty()) {
            performSingleAction(step.getAfterAction(), step, "[After] ");
        }
    }

    /**
     * Performs a single, atomic Selenium action.
     * @param action The name of the action to perform (e.g., "CLICK").
     * @param step The data row containing locator and test data.
     * @param logPrefix A prefix for logging to indicate the phase (Before/Main/After).
     */
    private void performSingleAction(String action, Tool2Panel.ElementDataRow step, String logPrefix) throws Exception {
        log(logPrefix + "EXECUTING: " + action);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement element = null;
        String upperCaseAction = action.toUpperCase();

        // Find the element only if the action requires it.
        if (!isBrowserAction(upperCaseAction) && !isWaitAction(upperCaseAction)) {
            By locator = getByFromLocator(step.getSelectedLocator());
            element = wait.until(ExpectedConditions.presenceOfElementLocated(locator));
        }
        switch (upperCaseAction) {
            case "NAVIGATE TO URL":
                driver.get(step.getTestData());
                break;
            case "CLICK":
                wait.until(ExpectedConditions.elementToBeClickable(element)).click();
                break;
            case "TYPE TEXT":
                element.clear();
                element.sendKeys(step.getTestData());
                break;
            case "UPLOAD FILE":
                Path filesFolderPath = Paths.get(System.getProperty("user.dir"), "Files");
                if (!Files.exists(filesFolderPath)) {
                    log(logPrefix + "Creating 'Files' directory at: " + filesFolderPath.toAbsolutePath());
                    Files.createDirectories(filesFolderPath);
                }
                String fileName = step.getTestData();
                Path filePath = filesFolderPath.resolve(fileName);
                if (!Files.exists(filePath)) {
                    throw new Exception("File not found in 'Files' folder: " + fileName + " (Expected at: " + filePath.toAbsolutePath() + ")");
                }
                log(logPrefix + "Uploading file from: " + filePath.toAbsolutePath());
                element.sendKeys(filePath.toAbsolutePath().toString());
                break;
            case "SELECT FROM DROPDOWN":
                handleDropdown(element, step.getTestData());
                break;
            case "SWITCH WINDOW/TAB":
                handleSwitchWindow();
                break;
            case "SWITCH TO MAIN WINDOW":
                Set<String> availableWindows = driver.getWindowHandles();
                if (availableWindows.contains(originalWindowHandle)) {
                    driver.switchTo().window(originalWindowHandle);
                } else if (!availableWindows.isEmpty()) {
                    log(logPrefix + "WARNING: Original window closed. Switching to next available window.");
                    String newMainWindow = availableWindows.iterator().next();
                    driver.switchTo().window(newMainWindow);
                    originalWindowHandle = newMainWindow;
                    log(logPrefix + "New main window is now: " + originalWindowHandle);
                } else {
                    throw new Exception("All browser windows are closed. Cannot continue test.");
                }
                break;
            case "SWITCH TO FRAME":
                driver.switchTo().frame(element);
                break;
            case "SWITCH TO DEFAULT":
                driver.switchTo().defaultContent();
                break;
            case "HANDLE PROMPTS/ALERTS":
                handleAlert(step.getTestData());
                break;
            case "EXECUTE JAVASCRIPT":
                ((JavascriptExecutor) driver).executeScript(step.getTestData(), element);
                break;
            case "WAIT":
                Thread.sleep(Long.parseLong(step.getTestData()));
                break;
            default:
                log(logPrefix + "WARNING: Unknown action '" + action + "'");
                return;
        }
        log(logPrefix + "SUCCESS: " + action);
    }

    private void handleDropdown(WebElement element, String testData) {
        Select select = new Select(element);
        String[] parts = testData.split(":", 2);
        String strategy = parts[0].trim().toLowerCase();
        String value = parts.length > 1 ? parts[1] : "";
        switch (strategy) {
            case "text":
                select.selectByVisibleText(value);
                break;
            case "value":
                select.selectByValue(value);
                break;
            case "index":
                select.selectByIndex(Integer.parseInt(value));
                break;
            default:
                log("  WARNING: Unknown dropdown strategy. Trying visible text.");
                select.selectByVisibleText(testData);
        }
    }

    private void handleAlert(String testData) {
        String action = testData.trim().toLowerCase();
        switch (action) {
            case "accept":
                driver.switchTo().alert().accept();
                break;
            case "dismiss":
                driver.switchTo().alert().dismiss();
                break;
            default:
                driver.switchTo().alert().sendKeys(testData);
                driver.switchTo().alert().accept();
        }
    }

    private void handleSwitchWindow() {
        Set<String> allWindowHandles = driver.getWindowHandles();
        for (String handle : allWindowHandles) {
            if (!handle.equals(originalWindowHandle)) {
                driver.switchTo().window(handle);
                break;
            }
        }
    }

    private boolean isBrowserAction(String action) {
        return action.contains("NAVIGATE") || action.contains("SWITCH") || action.contains("ALERT");
    }

    private boolean isWaitAction(String action) {
        return action.equalsIgnoreCase("WAIT");
    }

    private By getByFromLocator(String locatorString) throws Exception {
        if (locatorString == null || locatorString.trim().isEmpty()) {
            throw new Exception("Locator string cannot be null or empty.");
        }
        locatorString = locatorString.trim();

        // Smart-detection for XPath if no strategy prefix (like 'XPATH:') is found.
        if (!locatorString.contains(":")) {
            if (locatorString.startsWith("/") || locatorString.startsWith("./") || locatorString.startsWith("(")) {
                log("INFO: No locator strategy prefix found. Assuming 'XPATH' for: " + locatorString);
                return By.xpath(locatorString);
            }
            // If no colon and not an obvious XPath, the format is invalid.
            throw new Exception("Invalid locator format. Expected 'strategy:value' (e.g., 'ID:myId' or '//a'), but got: " + locatorString);
        }

        // Standard logic for locators with a strategy prefix (e.g., "ID:value").
        String[] parts = locatorString.split(":", 2);
        String strategy = parts[0].trim().toUpperCase();
        String value = parts[1].trim();

        if (value.isEmpty()) {
            throw new Exception("Locator value cannot be empty for strategy: " + strategy);
        }

        switch (strategy) {
            case "ID":
                return By.id(value);
            case "NAME":
                return By.name(value);
            case "TAG":
                return By.tagName(value);
            case "ABS XPATH": // Added support for this prefix from your UI
            case "REL XPATH":
            case "XPATH":
                return By.xpath(value);
            case "CSS":
                return By.cssSelector(value);
            case "CLASS":
                return By.className(value);
            case "LINKTEXT":
                return By.linkText(value);
            case "PARTIALLINKTEXT":
                return By.partialLinkText(value);
            default:
                throw new Exception("Unsupported locator strategy: " + strategy);
        }
    }

    private void log(String message) {
        logger.accept(message + "\n");
    }
}