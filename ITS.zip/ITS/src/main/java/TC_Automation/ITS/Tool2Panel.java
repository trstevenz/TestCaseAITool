package TC_Automation.ITS;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.prefs.Preferences;
import java.util.function.Consumer;

public class Tool2Panel extends JPanel {
    //<editor-fold desc="UI Components and Constants Declaration">
    private static final Color BUTTON_COLOR = new Color(52, 152, 219);
    private static final Color SUCCESS_COLOR = new Color(39, 174, 96);
    private static final Color DANGER_COLOR = new Color(231, 76, 60);
    private static final Color AI_COLOR = new Color(147, 112, 219);
    private static final Color DUPLICATE_COLOR = new Color(243, 156, 18);
    private static final Color EXCEL_COLOR = new Color(33, 115, 70);
    private static final Color RUN_COLOR = new Color(0, 100, 0);
    private static final Color COLLECTION_HEADER_COLOR = new Color(200, 230, 255);
    private final Preferences prefs = Preferences.userNodeForPackage(Tool2Panel.class);
    private static final String DATE_FORMAT_KEY = "date_format";
    private final TestDataTableModel tableModel;
    private final JTable testDataTable;
    private final JLabel projectNameLabel;
    private final JComboBox<String> projectLoaderComboBox;
    private final JComboBox<String> testDataLoaderComboBox;
    private final JComboBox<String> tabSelectorComboBox;
    private final JTextArea logTextArea;
    private final JButton runTestButton;
    private final JComboBox<SeleniumExecutor.Browser> browserComboBox;
    private final JTextField urlTextField;
    private final JCheckBox keepBrowserOpenCheckBox;
    private String projectName;
    private String currentFileName;
    private boolean isNewFile = true;
    private int generatedTabCounter = 1;
    private final Map<String, List<TableRow>> tabDataMap = new HashMap<>();
    private String currentTab = "Primary";
    private boolean hasUnsavedChanges = false;
    //</editor-fold>
    public Tool2Panel() {
        super(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        this.tableModel = new TestDataTableModel();
        this.testDataTable = new JTable(tableModel);
        this.projectNameLabel = new JLabel("No Project Loaded", SwingConstants.CENTER);
        this.projectNameLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        this.projectNameLabel.setForeground(new Color(41, 128, 185));
        this.projectLoaderComboBox = new JComboBox<>();
        this.testDataLoaderComboBox = new JComboBox<>();
        this.tabSelectorComboBox = new JComboBox<>();
        this.logTextArea = new JTextArea();
        this.urlTextField = new JTextField(30);
        this.browserComboBox = new JComboBox<>(SeleniumExecutor.Browser.values());
        this.runTestButton = createModernButton("▶ Run Test", RUN_COLOR);
        this.keepBrowserOpenCheckBox = new JCheckBox("Keep browser open");
        add(createTopPanel(), BorderLayout.NORTH);
        JScrollPane tableScrollPane = new JScrollPane(testDataTable);
        JScrollPane logScrollPane = new JScrollPane(logTextArea);
        logScrollPane.setBorder(BorderFactory.createTitledBorder("Execution Log"));
        logTextArea.setEditable(false);
        logTextArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tableScrollPane, logScrollPane);
        splitPane.setResizeWeight(0.7);
        add(splitPane, BorderLayout.CENTER);
        add(createExecutionPanel(), BorderLayout.SOUTH);
        configureTable();
        populateProjectComboBox();
        populateTestDataComboBox();
        attachListeners();
        initializeTabSystem();
    }
    private void attachListeners() {
        testDataTable.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && testDataTable.isEditing()) {
                    testDataTable.getCellEditor().stopCellEditing();
                }
            }
        });
        tabSelectorComboBox.addActionListener(e -> {
            if (tabSelectorComboBox.getSelectedItem() != null) {
                switchTab();
            }
        });
        runTestButton.addActionListener(e -> runTest());
    }
    private void initializeTabSystem() {
        tabDataMap.clear();
        tabSelectorComboBox.removeAllItems();
        tabDataMap.put("Primary", new ArrayList<>());
        tabSelectorComboBox.addItem("Primary");
        currentTab = "Primary";
        tabSelectorComboBox.setSelectedItem(currentTab);
        tableModel.setTabData(tabDataMap.get(currentTab));
        this.hasUnsavedChanges = false;
    }
    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.add(projectNameLabel);
        JPanel loadersPanel = new JPanel();
        loadersPanel.setLayout(new BoxLayout(loadersPanel, BoxLayout.Y_AXIS));
        loadersPanel.setBorder(BorderFactory.createTitledBorder("Project Management & Tools"));
        JPanel projectLoaderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        projectLoaderPanel.add(new JLabel("1. Load Project Structure:"));
        projectLoaderPanel.add(projectLoaderComboBox);
        JButton loadProjectButton = createModernButton("Load Project", BUTTON_COLOR);
        loadProjectButton.addActionListener(e -> loadProjectFile());
        projectLoaderPanel.add(loadProjectButton);
        loadersPanel.add(projectLoaderPanel);
        JPanel tabManagementPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        tabManagementPanel.add(new JLabel("Active Tab:"));
        tabSelectorComboBox.setEnabled(true);
        tabSelectorComboBox.setPreferredSize(new Dimension(200, 25));
        tabManagementPanel.add(tabSelectorComboBox);
        JButton addTabButton = createModernButton("+ Add Tab", SUCCESS_COLOR);
        addTabButton.addActionListener(e -> addNewTab());
        tabManagementPanel.add(addTabButton);
        JButton duplicateTabButton = createModernButton("Duplicate Tab", DUPLICATE_COLOR);
        duplicateTabButton.addActionListener(e -> duplicateCurrentTab());
        tabManagementPanel.add(duplicateTabButton);
        JButton renameTabButton = createModernButton("Rename Tab", new Color(155, 89, 182));
        renameTabButton.addActionListener(e -> renameCurrentTab());
        tabManagementPanel.add(renameTabButton);
        JButton deleteTabButton = createModernButton("- Delete Tab", DANGER_COLOR);
        deleteTabButton.addActionListener(e -> deleteCurrentTab());
        tabManagementPanel.add(deleteTabButton);
        loadersPanel.add(tabManagementPanel);
        JPanel dataLoaderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        dataLoaderPanel.add(new JLabel("2. Load/Save Test Data:"));
        dataLoaderPanel.add(testDataLoaderComboBox);
        JButton loadDataButton = createModernButton("Load Data", BUTTON_COLOR);
        loadDataButton.addActionListener(e -> loadTestDataFromFile());
        dataLoaderPanel.add(loadDataButton);
        JButton deleteDataButton = createModernButton("Delete Data", DANGER_COLOR);
        deleteDataButton.addActionListener(e -> deleteSelectedTestData());
        dataLoaderPanel.add(deleteDataButton);
        JButton importExcelButton = createModernButton("Import Excel", EXCEL_COLOR);
        importExcelButton.addActionListener(e -> importFromExcel());
        dataLoaderPanel.add(importExcelButton);
        JButton exportExcelButton = createModernButton("Export Excel", EXCEL_COLOR);
        exportExcelButton.addActionListener(e -> exportToExcel());
        dataLoaderPanel.add(exportExcelButton);
        loadersPanel.add(dataLoaderPanel);
        JPanel toolsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton generateTabsButton = createModernButton("Generate Tabs (AI)", AI_COLOR);
        generateTabsButton.addActionListener(e -> showAIGenerationDialog());
        toolsPanel.add(generateTabsButton);
        JButton apiKeyButton = createModernButton("Set API Key", AI_COLOR);
        apiKeyButton.addActionListener(e -> showApiKeyDialog());
        toolsPanel.add(apiKeyButton);
        JButton settingsButton = createModernButton("⚙️ Settings", new Color(127, 140, 141));
        settingsButton.addActionListener(e -> showSettingsDialog());
        toolsPanel.add(settingsButton);
        loadersPanel.add(toolsPanel);
        topPanel.add(loadersPanel);
        return topPanel;
    }
    private JPanel createExecutionPanel() {
        JPanel executionPanel = new JPanel(new BorderLayout(10, 5));
        executionPanel.setBorder(BorderFactory.createTitledBorder("Test Execution Controls"));
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        controls.add(new JLabel("Start URL:"));
        controls.add(urlTextField);
        controls.add(new JLabel("Browser:"));
        controls.add(browserComboBox);
        controls.add(runTestButton);
        controls.add(keepBrowserOpenCheckBox);
        executionPanel.add(controls, BorderLayout.CENTER);
        JPanel savePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = createModernButton("Save Test Data", SUCCESS_COLOR);
        saveButton.addActionListener(e -> showSaveOptionsDialog());
        savePanel.add(saveButton);
        executionPanel.add(savePanel, BorderLayout.EAST);
        return executionPanel;
    }
    private void runTest() {
        String url = urlTextField.getText();
        if (url.trim().isEmpty() || !url.startsWith("http")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid Start URL (e.g., https://...)", "Invalid URL", JOptionPane.ERROR_MESSAGE);
            return;
        }
        tabDataMap.put(currentTab, tableModel.getCurrentTabData());
        TestDataPackage testDataPackage = getActiveTestData();
        if (testDataPackage == null || testDataPackage.getTestSteps().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No test steps to run.", "Empty Test Case", JOptionPane.WARNING_MESSAGE);
            return;
        }
        logTextArea.setText("");
        runTestButton.setEnabled(false);
        runTestButton.setText("Running...");
        SeleniumExecutor.Browser selectedBrowser = (SeleniumExecutor.Browser) browserComboBox.getSelectedItem();
        boolean keepBrowserOpen = keepBrowserOpenCheckBox.isSelected();
        SwingWorker<Void, String> worker = new SwingWorker<Void, String>() {
            @Override
            protected Void doInBackground() throws Exception {
                Consumer<String> logger = this::publish;
                SeleniumExecutor executor = new SeleniumExecutor(logger);
                executor.executeTest(testDataPackage, selectedBrowser, keepBrowserOpen);
                return null;
            }
            @Override
            protected void process(List<String> chunks) {
                for (String message : chunks) {
                    logTextArea.append(message);
                }
            }
            @Override
            protected void done() {
                runTestButton.setEnabled(true);
                runTestButton.setText("▶ Run Test");
            }
        };
        worker.execute();
    }
    //<editor-fold desc="Core App Logic">
    private void renameCurrentTab() {
        if (currentFileName == null || isNewFile) {
            JOptionPane.showMessageDialog(this, "Please load or save a test data file before renaming a tab.", "File Not Loaded", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if ("Primary".equals(currentTab)) {
            JOptionPane.showMessageDialog(this, "Cannot rename the Primary tab.", "Protected Tab", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String newName = JOptionPane.showInputDialog(this, "Enter new name for tab:", currentTab);
        if (newName == null || newName.trim().isEmpty()) {
            return;
        }
        newName = newName.trim();
        if (tabDataMap.containsKey(newName)) {
            JOptionPane.showMessageDialog(this, "Tab name already exists.", "Duplicate Name", JOptionPane.ERROR_MESSAGE);
        } else {
            List<TableRow> tabData = tabDataMap.remove(currentTab);
            tabDataMap.put(newName, tabData);
            ActionListener switchListener = tabSelectorComboBox.getActionListeners()[0];
            tabSelectorComboBox.removeActionListener(switchListener);
            int index = tabSelectorComboBox.getSelectedIndex();
            tabSelectorComboBox.removeItemAt(index);
            tabSelectorComboBox.insertItemAt(newName, index);
            tabSelectorComboBox.setSelectedItem(newName);
            tabSelectorComboBox.addActionListener(switchListener);
            currentTab = newName;
            persistChangesToFile();
            this.hasUnsavedChanges = true;
            JOptionPane.showMessageDialog(this, "Tab renamed to '" + newName + "' and saved.", "Rename Successful", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    private void deleteCurrentTab() {
        if (currentFileName == null || isNewFile) {
            JOptionPane.showMessageDialog(this, "Please load or save a test data file before deleting a tab.", "File Not Loaded", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if ("Primary".equals(currentTab)) {
            JOptionPane.showMessageDialog(this, "Cannot delete the Primary tab.", "Protected Tab", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete tab '" + currentTab + "' and all its data?", "Confirm Tab Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            String deletedTabName = currentTab;
            tabDataMap.remove(currentTab);
            ActionListener switchListener = tabSelectorComboBox.getActionListeners()[0];
            tabSelectorComboBox.removeActionListener(switchListener);
            tabSelectorComboBox.removeItem(deletedTabName);
            currentTab = "Primary";
            tabSelectorComboBox.setSelectedItem(currentTab);
            tableModel.setTabData(tabDataMap.get(currentTab));
            tabSelectorComboBox.addActionListener(switchListener);
            persistChangesToFile();
            this.hasUnsavedChanges = true;
            JOptionPane.showMessageDialog(this, "Tab '" + deletedTabName + "' has been deleted and saved.", "Delete Successful", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    private void switchTab() {
        String selectedTab = (String) tabSelectorComboBox.getSelectedItem();
        if (selectedTab != null && !selectedTab.equals(currentTab)) {
            tabDataMap.put(currentTab, tableModel.getCurrentTabData());
            currentTab = selectedTab;
            if (!tabDataMap.containsKey(currentTab)) {
                tabDataMap.put(currentTab, new ArrayList<>());
            }
            tableModel.setTabData(tabDataMap.get(currentTab));
        }
    }
    private void addNewTab() {
        String tabName = JOptionPane.showInputDialog(this, "Enter name for the new tab:");
        if (tabName == null || tabName.trim().isEmpty()) {
            return;
        }
        tabName = tabName.trim();
        if (tabDataMap.containsKey(tabName)) {
            JOptionPane.showMessageDialog(this, "Tab name already exists!", "Duplicate Tab", JOptionPane.WARNING_MESSAGE);
        } else {
            List<TableRow> newData = new ArrayList<>();
            List<TableRow> primaryData = tabDataMap.get("Primary");
            if (primaryData != null) {
                for (TableRow row : primaryData) {
                    if (row instanceof CollectionHeaderRow) {
                        newData.add(new CollectionHeaderRow(((CollectionHeaderRow) row).getCollectionName()));
                    } else if (row instanceof ElementDataRow) {
                        ElementDataRow src = (ElementDataRow) row;
                        newData.add(new ElementDataRow(src.getElementName(), src.getAvailableLocators(), src.getSelectedLocator()));
                    }
                }
            }
            tabDataMap.put(tabName, newData);
            tabSelectorComboBox.addItem(tabName);
            tabSelectorComboBox.setSelectedItem(tabName);
            this.hasUnsavedChanges = true;
        }
    }
    private void duplicateCurrentTab() {
        String sourceTabName = currentTab;
        List<TableRow> sourceData = tabDataMap.get(sourceTabName);
        if (sourceData == null) {
            JOptionPane.showMessageDialog(this, "Cannot find data for the current tab to duplicate.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String newTabName = sourceTabName + "_Copy";
        int counter = 2;
        while (tabDataMap.containsKey(newTabName)) {
            newTabName = sourceTabName + "_Copy_" + counter++;
        }
        List<TableRow> duplicatedData = new ArrayList<>();
        for (TableRow row : sourceData) {
            duplicatedData.add(cloneRow(row));
        }
        tabDataMap.put(newTabName, duplicatedData);
        tabSelectorComboBox.addItem(newTabName);
        tabSelectorComboBox.setSelectedItem(newTabName);
        this.hasUnsavedChanges = true;
        JOptionPane.showMessageDialog(this, "Tab '" + sourceTabName + "' duplicated to '" + newTabName + "'.", "Tab Duplicated", JOptionPane.INFORMATION_MESSAGE);
    }
    private void configureTable() {
        testDataTable.setRowHeight(28);
        testDataTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        testDataTable.setFillsViewportHeight(true);
        testDataTable.getColumnModel().getColumn(0).setCellRenderer(new HeaderRenderer());
        testDataTable.getColumnModel().getColumn(0).setCellEditor(new HeaderEditor());
        testDataTable.getColumnModel().getColumn(1).setCellEditor(new LocatorCellEditor());
        testDataTable.getColumnModel().getColumn(2).setCellRenderer(new ActionCellRenderer());
        testDataTable.getColumnModel().getColumn(2).setCellEditor(new ActionCellEditor());
        testDataTable.getColumnModel().getColumn(3).setCellRenderer(new TestDataCellRenderer());
        testDataTable.getColumnModel().getColumn(3).setCellEditor(new TestDataCellEditor());
        for (int i = 1; i < testDataTable.getColumnCount(); i++) {
            if (i != 2 && i != 3) {
                testDataTable.getColumnModel().getColumn(i).setCellRenderer(new CollectionRenderer());
            }
        }
    }
    private void showSaveOptionsDialog() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        JLabel label = new JLabel("How would you like to save?");
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(label);
        panel.add(Box.createVerticalStrut(15));
        Dimension buttonSize = new Dimension(220, 32);
        JDialog dialog = new JDialog();
        JButton saveCurrentButton = createModernButton("Save Current File", BUTTON_COLOR);
        saveCurrentButton.setPreferredSize(buttonSize);
        saveCurrentButton.setMaximumSize(buttonSize);
        saveCurrentButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        saveCurrentButton.addActionListener(e -> {
            saveTestData(false);
            dialog.dispose();
        });
        saveCurrentButton.setEnabled(!isNewFile);
        panel.add(saveCurrentButton);
        panel.add(Box.createVerticalStrut(10));
        JButton saveNewFileButton = createModernButton("Save as New File...", AI_COLOR);
        saveNewFileButton.setPreferredSize(buttonSize);
        saveNewFileButton.setMaximumSize(buttonSize);
        saveNewFileButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        saveNewFileButton.addActionListener(e -> {
            saveTestData(true);
            dialog.dispose();
        });
        panel.add(saveNewFileButton);
        panel.add(Box.createVerticalStrut(15));
        JButton cancelButton = createModernButton("Cancel", DANGER_COLOR);
        cancelButton.setPreferredSize(buttonSize);
        cancelButton.setMaximumSize(buttonSize);
        cancelButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        cancelButton.addActionListener(e -> dialog.dispose());
        panel.add(cancelButton);
        dialog.add(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
    //</editor-fold>
    //<editor-fold desc="File I/O (JSON, Excel)">
    public void populateProjectComboBox() {
        projectLoaderComboBox.removeAllItems();
        File execDir = new File("executionList");
        if (execDir.exists() && execDir.isDirectory()) {
            File[] files = execDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".json"));
            if (files != null) {
                for (File file : files) {
                    projectLoaderComboBox.addItem(file.getName().replace(".json", ""));
                }
            }
        }
    }
    /**
     * Presents the user with options to Sync, Append, or Replace data when loading a project structure.
     */
    private void loadProjectFile() {
        String selectedProjectName = (String) projectLoaderComboBox.getSelectedItem();
        if (selectedProjectName == null) {
            JOptionPane.showMessageDialog(this, "No project selected.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String[] options = {"Sync with Current Data (Recommended)", "Append to Current Data", "Replace All Existing Data", "Cancel"};
        int choice = JOptionPane.showOptionDialog(
            this,
            "How do you want to load the project structure?\n\n" +
            "• Sync: Merges changes and preserves your test data.\n" +
            "• Append: Adds new collections to the end of your current list.\n" +
            "• Replace: Overwrites everything in the current tab.",
            "Load Project Structure Option",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]
        );
        File projectFile = new File("executionList", selectedProjectName + ".json");
        switch (choice) {
            case 0: // Sync
                loadAndSyncProjectData(projectFile);
                break;
            case 1: // Append
                loadAndAppendProjectData(projectFile);
                break;
            case 2: // Replace
                loadAndReplaceProjectData(projectFile);
                break;
            default: // Cancel or close dialog
                break;
        }
    }
    /**
     * Intelligently merges a project file with the existing data, preserving entered test data and actions.
     * @param projectFile The project structure file to sync with.
     */
    private void loadAndSyncProjectData(File projectFile) {
        try {
            // **THE FIX**: Ensure the main data map is updated with any pending edits from the table model.
            tabDataMap.put(currentTab, tableModel.getCurrentTabData());
            // 1. Get current data and create a lookup map for fast access by "collectionName::elementName".
            List<TableRow> oldRows = tabDataMap.getOrDefault("Primary", new ArrayList<>());
            Map<String, ElementDataRow> oldDataMap = new HashMap<>();
            String currentCollectionKey = "";
            for (TableRow row : oldRows) {
                if (row instanceof CollectionHeaderRow) {
                    currentCollectionKey = ((CollectionHeaderRow) row).getCollectionName();
                } else if (row instanceof ElementDataRow) {
                    ElementDataRow element = (ElementDataRow) row;
                    String key = currentCollectionKey + "::" + element.getElementName();
                    oldDataMap.put(key, element);
                }
            }
            // 2. Prepare to build the new, synced list of rows.
            List<TableRow> syncedRows = new ArrayList<>();
            String content = new String(Files.readAllBytes(projectFile.toPath()));
            JSONObject projectJson = new JSONObject(content);
            // 3. Iterate through the NEW structure from the file.
            Object collectionsObject = projectJson.get("collections");
            List<JSONObject> collections = new ArrayList<>();
            if (collectionsObject instanceof JSONArray) {
                JSONArray collectionsArray = (JSONArray) collectionsObject;
                for (int i = 0; i < collectionsArray.length(); i++) collections.add(collectionsArray.getJSONObject(i));
            } else {
                JSONObject collectionsJson = (JSONObject) collectionsObject;
                for (String key : collectionsJson.keySet()) {
                    collections.add(new JSONObject().put("collectionName", key).put("elements", collectionsJson.getJSONArray(key)));
                }
            }
            // 4. Match new elements against the old data map.
            for (JSONObject collectionObj : collections) {
                String collectionName = collectionObj.getString("collectionName");
                syncedRows.add(new CollectionHeaderRow(collectionName));
                JSONArray elementsArray = collectionObj.getJSONArray("elements");
                for (int i = 0; i < elementsArray.length(); i++) {
                    ElementDataRow newElementFromFile = parseElementData(elementsArray.getJSONArray(i));
                    String key = collectionName + "::" + newElementFromFile.getElementName();
                    if (oldDataMap.containsKey(key)) {
                        // MATCH FOUND: Use the old element which has user data, but update its locators.
                        ElementDataRow oldElementWithData = oldDataMap.get(key);
                        oldElementWithData.getAvailableLocators().clear();
                        oldElementWithData.getAvailableLocators().addAll(newElementFromFile.getAvailableLocators());
                        oldElementWithData.setSelectedLocator(newElementFromFile.getSelectedLocator());
                        syncedRows.add(oldElementWithData);
                    } else {
                        // NO MATCH: This is a new element. Add it as is from the file.
                        syncedRows.add(newElementFromFile);
                    }
                }
            }
            // 5. Update the UI with the newly created list.
            tabDataMap.put("Primary", syncedRows);
            tableModel.setTabData(syncedRows);
            this.hasUnsavedChanges = true;
            JOptionPane.showMessageDialog(this, "Data synced with project file successfully.", "Sync Complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException | org.json.JSONException e) {
            JOptionPane.showMessageDialog(this, "Error syncing project file: " + e.getMessage(), "File Sync Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * Appends collections and elements from a project file to the end of the current data in the Primary tab.
     * @param projectFile The project file to load and append.
     */
    private void loadAndAppendProjectData(File projectFile) {
        try {
            String content = new String(Files.readAllBytes(projectFile.toPath()));
            JSONObject projectJson = new JSONObject(content);
            List<TableRow> existingRows = tabDataMap.getOrDefault("Primary", new ArrayList<>());
            Object collectionsObject = projectJson.get("collections");
            if (collectionsObject instanceof JSONArray) {
                JSONArray collectionsArray = (JSONArray) collectionsObject;
                for (int i = 0; i < collectionsArray.length(); i++) {
                    JSONObject collectionObj = collectionsArray.getJSONObject(i);
                    existingRows.add(new CollectionHeaderRow(collectionObj.getString("collectionName")));
                    processAndAddElements(collectionObj.getJSONArray("elements"), existingRows);
                }
            } else { // Handle old format
                JSONObject collectionsJson = (JSONObject) collectionsObject;
                for (String collectionName : collectionsJson.keySet()) {
                    existingRows.add(new CollectionHeaderRow(collectionName));
                    processAndAddElements(collectionsJson.getJSONArray(collectionName), existingRows);
                }
            }
            tableModel.setTabData(existingRows);
            this.hasUnsavedChanges = true;
            JOptionPane.showMessageDialog(this, "New structure appended successfully.", "Append Complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException | org.json.JSONException e) {
            JOptionPane.showMessageDialog(this, "Error appending project file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * Replaces all existing data with the collections and elements from a new project file.
     * @param projectFile The project file to load.
     */
    private void loadAndReplaceProjectData(File projectFile) {
        try {
            String content = new String(Files.readAllBytes(projectFile.toPath()));
            JSONObject projectJson = new JSONObject(content);
            this.projectName = projectJson.getString("projectName");
            projectNameLabel.setText("Project: " + this.projectName);
            initializeTabSystem(); // This clears everything
            List<TableRow> tableRows = new ArrayList<>();
            Object collectionsObject = projectJson.get("collections");
            if (collectionsObject instanceof JSONArray) {
                JSONArray collectionsArray = (JSONArray) collectionsObject;
                for (int i = 0; i < collectionsArray.length(); i++) {
                    JSONObject collectionObj = collectionsArray.getJSONObject(i);
                    tableRows.add(new CollectionHeaderRow(collectionObj.getString("collectionName")));
                    processAndAddElements(collectionObj.getJSONArray("elements"), tableRows);
                }
            } else { // Handle old format
                JSONObject collectionsJson = (JSONObject) collectionsObject;
                for (String collectionName : collectionsJson.keySet()) {
                    tableRows.add(new CollectionHeaderRow(collectionName));
                    processAndAddElements(collectionsJson.getJSONArray(collectionName), tableRows);
                }
            }
            tabDataMap.put("Primary", tableRows);
            tableModel.setTabData(tableRows);
            isNewFile = true;
            currentFileName = null;
            this.hasUnsavedChanges = false;
        } catch (IOException | org.json.JSONException e) {
            JOptionPane.showMessageDialog(this, "Error replacing project file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    /**
     * Helper method to process a JSONArray of elements, preserving their original order,
     * and add them to the master list of table rows.
     * @param elementsArray The JSONArray containing element data in the desired order.
     * @param tableRows The master list to which ElementDataRow objects will be added.
     */
    private void processAndAddElements(JSONArray elementsArray, List<TableRow> tableRows) {
        for (int i = 0; i < elementsArray.length(); i++) {
            tableRows.add(parseElementData(elementsArray.getJSONArray(i)));
        }
    }
    /**
     * Parses a single element's JSON data and returns a fully formed ElementDataRow.
     * @param elementDataJson The JSONArray for a single element.
     * @return An ElementDataRow object.
     */
    private ElementDataRow parseElementData(JSONArray elementDataJson) {
        String elementName = elementDataJson.optString(0);
        List<String> locators = new ArrayList<>();
        if (!elementDataJson.optString(3).isEmpty()) locators.add("ID: " + elementDataJson.optString(3));
        if (!elementDataJson.optString(4).isEmpty()) locators.add("Tag: " + elementDataJson.optString(4));
        if (!elementDataJson.optString(1).isEmpty()) locators.add("Abs XPath: " + elementDataJson.optString(1));
        if (!elementDataJson.optString(2).isEmpty()) locators.add("Rel XPath: " + elementDataJson.optString(2));
        if (!elementDataJson.optString(5).isEmpty()) locators.add("Attributes: " + elementDataJson.optString(5));
        String defaultLocator = locators.isEmpty() ? "N/A" : locators.get(0);
        return new ElementDataRow(elementName, locators, defaultLocator);
    }
    public boolean saveTestData(boolean saveAsNewFile) {
        if (projectName == null || projectName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No project is loaded.", "Save Error", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        tabDataMap.put(currentTab, tableModel.getCurrentTabData());
        String fileNameToSave = currentFileName;
        if (saveAsNewFile || isNewFile) {
            String newName = JOptionPane.showInputDialog(this, "Enter name for the test data file:", projectName + "_TestData");
            if (newName == null || newName.trim().isEmpty()) {
                return false;
            }
            fileNameToSave = newName.trim();
        }
        if (!fileNameToSave.toLowerCase().endsWith(".json")) {
            fileNameToSave += ".json";
        }
        File file = new File("TestData", fileNameToSave);
        JSONObject outputJson = buildJsonContentFromMap(tabDataMap, fileNameToSave.replace(".json", ""));
        try (FileWriter writer = new FileWriter(file)) {
            writer.write(outputJson.toString(4));
            JOptionPane.showMessageDialog(this, "Test data saved to " + fileNameToSave, "Save Complete", JOptionPane.INFORMATION_MESSAGE);
            if (saveAsNewFile || isNewFile) {
                populateTestDataComboBox();
                testDataLoaderComboBox.setSelectedItem(fileNameToSave.replace(".json", ""));
            }
            currentFileName = fileNameToSave.replace(".json", "");
            isNewFile = false;
            this.hasUnsavedChanges = false;
            return true;
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving test data: " + e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    private void persistChangesToFile() {
        if (currentFileName == null || isNewFile) {
            return;
        }
        String fileNameToSave = currentFileName;
        if (!fileNameToSave.toLowerCase().endsWith(".json")) {
            fileNameToSave += ".json";
        }
        File file = new File("TestData", fileNameToSave);
        JSONObject outputJson = buildJsonContentFromMap(tabDataMap, currentFileName);
        try (FileWriter writer = new FileWriter(file)) {
            writer.write(outputJson.toString(4));
        } catch (IOException e) {
            System.err.println("Silent auto-save failed: " + e.getMessage());
        }
    }
    private JSONObject buildJsonContentFromMap(Map<String, List<TableRow>> dataMap, String fileName) {
        JSONObject outputJson = new JSONObject();
        outputJson.put("projectName", this.projectName);
        outputJson.put("fileName", fileName);
        if (testDataTable.isEditing()) {
            testDataTable.getCellEditor().stopCellEditing();
        }
        JSONArray testDataArray = new JSONArray();
        for (int i = 0; i < tabSelectorComboBox.getItemCount(); i++) {
            String tabName = tabSelectorComboBox.getItemAt(i);
            List<TableRow> rows = dataMap.get(tabName);
            if (rows != null) {
                JSONObject tabObject = new JSONObject();
                tabObject.put("tabName", tabName);
                JSONArray tabRows = new JSONArray();
                for (TableRow row : rows) {
                    JSONObject rowObj = new JSONObject();
                    if (row instanceof CollectionHeaderRow) {
                        CollectionHeaderRow header = (CollectionHeaderRow) row;
                        rowObj.put("type", "header");
                        rowObj.put("name", header.getCollectionName());
                        rowObj.put("isFixed", header.isFixed());
                    } else if (row instanceof ElementDataRow) {
                        ElementDataRow element = (ElementDataRow) row;
                        rowObj.put("type", "element");
                        rowObj.put("elementName", element.getElementName());
                        rowObj.put("locator", element.getSelectedLocator());
                        rowObj.put("beforeAction", element.getBeforeAction());
                        rowObj.put("mainAction", element.getMainAction());
                        rowObj.put("afterAction", element.getAfterAction());
                        rowObj.put("testDataType", element.getTestDataType().name());
                        rowObj.put("testDataValue", element.getTestDataValue());
                        rowObj.put("availableLocators", new JSONArray(element.getAvailableLocators()));
                    }
                    tabRows.put(rowObj);
                }
                tabObject.put("rows", tabRows);
                testDataArray.put(tabObject);
            }
        }
        outputJson.put("testData", testDataArray);
        return outputJson;
    }
    private void populateTestDataComboBox() {
        String selected = (String) testDataLoaderComboBox.getSelectedItem();
        testDataLoaderComboBox.removeAllItems();
        File testDataDir = new File("TestData");
        if (testDataDir.exists() && testDataDir.isDirectory()) {
            File[] files = testDataDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".json"));
            if (files != null) {
                for (File file : files) {
                    testDataLoaderComboBox.addItem(file.getName().replace(".json", ""));
                }
            }
        }
        testDataLoaderComboBox.setSelectedItem(selected);
    }
    private void loadTestDataFromFile() {
        if (this.projectName == null) {
            JOptionPane.showMessageDialog(this, "Please load a Project Structure first.", "Project Not Loaded", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String selectedFile = (String) testDataLoaderComboBox.getSelectedItem();
        if (selectedFile == null) {
            JOptionPane.showMessageDialog(this, "No test data file selected.", "Load Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        File file = new File("TestData", selectedFile + ".json");
        try {
            String content = new String(Files.readAllBytes(file.toPath()));
            JSONObject testDataJson = new JSONObject(content);
            if (!this.projectName.equals(testDataJson.optString("projectName"))) {
                JOptionPane.showMessageDialog(this, "This data belongs to a different project.", "Project Mismatch", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Map<String, List<TableRow>> newTabDataMap = new HashMap<>();
            List<String> tabNamesInOrder = new ArrayList<>();
            Object testDataObject = testDataJson.get("testData");
            if (testDataObject instanceof JSONArray) {
                JSONArray testDataArray = (JSONArray) testDataObject;
                for (int i = 0; i < testDataArray.length(); i++) {
                    JSONObject tabObject = testDataArray.getJSONObject(i);
                    String tabName = tabObject.getString("tabName");
                    JSONArray tabRowsJson = tabObject.getJSONArray("rows");
                    tabNamesInOrder.add(tabName);
                    newTabDataMap.put(tabName, parseTabRows(tabRowsJson));
                }
            } else if (testDataObject instanceof JSONObject) {
                JSONObject testDataByTab = (JSONObject) testDataObject;
                for (String tabName : testDataByTab.keySet()) {
                    tabNamesInOrder.add(tabName);
                    JSONArray tabRowsJson = testDataByTab.getJSONArray(tabName);
                    newTabDataMap.put(tabName, parseTabRows(tabRowsJson));
                }
            }
            loadDataMapIntoUI(newTabDataMap, tabNamesInOrder);
            currentFileName = selectedFile;
            isNewFile = false;
            this.hasUnsavedChanges = false;
            JOptionPane.showMessageDialog(this, "Test data loaded successfully!", "Load Complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException | org.json.JSONException e) {
            JOptionPane.showMessageDialog(this, "Error loading test data file: " + e.getMessage(), "Load Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private List<TableRow> parseTabRows(JSONArray tabRowsJson) {
        List<TableRow> tableRows = new ArrayList<>();
        for (int i = 0; i < tabRowsJson.length(); i++) {
            JSONObject rowObj = tabRowsJson.getJSONObject(i);
            if ("header".equals(rowObj.optString("type"))) {
                CollectionHeaderRow header = new CollectionHeaderRow(rowObj.getString("name"));
                header.setFixed(rowObj.optBoolean("isFixed", false));
                tableRows.add(header);
            } else if ("element".equals(rowObj.optString("type"))) {
                List<String> locators = new ArrayList<>();
                JSONArray locatorsArray = rowObj.optJSONArray("availableLocators");
                if (locatorsArray != null) {
                    for (int j = 0; j < locatorsArray.length(); j++) {
                        locators.add(locatorsArray.getString(j));
                    }
                }
                ElementDataRow element = new ElementDataRow(rowObj.getString("elementName"), locators, rowObj.optString("locator"));
                element.setBeforeAction(rowObj.optString("beforeAction", ""));
                element.setMainAction(rowObj.optString("mainAction", ""));
                element.setAfterAction(rowObj.optString("afterAction", ""));
                element.setTestDataType(ElementDataRow.TestDataType.valueOf(rowObj.optString("testDataType", "STATIC")));
                if (rowObj.has("testDataValue")) {
                    element.setTestDataValue(rowObj.optString("testDataValue", ""));
                } else if (rowObj.has("testData")) {
                    element.setTestDataValue(rowObj.optString("testData", ""));
                    element.setTestDataType(ElementDataRow.TestDataType.STATIC);
                }
                tableRows.add(element);
            }
        }
        return tableRows;
    }
    private void deleteSelectedTestData() {
        String selectedFile = (String) testDataLoaderComboBox.getSelectedItem();
        if (selectedFile == null) {
            JOptionPane.showMessageDialog(this, "No test data file selected to delete.", "Delete Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to permanently delete '" + selectedFile + "'?", "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (choice == JOptionPane.YES_OPTION) {
            File fileToDelete = new File("TestData", selectedFile + ".json");
            if (fileToDelete.exists() && fileToDelete.delete()) {
                JOptionPane.showMessageDialog(this, "File deleted successfully.", "Delete Successful", JOptionPane.INFORMATION_MESSAGE);
                if (selectedFile.equals(currentFileName)) {
                    currentFileName = null;
                    isNewFile = true;
                    initializeTabSystem();
                }
                populateTestDataComboBox();
            } else {
                JOptionPane.showMessageDialog(this, "Could not delete the file.", "Delete Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    private void importFromExcel() {
        if (projectName == null) {
            JOptionPane.showMessageDialog(this, "Please load a Project Structure before importing data.", "Import Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String[] options = {"Overwrite Current Data", "Save as New JSON File", "Cancel"};
        int choice = JOptionPane.showOptionDialog(this, "How would you like to import the Excel file?", "Import Option", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        if (choice == 0) {
            importAndOverwrite();
        } else if (choice == 1) {
            importAndSaveAsNew();
        }
    }
    private void importAndOverwrite() {
        File excelFile = chooseExcelFile();
        if (excelFile == null) return;
        Map<String, List<TableRow>> importedData = parseExcelFile(excelFile);
        if (importedData == null) return;
        loadDataMapIntoUI(importedData, new ArrayList<>(importedData.keySet()));
        this.isNewFile = true;
        this.currentFileName = null;
        this.hasUnsavedChanges = true;
        JOptionPane.showMessageDialog(this, "Data imported and has overwritten current view.\nSave the data to create a new JSON file.", "Import Complete", JOptionPane.INFORMATION_MESSAGE);
    }
    private void importAndSaveAsNew() {
        File excelFile = chooseExcelFile();
        if (excelFile == null) return;
        Map<String, List<TableRow>> importedData = parseExcelFile(excelFile);
        if (importedData == null) return;
        String newName = JOptionPane.showInputDialog(this, "Enter a name for the new Test Data JSON file:");
        if (newName == null || newName.trim().isEmpty()) return;
        String fileNameToSave = newName.trim();
        if (fileNameToSave.toLowerCase().endsWith(".json")) {
            fileNameToSave = fileNameToSave.substring(0, fileNameToSave.length() - 5);
        }
        File file = new File("TestData", fileNameToSave + ".json");
        if (file.exists()) {
            JOptionPane.showMessageDialog(this, "A file with this name already exists.", "Save Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JSONObject outputJson = buildJsonContentFromMap(importedData, fileNameToSave);
        try (FileWriter writer = new FileWriter(file)) {
            writer.write(outputJson.toString(4));
            JOptionPane.showMessageDialog(this, "Excel file converted and saved as " + file.getName(), "Save Complete", JOptionPane.INFORMATION_MESSAGE);
            populateTestDataComboBox();
            testDataLoaderComboBox.setSelectedItem(fileNameToSave);
            loadTestDataFromFile();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving new test data file: " + e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private File chooseExcelFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Excel File");
        fileChooser.setFileFilter(new FileNameExtensionFilter("Excel Files (*.xlsx)", "xlsx"));
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            return fileChooser.getSelectedFile();
        }
        return null;
    }
    private Map<String, List<TableRow>> parseExcelFile(File excelFile) {
        try (Workbook workbook = new XSSFWorkbook(new FileInputStream(excelFile))) {
            Map<String, List<TableRow>> importedData = new HashMap<>();
            for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                Sheet sheet = workbook.getSheetAt(i);
                String tabName = sheet.getSheetName();
                List<TableRow> tableRows = new ArrayList<>();
                for (Row row : sheet) {
                    if (row.getRowNum() == 0) continue;
                    String col1 = getCellStringValue(row.getCell(0));
                    String col2 = getCellStringValue(row.getCell(1));
                    String col3 = getCellStringValue(row.getCell(2));
                    String col4 = getCellStringValue(row.getCell(3));
                    String col5 = getCellStringValue(row.getCell(4));
                    boolean isFixed = row.getCell(5) != null && row.getCell(5).getCellType() == CellType.BOOLEAN && row.getCell(5).getBooleanCellValue();
                    if (col2.isEmpty() && !col1.trim().isEmpty()) {
                        CollectionHeaderRow header = new CollectionHeaderRow(col1.trim());
                        header.setFixed(isFixed);
                        tableRows.add(header);
                    } else if (!col1.trim().isEmpty()) {
                        ElementDataRow element = new ElementDataRow(col1.trim(), Collections.singletonList(col2), col2);
                        element.setMainAction(col3);
                        element.setTestDataValue(col5);
                        ElementDataRow.TestDataType.fromDisplayName(col4)
                            .ifPresent(element::setTestDataType);
                        tableRows.add(element);
                    }
                }
                importedData.put(tabName, tableRows);
            }
            return importedData;
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading Excel file: " + e.getMessage(), "Import Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    private void loadDataMapIntoUI(Map<String, List<TableRow>> dataMap, List<String> tabOrder) {
        this.tabDataMap.clear();
        this.tabDataMap.putAll(dataMap);
        tabSelectorComboBox.removeAllItems();
        for (String tabName : tabOrder) {
            tabSelectorComboBox.addItem(tabName);
        }
        if (tabSelectorComboBox.getItemCount() > 0) {
            tabSelectorComboBox.setSelectedIndex(0);
            currentTab = (String) tabSelectorComboBox.getSelectedItem();
            tableModel.setTabData(this.tabDataMap.get(currentTab));
        } else {
            initializeTabSystem();
        }
    }
    private void exportToExcel() {
        if (tabDataMap.isEmpty() || (tabDataMap.size() == 1 && tabDataMap.get("Primary").isEmpty())) {
            JOptionPane.showMessageDialog(this, "No data to export.", "Export Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export to Excel");
        fileChooser.setFileFilter(new FileNameExtensionFilter("Excel Files (*.xlsx)", "xlsx"));
        fileChooser.setSelectedFile(new File(projectName + "_TestData.xlsx"));
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (Workbook workbook = new XSSFWorkbook(); FileOutputStream fos = new FileOutputStream(fileToSave)) {
                CellStyle headerStyle = workbook.createCellStyle();
                org.apache.poi.ss.usermodel.Font font = workbook.createFont();
                font.setBold(true);
                headerStyle.setFont(font);
                for (Map.Entry<String, List<TableRow>> tabEntry : tabDataMap.entrySet()) {
                    Sheet sheet = workbook.createSheet(tabEntry.getKey());
                    Row headerRow = sheet.createRow(0);
                    String[] columns = {"Collection / Element", "Locator", "Action(s)", "Test Data Type", "Test Data Value", "Is Fixed"};
                    for (int i = 0; i < columns.length; i++) {
                        Cell cell = headerRow.createCell(i);
                        cell.setCellValue(columns[i]);
                        cell.setCellStyle(headerStyle);
                    }
                    int rowNum = 1;
                    for (TableRow tableRow : tabEntry.getValue()) {
                        Row row = sheet.createRow(rowNum++);
                        if (tableRow instanceof CollectionHeaderRow) {
                            CollectionHeaderRow header = (CollectionHeaderRow) tableRow;
                            row.createCell(0).setCellValue(header.getCollectionName());
                            row.createCell(5).setCellValue(header.isFixed());
                        } else if (tableRow instanceof ElementDataRow) {
                            ElementDataRow element = (ElementDataRow) tableRow;
                            row.createCell(0).setCellValue("    " + element.getElementName());
                            row.createCell(1).setCellValue(element.getSelectedLocator());
                            row.createCell(2).setCellValue(formatActionsForDisplay(element));
                            row.createCell(3).setCellValue(element.getTestDataType().toString());
                            row.createCell(4).setCellValue(element.getTestDataValue());
                        }
                    }
                    for (int i = 0; i < columns.length; i++) {
                        sheet.autoSizeColumn(i);
                    }
                }
                workbook.write(fos);
                JOptionPane.showMessageDialog(this, "Data exported successfully to " + fileToSave.getName(), "Export Successful", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error exporting to Excel: " + e.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    //</editor-fold>
    //<editor-fold desc="AI & Tools">
    private void showApiKeyDialog() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.add(new JLabel("Enter Gemini API Key:"), BorderLayout.NORTH);
        JTextField apiKeyField = new JTextField(prefs.get("gemini_api_key", ""), 30);
        panel.add(apiKeyField, BorderLayout.CENTER);
        int result = JOptionPane.showConfirmDialog(this, panel, "API Key Configuration", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            prefs.put("gemini_api_key", apiKeyField.getText());
        }
    }
    private void showSettingsDialog() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        panel.add(new JLabel("Enter Date Format (e.g., yyyy-MM-dd):"), BorderLayout.NORTH);
        JTextField dateFormatField = new JTextField(prefs.get(DATE_FORMAT_KEY, "yyyy-MM-dd"), 20);
        panel.add(dateFormatField, BorderLayout.CENTER);
        int result = JOptionPane.showConfirmDialog(this, panel, "Settings", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            try {
                DateTimeFormatter.ofPattern(dateFormatField.getText());
                prefs.put(DATE_FORMAT_KEY, dateFormatField.getText());
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(this, "Invalid date format.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    private void showAIGenerationDialog() {
        String countStr = JOptionPane.showInputDialog(this, "Number of sheets to generate (1-20):", "5");
        if (countStr != null) {
            try {
                int sheetCount = Integer.parseInt(countStr);
                if (sheetCount > 0 && sheetCount <= 20) {
                    generateAISheets(sheetCount);
                } else {
                    JOptionPane.showMessageDialog(this, "Please enter a number between 1-20.", "Invalid Input", JOptionPane.WARNING_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number.", "Invalid Input", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    private void generateAISheets(int sheetCount) {
        String apiKey = prefs.get("gemini_api_key", "");
        if (apiKey.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please set your Gemini API key first.", "API Key Missing", JOptionPane.WARNING_MESSAGE);
            return;
        }
        tabDataMap.put(currentTab, tableModel.getCurrentTabData());
        JDialog progressDialog = new JDialog();
        JProgressBar progressBar = new JProgressBar(0, sheetCount);
        progressBar.setStringPainted(true);
        progressDialog.add(new JLabel("Generating sheets with AI..."), BorderLayout.NORTH);
        progressDialog.add(progressBar, BorderLayout.CENTER);
        progressDialog.pack();
        progressDialog.setLocationRelativeTo(this);
        new Thread(() -> {
            List<TableRow> primaryData = tabDataMap.get("Primary");
            if (primaryData == null || primaryData.isEmpty()) {
                SwingUtilities.invokeLater(() -> {
                    progressDialog.dispose();
                    JOptionPane.showMessageDialog(this, "Primary tab has no data to use as a template.", "AI Error", JOptionPane.ERROR_MESSAGE);
                });
                return;
            }
            boolean isCurrentCollectionFixed = false;
            for (int i = 0; i < sheetCount; i++) {
                String sheetName = "generated_" + generatedTabCounter++;
                List<TableRow> sheetData = new ArrayList<>();
                for (TableRow row : primaryData) {
                    if (row instanceof CollectionHeaderRow) {
                        CollectionHeaderRow sourceHeader = (CollectionHeaderRow) row;
                        isCurrentCollectionFixed = sourceHeader.isFixed();
                        CollectionHeaderRow newHeader = new CollectionHeaderRow(sourceHeader.getCollectionName());
                        newHeader.setFixed(isCurrentCollectionFixed);
                        sheetData.add(newHeader);
                    } else if (row instanceof ElementDataRow) {
                        ElementDataRow sourceElement = (ElementDataRow) row;
                        ElementDataRow newElement = cloneElementDataRow(sourceElement);
                        if (!isCurrentCollectionFixed && sourceElement.getTestDataType() == ElementDataRow.TestDataType.STATIC) {
                            String sourceTestData = sourceElement.getTestDataValue();
                            if (sourceTestData != null && !sourceTestData.trim().isEmpty()) {
                                String generatedData = generateTestDataWithAI(apiKey, sourceElement.getElementName(), sourceTestData);
                                newElement.setTestDataValue(generatedData != null ? generatedData : "AI_Failed");
                            }
                        }
                        sheetData.add(newElement);
                    }
                }
                final int progress = i + 1;
                SwingUtilities.invokeLater(() -> {
                    tabDataMap.put(sheetName, sheetData);
                    tabSelectorComboBox.addItem(sheetName);
                    progressBar.setValue(progress);
                });
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
            }
            SwingUtilities.invokeLater(() -> {
                progressDialog.dispose();
                tabSelectorComboBox.setSelectedItem("generated_" + (generatedTabCounter - 1));
                this.hasUnsavedChanges = true;
                JOptionPane.showMessageDialog(this, "Generated " + sheetCount + " sheets successfully!", "AI Generation Complete", JOptionPane.INFORMATION_MESSAGE);
            });
        }).start();
        progressDialog.setVisible(true);
    }
    private String generateTestDataWithAI(String apiKey, String elementName, String exampleData) {
        try {
            String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent";
            String prompt = String.format(
                "You are a test data generator. Your task is to generate a new, realistic data value that follows the same pattern and data type as the example provided.\\n" +
                "Element Name: '%s'\\n" +
                "Example Value: '%s'\\n" +
                "Generate a new, different value that fits this pattern. The new value must not be the same as the example value. Only return the raw new value, with no explanation, labels, or quotation marks.",
                elementName, exampleData
            );
            String escapedPrompt = prompt.replace("\"", "\\\"").replace("\n", "\\n");
            String jsonPayload = "{ \"contents\": [ { \"parts\": [ { \"text\": \"" + escapedPrompt + "\" } ] } ] }";
            java.net.URL apiUrl = new java.net.URL(url + "?key=" + apiKey);
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) apiUrl.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            try (java.io.OutputStream os = conn.getOutputStream()) {
                os.write(jsonPayload.getBytes("utf-8"));
            }
            if (conn.getResponseCode() == 200) {
                try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(conn.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) response.append(line);
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    return jsonResponse.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim();
                }
            }
        } catch (Exception e) {
            System.err.println("AI Test Data Generation Failed for " + elementName + ": " + e.getMessage());
        }
        return null;
    }
    //</editor-fold>
    //<editor-fold desc="Helpers">
    private JButton createModernButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setOpaque(true);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bgColor.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(bgColor);
            }
        });
        return button;
    }
    public boolean hasUnsavedChanges() {
        return this.hasUnsavedChanges;
    }
    private String formatActionsForDisplay(ElementDataRow element) {
        StringBuilder sb = new StringBuilder();
        if (element.getBeforeAction() != null && !element.getBeforeAction().isEmpty()) sb.append("[B: ").append(element.getBeforeAction()).append("] ");
        if (element.getMainAction() != null && !element.getMainAction().isEmpty()) sb.append(element.getMainAction());
        if (element.getAfterAction() != null && !element.getAfterAction().isEmpty()) sb.append(" [A: ").append(element.getAfterAction()).append("]");
        return sb.toString().trim();
    }
    private String formatTestDataForDisplay(ElementDataRow element) {
        if (element == null) return "";
        switch (element.getTestDataType()) {
            case STATIC:
                return element.getTestDataValue() != null ? element.getTestDataValue() : "";
            case CURRENT_DATE:
            case YESTERDAY_DATE:
                return element.getTestDataType().toString();
            case RANDOM_NUMERIC:
            case RANDOM_ALPHANUMERIC:
                return element.getTestDataType() + ": " + element.getTestDataValue();
            default:
                return "";
        }
    }
    private String getCellStringValue(Cell cell) {
        if (cell == null) {
            return "";
        }
        return new DataFormatter().formatCellValue(cell);
    }
    private String generateRandomNumeric(int length) {
        if (length <= 0) return "";
        Random random = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }
    private String generateRandomAlphanumeric(int length) {
        if (length <= 0) return "";
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }
    private ElementDataRow cloneElementDataRow(ElementDataRow source) {
        if (source == null) return null;
        ElementDataRow clone = new ElementDataRow(
            source.getElementName(),
            new ArrayList<>(source.getAvailableLocators()),
            source.getSelectedLocator()
        );
        clone.setBeforeAction(source.getBeforeAction());
        clone.setMainAction(source.getMainAction());
        clone.setAfterAction(source.getAfterAction());
        clone.setTestDataType(source.getTestDataType());
        clone.setTestDataValue(source.getTestDataValue());
        return clone;
    }
    private TableRow cloneRow(TableRow source) {
        if (source instanceof CollectionHeaderRow) {
            CollectionHeaderRow header = (CollectionHeaderRow) source;
            CollectionHeaderRow newHeader = new CollectionHeaderRow(header.getCollectionName());
            newHeader.setFixed(header.isFixed());
            return newHeader;
        } else if (source instanceof ElementDataRow) {
            return cloneElementDataRow((ElementDataRow) source);
        }
        return null;
    }
    private String resolveTestData(ElementDataRow element) {
        String dateFormat = prefs.get(DATE_FORMAT_KEY, "yyyy-MM-dd");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);
        int length;
        switch (element.getTestDataType()) {
            case CURRENT_DATE:
                return LocalDate.now().format(formatter);
            case YESTERDAY_DATE:
                return LocalDate.now().minusDays(1).format(formatter);
            case RANDOM_NUMERIC:
                try {
                    length = Integer.parseInt(element.getTestDataValue());
                    return generateRandomNumeric(length);
                } catch (Exception e) {
                    return "INVALID_LENGTH";
                }
            case RANDOM_ALPHANUMERIC:
                try {
                    length = Integer.parseInt(element.getTestDataValue());
                    return generateRandomAlphanumeric(length);
                } catch (Exception e) {
                    return "INVALID_LENGTH";
                }
            case STATIC:
            default:
                return element.getTestDataValue();
        }
    }
    //</editor-fold>
    //<editor-fold desc="Inner classes">
    static abstract class TableRow {}
    public static class TestDataPackage {
        private final String tabName;
        private final List<TableRow> testSteps;
        public TestDataPackage(String tabName, List<TableRow> testSteps) {
            this.tabName = tabName;
            this.testSteps = testSteps;
        }
        public String getTabName() {
            return tabName;
        }
        public List<TableRow> getTestSteps() {
            return testSteps;
        }
    }
    public TestDataPackage getActiveTestData() {
        if (currentTab == null || tabDataMap.get(currentTab) == null) return null;
        List<TableRow> executionSteps = new ArrayList<>();
        String url = urlTextField.getText().trim();
        ElementDataRow navigateStep = new ElementDataRow("Navigate Action", Collections.emptyList(), "");
        navigateStep.setMainAction("NAVIGATE TO URL");
        navigateStep.setTestDataType(ElementDataRow.TestDataType.STATIC);
        navigateStep.setTestDataValue(url);
        executionSteps.add(navigateStep);
        List<TableRow> originalSteps = tabDataMap.get(currentTab);
        for (TableRow step : originalSteps) {
            if (step instanceof ElementDataRow) {
                ElementDataRow originalElement = (ElementDataRow) step;
                ElementDataRow resolvedElement = cloneElementDataRow(originalElement);
                String resolvedValue = resolveTestData(originalElement);
                resolvedElement.setTestDataValue(resolvedValue);
                executionSteps.add(resolvedElement);
            } else {
                executionSteps.add(step);
            }
        }
        return new TestDataPackage(currentTab, executionSteps);
    }
    private static class CollectionHeaderRow extends TableRow {
        private final String collectionName;
        private boolean isFixed = false;
        public CollectionHeaderRow(String name) {
            this.collectionName = name;
        }
        public String getCollectionName() {
            return collectionName;
        }
        public boolean isFixed() {
            return isFixed;
        }
        public void setFixed(boolean fixed) {
            isFixed = fixed;
        }
    }
    static class ElementDataRow extends TableRow {
        public enum TestDataType {
            STATIC("Static Text"),
            CURRENT_DATE("Current Date"),
            YESTERDAY_DATE("Yesterday's Date"),
            RANDOM_NUMERIC("Random N-Digit Number"),
            RANDOM_ALPHANUMERIC("Random Alphanumeric");
            private final String displayName;
            TestDataType(String displayName) {
                this.displayName = displayName;
            }
            @Override public String toString() {
                return displayName;
            }
            public static Optional<TestDataType> fromDisplayName(String name) {
                return Arrays.stream(values())
                    .filter(e -> e.displayName.equalsIgnoreCase(name))
                    .findFirst();
            }
        }
        private final String elementName;
        private final List<String> availableLocators;
        private String selectedLocator;
        private TestDataType testDataType = TestDataType.STATIC;
        private String testDataValue;
        private String beforeAction = "";
        private String mainAction = "";
        private String afterAction = "";
        public ElementDataRow(String name, List<String> locators, String selected) {
            this.elementName = name;
            this.availableLocators = locators;
            this.selectedLocator = selected;
        }
        public String getElementName() { return elementName; }
        public List<String> getAvailableLocators() { return availableLocators; }
        public String getSelectedLocator() { return selectedLocator; }
        public void setSelectedLocator(String s) { this.selectedLocator = s; }
        public TestDataType getTestDataType() { return testDataType; }
        public void setTestDataType(TestDataType testDataType) { this.testDataType = testDataType; }
        public String getTestDataValue() { return testDataValue; }
        public void setTestDataValue(String testDataValue) { this.testDataValue = testDataValue; }
        public String getTestData() { return testDataValue; }
        public void setTestData(String data) { this.testDataValue = data; }
        public String getBeforeAction() { return beforeAction; }
        public void setBeforeAction(String beforeAction) { this.beforeAction = beforeAction; }
        public String getMainAction() { return mainAction; }
        public void setMainAction(String mainAction) { this.mainAction = mainAction; }
        public String getAfterAction() { return afterAction; }
        public void setAfterAction(String afterAction) { this.afterAction = afterAction; }
    }
    private class TestDataTableModel extends AbstractTableModel {
        private final String[] columnNames = {"Element Name / Collection", "Locator", "Action(s)", "Test Data"};
        private List<TableRow> currentTabData = new ArrayList<>();
        private final String[] elementActions = {"", "CLICK", "TYPE TEXT", "SELECT FROM DROPDOWN", "UPLOAD FILE", "EXECUTE JAVASCRIPT"};
        private final String[] browserActions = {"", "NAVIGATE TO URL", "WAIT", "SWITCH WINDOW/TAB", "SWITCH TO FRAME", "SWITCH TO DEFAULT", "HANDLE PROMPTS/ALERTS","SWITCH TO MAIN WINDOW"};
        public String[] getElementActions() { return elementActions; }
        public String[] getBrowserActions() { return browserActions; }
        public List<TableRow> getCurrentTabData() { return currentTabData; }
        public void setTabData(List<TableRow> data) {
            this.currentTabData = data != null ? data : new ArrayList<>();
            fireTableDataChanged();
        }
        @Override public int getRowCount() { return currentTabData.size(); }
        @Override public int getColumnCount() { return columnNames.length; }
        @Override public String getColumnName(int column) { return columnNames[column]; }
        @Override public boolean isCellEditable(int row, int col) {
            TableRow tableRow = currentTabData.get(row);
            if (tableRow instanceof CollectionHeaderRow) {
                return col == 0;
            }
            return col > 0 && tableRow instanceof ElementDataRow;
        }
        @Override public Object getValueAt(int rowIndex, int columnIndex) {
            TableRow row = currentTabData.get(rowIndex);
            if (row instanceof CollectionHeaderRow) {
                return (columnIndex == 0) ? row : "";
            } else if (row instanceof ElementDataRow) {
                ElementDataRow element = (ElementDataRow) row;
                switch (columnIndex) {
                    case 0: return "    " + element.getElementName();
                    case 1: return element.getSelectedLocator();
                    case 2:
                    case 3: return element;
                }
            }
            return "";
        }
        @Override public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
            TableRow row = currentTabData.get(rowIndex);
            if (row instanceof CollectionHeaderRow) {
                fireTableRowsUpdated(rowIndex, rowIndex);
                Tool2Panel.this.hasUnsavedChanges = true;
            } else if (row instanceof ElementDataRow) {
                ElementDataRow element = (ElementDataRow) row;
                switch (columnIndex) {
                    case 1:
                        element.setSelectedLocator(aValue.toString());
                        break;
                    case 2:
                    case 3:
                        if (aValue instanceof ElementDataRow) {
                            ElementDataRow updatedElement = (ElementDataRow) aValue;
                            element.setBeforeAction(updatedElement.getBeforeAction());
                            element.setMainAction(updatedElement.getMainAction());
                            element.setAfterAction(updatedElement.getAfterAction());
                            element.setTestDataType(updatedElement.getTestDataType());
                            element.setTestDataValue(updatedElement.getTestDataValue());
                        }
                        break;
                }
                fireTableCellUpdated(rowIndex, columnIndex);
                Tool2Panel.this.hasUnsavedChanges = true;
            }
        }
    }
    private class CollectionRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            c.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
            c.setFont(table.getFont().deriveFont(Font.PLAIN));
            c.setForeground(table.getForeground());
            return c;
        }
    }
    private class HeaderRenderer implements TableCellRenderer {
        private final JPanel panel = new JPanel(new BorderLayout(10, 0));
        private final JLabel label = new JLabel();
        private final JCheckBox checkBox = new JCheckBox("Fixed");
        private final DefaultTableCellRenderer defaultRenderer = new DefaultTableCellRenderer();
        HeaderRenderer() {
            panel.add(label, BorderLayout.CENTER);
            panel.add(checkBox, BorderLayout.EAST);
            panel.setOpaque(true);
            checkBox.setOpaque(false);
        }
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (value instanceof CollectionHeaderRow) {
                CollectionHeaderRow header = (CollectionHeaderRow) value;
                panel.setBackground(COLLECTION_HEADER_COLOR);
                label.setFont(table.getFont().deriveFont(Font.BOLD, 14));
                label.setForeground(Color.DARK_GRAY);
                label.setText(header.getCollectionName());
                checkBox.setSelected(header.isFixed());
                return panel;
            } else {
                return defaultRenderer.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        }
    }
    private class HeaderEditor extends AbstractCellEditor implements TableCellEditor {
        private final JPanel panel = new JPanel(new BorderLayout(10, 0));
        private final JLabel label = new JLabel();
        private final JCheckBox checkBox = new JCheckBox("Fixed");
        private CollectionHeaderRow currentHeader;
        HeaderEditor() {
            panel.add(label, BorderLayout.CENTER);
            panel.add(checkBox, BorderLayout.EAST);
            panel.setBackground(COLLECTION_HEADER_COLOR);
            checkBox.setOpaque(false);
            checkBox.addActionListener(e -> {
                if (currentHeader != null) {
                    currentHeader.setFixed(checkBox.isSelected());
                    fireEditingStopped();
                }
            });
        }
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            if (value instanceof CollectionHeaderRow) {
                this.currentHeader = (CollectionHeaderRow) value;
                label.setFont(table.getFont().deriveFont(Font.BOLD, 14));
                label.setForeground(Color.DARK_GRAY);
                label.setText(currentHeader.getCollectionName());
                checkBox.setSelected(currentHeader.isFixed());
                return panel;
            }
            return null;
        }
        @Override
        public Object getCellEditorValue() {
            return this.currentHeader;
        }
    }
    private class LocatorCellEditor extends DefaultCellEditor {
        public LocatorCellEditor() {
            super(new JComboBox<>());
        }
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            if (((TestDataTableModel) table.getModel()).currentTabData.get(row) instanceof ElementDataRow) {
                ElementDataRow element = (ElementDataRow) ((TestDataTableModel) table.getModel()).currentTabData.get(row);
                JComboBox<String> comboBox = (JComboBox<String>) editorComponent;
                comboBox.removeAllItems();
                if (element.getAvailableLocators() != null) {
                    element.getAvailableLocators().forEach(comboBox::addItem);
                }
                comboBox.setSelectedItem(value);
                return comboBox;
            }
            return null;
        }
    }
    private class ActionCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (value instanceof ElementDataRow) {
                setText(formatActionsForDisplay((ElementDataRow) value));
            } else {
                setText("");
            }
            return this;
        }
    }
    private class ActionCellEditor extends AbstractCellEditor implements TableCellEditor {
        private ElementDataRow currentElement;
        @Override
        public Object getCellEditorValue() {
            return currentElement;
        }
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.currentElement = cloneElementDataRow((ElementDataRow) value);
            ActionSequenceDialog dialog = new ActionSequenceDialog(
                (Frame) SwingUtilities.getWindowAncestor(Tool2Panel.this),
                tableModel.getBrowserActions(),
                tableModel.getElementActions(),
                currentElement
            );
            if (dialog.isConfirmed()) {
                this.currentElement = dialog.getUpdatedElement();
            }
            fireEditingStopped();
            return new JLabel(formatActionsForDisplay(currentElement));
        }
    }
    private class TestDataCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (value instanceof ElementDataRow) {
                setText(formatTestDataForDisplay((ElementDataRow) value));
            } else {
                setText("");
            }
            return this;
        }
    }
    private class TestDataCellEditor extends AbstractCellEditor implements TableCellEditor {
        private ElementDataRow currentElement;
        @Override
        public Object getCellEditorValue() {
            return currentElement;
        }
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.currentElement = cloneElementDataRow((ElementDataRow) value);
            TestDataEditorDialog dialog = new TestDataEditorDialog(
                (Frame) SwingUtilities.getWindowAncestor(Tool2Panel.this),
                currentElement
            );
            if (dialog.isConfirmed()) {
                this.currentElement = dialog.getUpdatedElement();
            }
            fireEditingStopped();
            return new JLabel(formatTestDataForDisplay(currentElement));
        }
    }
    private static class ActionSequenceDialog extends JDialog {
        private JComboBox<String> beforeActionBox, mainActionBox, afterActionBox;
        private boolean confirmed = false;
        private ElementDataRow element;
        public ActionSequenceDialog(Frame owner, String[] browserActions, String[] elementActions, ElementDataRow element) {
            super(owner, "Action Sequence Editor", true);
            this.element = element;
            JPanel mainPanel = new JPanel(new GridLayout(0, 2, 10, 10));
            mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
            beforeActionBox = new JComboBox<>(browserActions);
            mainActionBox = new JComboBox<>(elementActions);
            afterActionBox = new JComboBox<>(browserActions);
            beforeActionBox.setSelectedItem(element.getBeforeAction());
            mainActionBox.setSelectedItem(element.getMainAction());
            afterActionBox.setSelectedItem(element.getAfterAction());
            JButton okButton = new JButton("OK");
            okButton.addActionListener(e -> {
                confirmed = true;
                this.element.setBeforeAction((String) beforeActionBox.getSelectedItem());
                this.element.setMainAction((String) mainActionBox.getSelectedItem());
                this.element.setAfterAction((String) afterActionBox.getSelectedItem());
                dispose();
            });
            JButton cancelButton = new JButton("Cancel");
            cancelButton.addActionListener(e -> dispose());
            mainPanel.add(new JLabel("Before Action (Browser-level):"));
            mainPanel.add(beforeActionBox);
            mainPanel.add(new JLabel("Main Action (Element-level):"));
            mainPanel.add(mainActionBox);
            mainPanel.add(new JLabel("After Action (Browser-level):"));
            mainPanel.add(afterActionBox);
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttonPanel.add(okButton);
            buttonPanel.add(cancelButton);
            add(mainPanel, BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
            pack();
            setLocationRelativeTo(owner);
            setVisible(true);
        }
        public boolean isConfirmed() { return confirmed; }
        public ElementDataRow getUpdatedElement() { return element; }
    }
    private static class TestDataEditorDialog extends JDialog {
        private JComboBox<ElementDataRow.TestDataType> typeComboBox;
        private JTextField valueField;
        private JLabel valueLabel;
        private boolean confirmed = false;
        private ElementDataRow element;
        public TestDataEditorDialog(Frame owner, ElementDataRow element) {
            super(owner, "Test Data Editor", true);
            this.element = element;
            JPanel mainPanel = new JPanel(new GridBagLayout());
            mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.fill = GridBagConstraints.HORIZONTAL;
            typeComboBox = new JComboBox<>(ElementDataRow.TestDataType.values());
            valueField = new JTextField(20);
            valueLabel = new JLabel();
            gbc.gridx = 0; gbc.gridy = 0;
            mainPanel.add(new JLabel("Data Type:"), gbc);
            gbc.gridx = 1; mainPanel.add(typeComboBox, gbc);
            gbc.gridx = 0; gbc.gridy = 1;
            mainPanel.add(valueLabel, gbc);
            gbc.gridx = 1; mainPanel.add(valueField, gbc);
            typeComboBox.setSelectedItem(element.getTestDataType());
            valueField.setText(element.getTestDataValue());
            typeComboBox.addActionListener(e -> updateValueFieldState());
            updateValueFieldState();
            JButton okButton = new JButton("OK");
            okButton.addActionListener(e -> {
                confirmed = true;
                this.element.setTestDataType((ElementDataRow.TestDataType) typeComboBox.getSelectedItem());
                this.element.setTestDataValue(valueField.getText());
                dispose();
            });
            JButton cancelButton = new JButton("Cancel");
            cancelButton.addActionListener(e -> dispose());
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttonPanel.add(okButton);
            buttonPanel.add(cancelButton);
            add(mainPanel, BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
            pack();
            setLocationRelativeTo(owner);
            setVisible(true);
        }
        private void updateValueFieldState() {
            ElementDataRow.TestDataType selected = (ElementDataRow.TestDataType) typeComboBox.getSelectedItem();
            switch (selected) {
                case STATIC:
                    valueLabel.setText("Value:");
                    valueField.setEnabled(true);
                    break;
                case RANDOM_NUMERIC:
                case RANDOM_ALPHANUMERIC:
                    valueLabel.setText("Length:");
                    valueField.setEnabled(true);
                    break;
                case CURRENT_DATE:
                case YESTERDAY_DATE:
                    valueLabel.setText("Value:");
                    valueField.setEnabled(false);
                    valueField.setText("");
                    break;
            }
        }
        public boolean isConfirmed() { return confirmed; }
        public ElementDataRow getUpdatedElement() { return element; }
    }
    //</editor-fold>
}